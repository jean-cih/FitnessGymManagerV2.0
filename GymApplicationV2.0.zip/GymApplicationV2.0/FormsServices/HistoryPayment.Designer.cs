﻿namespace GymApplicationV2._0
{
    partial class HistoryPayment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataGridViewHistory = new System.Windows.Forms.DataGridView();
            this.radioForMonth = new System.Windows.Forms.RadioButton();
            this.radioForDay = new System.Windows.Forms.RadioButton();
            this.radioOtherPeriod = new System.Windows.Forms.RadioButton();
            this.labelWith = new System.Windows.Forms.Label();
            this.labelTo = new System.Windows.Forms.Label();
            this.radioForWeek = new System.Windows.Forms.RadioButton();
            this.jeanModernButtonShow = new GymApplicationV2._0.Controls.JeanModernButton();
            this.labelPayments = new System.Windows.Forms.Label();
            this.jeanModernButtonRefresh = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanPanel = new GymApplicationV2._0.Controls.JeanPanel();
            this.jeanDateTimePickerBegin = new GymApplicationV2._0.Controls.JeanDateTimePicker();
            this.jeanDateTimePickerEnd = new GymApplicationV2._0.Controls.JeanDateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHistory)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewHistory
            // 
            this.dataGridViewHistory.AllowUserToAddRows = false;
            this.dataGridViewHistory.AllowUserToDeleteRows = false;
            this.dataGridViewHistory.AllowUserToResizeColumns = false;
            this.dataGridViewHistory.AllowUserToResizeRows = false;
            this.dataGridViewHistory.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewHistory.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewHistory.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewHistory.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewHistory.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridViewHistory.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(230)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(230)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewHistory.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewHistory.ColumnHeadersHeight = 35;
            this.dataGridViewHistory.EnableHeadersVisualStyles = false;
            this.dataGridViewHistory.GridColor = System.Drawing.Color.Black;
            this.dataGridViewHistory.Location = new System.Drawing.Point(31, 178);
            this.dataGridViewHistory.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridViewHistory.Name = "dataGridViewHistory";
            this.dataGridViewHistory.ReadOnly = true;
            this.dataGridViewHistory.RowHeadersVisible = false;
            this.dataGridViewHistory.RowHeadersWidth = 51;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            this.dataGridViewHistory.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewHistory.RowTemplate.Height = 24;
            this.dataGridViewHistory.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewHistory.Size = new System.Drawing.Size(1180, 414);
            this.dataGridViewHistory.TabIndex = 1;
            // 
            // radioForMonth
            // 
            this.radioForMonth.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.radioForMonth.AutoSize = true;
            this.radioForMonth.Location = new System.Drawing.Point(1012, 8);
            this.radioForMonth.Name = "radioForMonth";
            this.radioForMonth.Size = new System.Drawing.Size(87, 20);
            this.radioForMonth.TabIndex = 29;
            this.radioForMonth.Text = "За месяц";
            this.radioForMonth.UseVisualStyleBackColor = true;
            // 
            // radioForDay
            // 
            this.radioForDay.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.radioForDay.AutoSize = true;
            this.radioForDay.Location = new System.Drawing.Point(1012, 68);
            this.radioForDay.Name = "radioForDay";
            this.radioForDay.Size = new System.Drawing.Size(79, 20);
            this.radioForDay.TabIndex = 30;
            this.radioForDay.Text = "За день";
            this.radioForDay.UseVisualStyleBackColor = true;
            // 
            // radioOtherPeriod
            // 
            this.radioOtherPeriod.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.radioOtherPeriod.AutoSize = true;
            this.radioOtherPeriod.Checked = true;
            this.radioOtherPeriod.Location = new System.Drawing.Point(1012, 98);
            this.radioOtherPeriod.Name = "radioOtherPeriod";
            this.radioOtherPeriod.Size = new System.Drawing.Size(126, 20);
            this.radioOtherPeriod.TabIndex = 35;
            this.radioOtherPeriod.TabStop = true;
            this.radioOtherPeriod.Text = "Другой период";
            this.radioOtherPeriod.UseVisualStyleBackColor = true;
            // 
            // labelWith
            // 
            this.labelWith.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelWith.AutoSize = true;
            this.labelWith.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelWith.Location = new System.Drawing.Point(892, 134);
            this.labelWith.Name = "labelWith";
            this.labelWith.Size = new System.Drawing.Size(18, 20);
            this.labelWith.TabIndex = 28;
            this.labelWith.Text = "с";
            // 
            // labelTo
            // 
            this.labelTo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelTo.AutoSize = true;
            this.labelTo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelTo.Location = new System.Drawing.Point(1055, 134);
            this.labelTo.Name = "labelTo";
            this.labelTo.Size = new System.Drawing.Size(29, 20);
            this.labelTo.TabIndex = 34;
            this.labelTo.Text = "по";
            // 
            // radioForWeek
            // 
            this.radioForWeek.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.radioForWeek.AutoSize = true;
            this.radioForWeek.Location = new System.Drawing.Point(1012, 38);
            this.radioForWeek.Name = "radioForWeek";
            this.radioForWeek.Size = new System.Drawing.Size(98, 20);
            this.radioForWeek.TabIndex = 31;
            this.radioForWeek.Text = "За неделю";
            this.radioForWeek.UseVisualStyleBackColor = true;
            // 
            // jeanModernButtonShow
            // 
            this.jeanModernButtonShow.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.jeanModernButtonShow.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonShow.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonShow.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButtonShow.BorderRadius = 20;
            this.jeanModernButtonShow.BorderSize = 2;
            this.jeanModernButtonShow.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonShow.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonShow.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonShow.Location = new System.Drawing.Point(468, 613);
            this.jeanModernButtonShow.Name = "jeanModernButtonShow";
            this.jeanModernButtonShow.Size = new System.Drawing.Size(150, 45);
            this.jeanModernButtonShow.TabIndex = 36;
            this.jeanModernButtonShow.Text = "Показать";
            this.jeanModernButtonShow.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonShow.UseVisualStyleBackColor = false;
            this.jeanModernButtonShow.Click += new System.EventHandler(this.jeanModernButtonShow_Click);
            // 
            // labelPayments
            // 
            this.labelPayments.AutoSize = true;
            this.labelPayments.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelPayments.Location = new System.Drawing.Point(26, 134);
            this.labelPayments.Name = "labelPayments";
            this.labelPayments.Size = new System.Drawing.Size(0, 25);
            this.labelPayments.TabIndex = 37;
            // 
            // jeanModernButtonRefresh
            // 
            this.jeanModernButtonRefresh.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.jeanModernButtonRefresh.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonRefresh.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonRefresh.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButtonRefresh.BorderRadius = 20;
            this.jeanModernButtonRefresh.BorderSize = 2;
            this.jeanModernButtonRefresh.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonRefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonRefresh.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonRefresh.Location = new System.Drawing.Point(624, 613);
            this.jeanModernButtonRefresh.Name = "jeanModernButtonRefresh";
            this.jeanModernButtonRefresh.Size = new System.Drawing.Size(150, 45);
            this.jeanModernButtonRefresh.TabIndex = 38;
            this.jeanModernButtonRefresh.Text = "Обновить";
            this.jeanModernButtonRefresh.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonRefresh.UseVisualStyleBackColor = false;
            this.jeanModernButtonRefresh.Click += new System.EventHandler(this.jeanModernButtonRefresh_Click);
            // 
            // jeanPanel
            // 
            this.jeanPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.jeanPanel.BackColor = System.Drawing.Color.White;
            this.jeanPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.jeanPanel.BorderRadius = 30;
            this.jeanPanel.ForeColor = System.Drawing.Color.Black;
            this.jeanPanel.GradientAngle = 90F;
            this.jeanPanel.GradientBottomColor = System.Drawing.Color.DodgerBlue;
            this.jeanPanel.GradientTapColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            this.jeanPanel.Location = new System.Drawing.Point(12, 169);
            this.jeanPanel.Name = "jeanPanel";
            this.jeanPanel.Size = new System.Drawing.Size(1217, 436);
            this.jeanPanel.TabIndex = 39;
            // 
            // jeanDateTimePickerBegin
            // 
            this.jeanDateTimePickerBegin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jeanDateTimePickerBegin.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            this.jeanDateTimePickerBegin.BorderSize = 2;
            this.jeanDateTimePickerBegin.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanDateTimePickerBegin.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.jeanDateTimePickerBegin.Location = new System.Drawing.Point(914, 127);
            this.jeanDateTimePickerBegin.MaxDate = new System.DateTime(2100, 12, 31, 0, 0, 0, 0);
            this.jeanDateTimePickerBegin.MinDate = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.jeanDateTimePickerBegin.MinimumSize = new System.Drawing.Size(4, 30);
            this.jeanDateTimePickerBegin.Name = "jeanDateTimePickerBegin";
            this.jeanDateTimePickerBegin.Size = new System.Drawing.Size(135, 30);
            this.jeanDateTimePickerBegin.SkinColor = System.Drawing.Color.White;
            this.jeanDateTimePickerBegin.TabIndex = 41;
            this.jeanDateTimePickerBegin.TextColor = System.Drawing.Color.Black;
            // 
            // jeanDateTimePickerEnd
            // 
            this.jeanDateTimePickerEnd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jeanDateTimePickerEnd.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            this.jeanDateTimePickerEnd.BorderSize = 2;
            this.jeanDateTimePickerEnd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanDateTimePickerEnd.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.jeanDateTimePickerEnd.Location = new System.Drawing.Point(1089, 127);
            this.jeanDateTimePickerEnd.MaxDate = new System.DateTime(2100, 12, 31, 0, 0, 0, 0);
            this.jeanDateTimePickerEnd.MinDate = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.jeanDateTimePickerEnd.MinimumSize = new System.Drawing.Size(4, 30);
            this.jeanDateTimePickerEnd.Name = "jeanDateTimePickerEnd";
            this.jeanDateTimePickerEnd.Size = new System.Drawing.Size(135, 30);
            this.jeanDateTimePickerEnd.SkinColor = System.Drawing.Color.White;
            this.jeanDateTimePickerEnd.TabIndex = 42;
            this.jeanDateTimePickerEnd.TextColor = System.Drawing.Color.Black;
            // 
            // HistoryPayment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1241, 743);
            this.Controls.Add(this.jeanDateTimePickerEnd);
            this.Controls.Add(this.jeanDateTimePickerBegin);
            this.Controls.Add(this.dataGridViewHistory);
            this.Controls.Add(this.jeanPanel);
            this.Controls.Add(this.jeanModernButtonRefresh);
            this.Controls.Add(this.labelPayments);
            this.Controls.Add(this.jeanModernButtonShow);
            this.Controls.Add(this.radioOtherPeriod);
            this.Controls.Add(this.labelTo);
            this.Controls.Add(this.labelWith);
            this.Controls.Add(this.radioForWeek);
            this.Controls.Add(this.radioForDay);
            this.Controls.Add(this.radioForMonth);
            this.Name = "HistoryPayment";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "HistoryPayment";
            this.Load += new System.EventHandler(this.HistoryPayment_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHistory)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        protected internal System.Windows.Forms.DataGridView dataGridViewHistory;
        private System.Windows.Forms.RadioButton radioForMonth;
        private System.Windows.Forms.RadioButton radioForDay;
        private System.Windows.Forms.RadioButton radioOtherPeriod;
        private System.Windows.Forms.Label labelWith;
        private System.Windows.Forms.Label labelTo;
        private System.Windows.Forms.RadioButton radioForWeek;
        private Controls.JeanModernButton jeanModernButtonShow;
        private System.Windows.Forms.Label labelPayments;
        private Controls.JeanModernButton jeanModernButtonRefresh;
        private Controls.JeanPanel jeanPanel;
        private Controls.JeanDateTimePicker jeanDateTimePickerEnd;
        private Controls.JeanDateTimePicker jeanDateTimePickerBegin;
    }
}