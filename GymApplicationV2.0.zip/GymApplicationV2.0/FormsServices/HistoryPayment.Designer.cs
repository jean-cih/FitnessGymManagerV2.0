﻿namespace GymApplicationV2._0
{
    partial class HistoryPayment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataGridViewHistory = new System.Windows.Forms.DataGridView();
            this.radioForMonth = new System.Windows.Forms.RadioButton();
            this.radioForDay = new System.Windows.Forms.RadioButton();
            this.radioOtherPeriod = new System.Windows.Forms.RadioButton();
            this.dateTimePickerBegin = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerEnd = new System.Windows.Forms.DateTimePicker();
            this.labelWith = new System.Windows.Forms.Label();
            this.labelTo = new System.Windows.Forms.Label();
            this.radioForWeek = new System.Windows.Forms.RadioButton();
            this.jeanModernButtonShow = new GymApplicationV2._0.Controls.JeanModernButton();
            this.labelPayments = new System.Windows.Forms.Label();
            this.jeanModernButtonRefresh = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanFormStyle = new GymApplicationV2._0.Components.JeanFormStyle(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHistory)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewHistory
            // 
            this.dataGridViewHistory.AllowUserToAddRows = false;
            this.dataGridViewHistory.AllowUserToDeleteRows = false;
            this.dataGridViewHistory.AllowUserToResizeColumns = false;
            this.dataGridViewHistory.AllowUserToResizeRows = false;
            this.dataGridViewHistory.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewHistory.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewHistory.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewHistory.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridViewHistory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewHistory.GridColor = System.Drawing.Color.Black;
            this.dataGridViewHistory.Location = new System.Drawing.Point(12, 173);
            this.dataGridViewHistory.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridViewHistory.Name = "dataGridViewHistory";
            this.dataGridViewHistory.ReadOnly = true;
            this.dataGridViewHistory.RowHeadersWidth = 51;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            this.dataGridViewHistory.RowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewHistory.RowTemplate.Height = 24;
            this.dataGridViewHistory.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewHistory.Size = new System.Drawing.Size(1217, 419);
            this.dataGridViewHistory.TabIndex = 1;
            // 
            // radioForMonth
            // 
            this.radioForMonth.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.radioForMonth.AutoSize = true;
            this.radioForMonth.Location = new System.Drawing.Point(949, 13);
            this.radioForMonth.Name = "radioForMonth";
            this.radioForMonth.Size = new System.Drawing.Size(87, 20);
            this.radioForMonth.TabIndex = 29;
            this.radioForMonth.Text = "За месяц";
            this.radioForMonth.UseVisualStyleBackColor = true;
            // 
            // radioForDay
            // 
            this.radioForDay.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.radioForDay.AutoSize = true;
            this.radioForDay.Location = new System.Drawing.Point(949, 73);
            this.radioForDay.Name = "radioForDay";
            this.radioForDay.Size = new System.Drawing.Size(79, 20);
            this.radioForDay.TabIndex = 30;
            this.radioForDay.Text = "За день";
            this.radioForDay.UseVisualStyleBackColor = true;
            // 
            // radioOtherPeriod
            // 
            this.radioOtherPeriod.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.radioOtherPeriod.AutoSize = true;
            this.radioOtherPeriod.Checked = true;
            this.radioOtherPeriod.Location = new System.Drawing.Point(949, 103);
            this.radioOtherPeriod.Name = "radioOtherPeriod";
            this.radioOtherPeriod.Size = new System.Drawing.Size(126, 20);
            this.radioOtherPeriod.TabIndex = 35;
            this.radioOtherPeriod.TabStop = true;
            this.radioOtherPeriod.Text = "Другой период";
            this.radioOtherPeriod.UseVisualStyleBackColor = true;
            // 
            // dateTimePickerBegin
            // 
            this.dateTimePickerBegin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.dateTimePickerBegin.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerBegin.Location = new System.Drawing.Point(956, 136);
            this.dateTimePickerBegin.MaxDate = new System.DateTime(2100, 12, 31, 0, 0, 0, 0);
            this.dateTimePickerBegin.MinDate = new System.DateTime(2022, 1, 1, 0, 0, 0, 0);
            this.dateTimePickerBegin.Name = "dateTimePickerBegin";
            this.dateTimePickerBegin.Size = new System.Drawing.Size(109, 22);
            this.dateTimePickerBegin.TabIndex = 32;
            // 
            // dateTimePickerEnd
            // 
            this.dateTimePickerEnd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.dateTimePickerEnd.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerEnd.Location = new System.Drawing.Point(1116, 136);
            this.dateTimePickerEnd.MaxDate = new System.DateTime(2100, 12, 31, 0, 0, 0, 0);
            this.dateTimePickerEnd.MinDate = new System.DateTime(2022, 1, 1, 0, 0, 0, 0);
            this.dateTimePickerEnd.Name = "dateTimePickerEnd";
            this.dateTimePickerEnd.Size = new System.Drawing.Size(109, 22);
            this.dateTimePickerEnd.TabIndex = 33;
            // 
            // labelWith
            // 
            this.labelWith.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelWith.AutoSize = true;
            this.labelWith.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelWith.Location = new System.Drawing.Point(928, 136);
            this.labelWith.Name = "labelWith";
            this.labelWith.Size = new System.Drawing.Size(18, 20);
            this.labelWith.TabIndex = 28;
            this.labelWith.Text = "с";
            // 
            // labelTo
            // 
            this.labelTo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelTo.AutoSize = true;
            this.labelTo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelTo.Location = new System.Drawing.Point(1074, 136);
            this.labelTo.Name = "labelTo";
            this.labelTo.Size = new System.Drawing.Size(29, 20);
            this.labelTo.TabIndex = 34;
            this.labelTo.Text = "по";
            // 
            // radioForWeek
            // 
            this.radioForWeek.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.radioForWeek.AutoSize = true;
            this.radioForWeek.Location = new System.Drawing.Point(949, 43);
            this.radioForWeek.Name = "radioForWeek";
            this.radioForWeek.Size = new System.Drawing.Size(98, 20);
            this.radioForWeek.TabIndex = 31;
            this.radioForWeek.Text = "За неделю";
            this.radioForWeek.UseVisualStyleBackColor = true;
            // 
            // jeanModernButtonShow
            // 
            this.jeanModernButtonShow.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.jeanModernButtonShow.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonShow.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonShow.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButtonShow.BorderRadius = 20;
            this.jeanModernButtonShow.BorderSize = 2;
            this.jeanModernButtonShow.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonShow.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonShow.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonShow.Location = new System.Drawing.Point(468, 611);
            this.jeanModernButtonShow.Name = "jeanModernButtonShow";
            this.jeanModernButtonShow.Size = new System.Drawing.Size(150, 45);
            this.jeanModernButtonShow.TabIndex = 36;
            this.jeanModernButtonShow.Text = "Показать";
            this.jeanModernButtonShow.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonShow.UseVisualStyleBackColor = false;
            this.jeanModernButtonShow.Click += new System.EventHandler(this.jeanModernButtonShow_Click);
            // 
            // labelPayments
            // 
            this.labelPayments.AutoSize = true;
            this.labelPayments.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelPayments.Location = new System.Drawing.Point(26, 134);
            this.labelPayments.Name = "labelPayments";
            this.labelPayments.Size = new System.Drawing.Size(263, 25);
            this.labelPayments.TabIndex = 37;
            this.labelPayments.Text = "Платежей за период: 32";
            // 
            // jeanModernButtonRefresh
            // 
            this.jeanModernButtonRefresh.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.jeanModernButtonRefresh.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonRefresh.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonRefresh.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButtonRefresh.BorderRadius = 20;
            this.jeanModernButtonRefresh.BorderSize = 2;
            this.jeanModernButtonRefresh.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonRefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonRefresh.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonRefresh.Location = new System.Drawing.Point(624, 611);
            this.jeanModernButtonRefresh.Name = "jeanModernButtonRefresh";
            this.jeanModernButtonRefresh.Size = new System.Drawing.Size(150, 45);
            this.jeanModernButtonRefresh.TabIndex = 38;
            this.jeanModernButtonRefresh.Text = "Обновить";
            this.jeanModernButtonRefresh.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonRefresh.UseVisualStyleBackColor = false;
            this.jeanModernButtonRefresh.Click += new System.EventHandler(this.jeanModernButtonRefresh_Click);
            // 
            // jeanFormStyle
            // 
            this.jeanFormStyle.AllowUserResize = false;
            this.jeanFormStyle.BackColor = System.Drawing.Color.White;
            this.jeanFormStyle.ContextMenuForm = null;
            this.jeanFormStyle.ControlBoxButtonsWidth = 20;
            this.jeanFormStyle.EnableControlBoxIconsLight = false;
            this.jeanFormStyle.EnableControlBoxMouseLight = false;
            this.jeanFormStyle.Form = this;
            this.jeanFormStyle.FormStyle = GymApplicationV2._0.Components.JeanFormStyle.fStyle.None;
            this.jeanFormStyle.HeaderColor = System.Drawing.Color.Black;
            this.jeanFormStyle.HeaderColorAdditional = System.Drawing.Color.DarkOrange;
            this.jeanFormStyle.HeaderColorGradientEnable = true;
            this.jeanFormStyle.HeaderColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.jeanFormStyle.HeaderHeight = 30;
            this.jeanFormStyle.HeaderImage = null;
            this.jeanFormStyle.HeaderTextColor = System.Drawing.Color.White;
            this.jeanFormStyle.HeaderTextFont = new System.Drawing.Font("Segoe UI", 9.75F);
            // 
            // HistoryPayment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1241, 743);
            this.Controls.Add(this.jeanModernButtonRefresh);
            this.Controls.Add(this.labelPayments);
            this.Controls.Add(this.jeanModernButtonShow);
            this.Controls.Add(this.radioOtherPeriod);
            this.Controls.Add(this.labelTo);
            this.Controls.Add(this.labelWith);
            this.Controls.Add(this.dateTimePickerEnd);
            this.Controls.Add(this.dateTimePickerBegin);
            this.Controls.Add(this.radioForWeek);
            this.Controls.Add(this.radioForDay);
            this.Controls.Add(this.radioForMonth);
            this.Controls.Add(this.dataGridViewHistory);
            this.Name = "HistoryPayment";
            this.Text = "HistoryPayment";
            this.Load += new System.EventHandler(this.HistoryPayment_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHistory)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        protected internal System.Windows.Forms.DataGridView dataGridViewHistory;
        private System.Windows.Forms.RadioButton radioForMonth;
        private System.Windows.Forms.RadioButton radioForDay;
        private System.Windows.Forms.RadioButton radioOtherPeriod;
        private System.Windows.Forms.DateTimePicker dateTimePickerBegin;
        private System.Windows.Forms.DateTimePicker dateTimePickerEnd;
        private System.Windows.Forms.Label labelWith;
        private System.Windows.Forms.Label labelTo;
        private System.Windows.Forms.RadioButton radioForWeek;
        private Controls.JeanModernButton jeanModernButtonShow;
        private System.Windows.Forms.Label labelPayments;
        private Controls.JeanModernButton jeanModernButtonRefresh;
        private Components.JeanFormStyle jeanFormStyle;
    }
}