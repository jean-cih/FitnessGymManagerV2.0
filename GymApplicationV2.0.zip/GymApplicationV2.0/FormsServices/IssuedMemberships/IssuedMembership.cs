﻿using GymApplicationV2._0.Components;
using GymApplicationV2._0.Connections;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymApplicationV2._0.FormsServices.IssuedMemberships
{
    public partial class IssuedMembership : Form
    {
        public IssuedMembership()
        {
            InitializeComponent();
        }

        private void IssuedMembership_Load(object sender, EventArgs e)
        {
            dataGridViewIssued.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            JeanFormStyle.fStyle style = JeanFormStyle.fStyle.None;
            if (DataClass.styleForm == "UserStyle")
            {
                style = JeanFormStyle.fStyle.UserStyle;
            }
            else if (DataClass.styleForm == "SimpleDark")
            {
                style = JeanFormStyle.fStyle.SimpleDark;
            }
            else if (DataClass.styleForm == "TelegramStyle")
            {
                style = JeanFormStyle.fStyle.TelegramStyle;
            }

            jeanFormStyle.FormStyle = style;

            dataGridViewIssued.DataSource = IssuedMembershipContext.GetDataFromDatabase("SELECT * FROM Issued");

            dataGridViewIssued.DefaultCellStyle.Font = new Font("Issued", DataClass.sizeFontTables);
            dataGridViewIssued.ColumnHeadersDefaultCellStyle.Font = new Font("Issued", DataClass.sizeFontTables);
        }

        private void jeanModernButtonRefresh_Click(object sender, EventArgs e)
        {
            dataGridViewIssued.DataSource = IssuedMembershipContext.GetDataFromDatabase("SELECT * FROM Issued");
        }

        private void jeanModernButtonErase_Click(object sender, EventArgs e)
        {
            jeanSoftTextBoxSearch.Texts = "";
        }

        private void jeanSoftTextBoxSearch__TextChanged(object sender, EventArgs e)
        {
            if (jeanSoftTextBoxSearch.Texts.Length > 0)
            {
                jeanModernButtonErase.Visible = true;
            }
            else
            {
                jeanModernButtonErase.Visible = false;
                dataGridViewIssued.DataSource = IssuedMembershipContext.GetDataFromDatabase("SELECT * FROM Issued");
                return;
            }

            dataGridViewIssued.DataSource = IssuedMembershipContext.GetDataFromDatabase($"" +
                    $"SELECT * " +
                    $"FROM Issued " +
                    $"WHERE №Карты LIKE '%{jeanSoftTextBoxSearch.Texts}%' " +
                    $"OR Клиент LIKE '%{jeanSoftTextBoxSearch.Texts}%'");
        }

        private void jeanModernButtonFreeze_Click(object sender, EventArgs e)
        {

            Regex regex = new Regex(@"^\d{13}$");
            if (!regex.IsMatch(numberCard))
            {
                Message.MessageWindowOk("Выберете номер клиента из таблицы");
                return;
            }

            object status = IssuedMembershipContext.GetElementIssued("SELECT Статус FROM Issued WHERE №Карты = '" + numberCard + "';");

            if (status.ToString() == "заморожен")
            {
                Message.MessageWindowOk("Абонемент уже заморожен");
                return;
            }

            DialogResult result = Message.MessageWindowYesNo("Заморозить абонемент");

            if(result == DialogResult.No)
            {
                return;
            }

            IssuedMembershipContext.CommandDataIssued("UPDATE Issued SET " +
                    "Статус = '" + "заморожен" + "', " +
                    "Дата_окончания = '" + Convert.ToDateTime(dateOver).Add(new TimeSpan(60, 0, 0, 0)).ToShortDateString() + "' " +
                    "WHERE №Карты = '" + numberCard + "';");

            Message.MessageWindowOk("Абонемент заморожен");

            dataGridViewIssued.DataSource = IssuedMembershipContext.GetDataFromDatabase("SELECT * FROM Issued");
        }

        string numberCard = "", dateOver;

        private void dataGridViewIssued_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            jeanSoftTextBoxSearch.Texts = dataGridViewIssued.SelectedRows[0].Cells[2].Value.ToString();
            numberCard = dataGridViewIssued.SelectedRows[0].Cells[2].Value.ToString();
            dateOver = dataGridViewIssued.SelectedRows[0].Cells[3].Value.ToString();
        }
    }
}
