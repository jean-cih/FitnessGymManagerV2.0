﻿using GymApplicationV2._0.Components;
using GymApplicationV2._0.Connections;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace GymApplicationV2._0.FormsServices.IssuedMemberships
{
    public partial class IssuedMembership : Form
    {
        private ToolStripDropDownMenu _menu;
        public IssuedMembership()
        {
            InitializeComponent();

            jeanModernButtonChangeData.Click += Button_Click;
            Controls.Add(jeanModernButtonChangeData);

            _menu = new ToolStripDropDownMenu();
            _menu.Font = new System.Drawing.Font("Arial", 12, FontStyle.Regular);
            ToolStripMenuItem item1 = new ToolStripMenuItem("Заморозить", Properties.Resources.Freeze);
            ToolStripMenuItem item2 = new ToolStripMenuItem("Изменить параметры", Properties.Resources.change);
            _menu.Items.Add(item1);
            _menu.Items.Add(item2);

            _menu.Items[0].Click += jeanModernButtonFreeze_Click;
            _menu.Items[1].Click += jeanModernButtonChange_Click;
        }

        private void Button_Click(object sender, EventArgs e)
        {
            _menu.Show(jeanModernButtonChangeData, new Point(0, jeanModernButtonChangeData.Height));
        }

        private void IssuedMembership_Load(object sender, EventArgs e)
        {
            this.Width = Convert.ToInt32(Screen.PrimaryScreen.Bounds.Width * 0.75);
            this.Height = Convert.ToInt32(Screen.PrimaryScreen.Bounds.Height * 0.75);

            jeanPanel.Size = new Size(this.Width - 40, this.Height - 180);
            jeanSoftTextBoxSearch.Location = new System.Drawing.Point(this.Width / 2 - 150, 55);
            jeanModernButtonErase.Location = new System.Drawing.Point(this.Width / 2 - 150 + 260, 60);
            pictureBoxSearch.Location = new System.Drawing.Point(this.Width / 2 - 140, 60);
            jeanModernButtonChangeData.Location = new System.Drawing.Point(this.Width - 150, 55);

            dataGridViewIssued.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            JeanFormStyle.fStyle style = JeanFormStyle.fStyle.None;
            if (DataClass.styleForm == "UserStyle")
            {
                style = JeanFormStyle.fStyle.UserStyle;
            }
            else if (DataClass.styleForm == "SimpleDark")
            {
                style = JeanFormStyle.fStyle.SimpleDark;
            }
            else if (DataClass.styleForm == "TelegramStyle")
            {
                style = JeanFormStyle.fStyle.TelegramStyle;
            }

            jeanFormStyle.FormStyle = style;

            dataGridViewIssued.DataSource = IssuedMembershipContext.GetDataFromDatabase("SELECT * FROM Issued");

            dataGridViewIssued.DefaultCellStyle.Font = new Font("Issued", DataClass.sizeFontTables);
            dataGridViewIssued.ColumnHeadersDefaultCellStyle.Font = new Font("Issued", DataClass.sizeFontTables);
        }

        private void jeanModernButtonRefresh_Click(object sender, EventArgs e)
        {
            dataGridViewIssued.DataSource = IssuedMembershipContext.GetDataFromDatabase("SELECT * FROM Issued");
        }

        private void jeanModernButtonErase_Click(object sender, EventArgs e)
        {
            jeanSoftTextBoxSearch.Texts = "";
        }

        private void jeanSoftTextBoxSearch__TextChanged(object sender, EventArgs e)
        {
            if (jeanSoftTextBoxSearch.Texts.Length > 0)
            {
                jeanModernButtonErase.Visible = true;
            }
            else
            {
                jeanModernButtonErase.Visible = false;
                dataGridViewIssued.DataSource = IssuedMembershipContext.GetDataFromDatabase("SELECT * FROM Issued");
                return;
            }

            dataGridViewIssued.DataSource = IssuedMembershipContext.GetDataFromDatabase($"" +
                    $"SELECT * " +
                    $"FROM Issued " +
                    $"WHERE №Карты LIKE '%{jeanSoftTextBoxSearch.Texts}%' " +
                    $"OR Клиент LIKE '%{jeanSoftTextBoxSearch.Texts}%'");
        }

        string numberCard = "", dateOver;
        private void dataGridViewIssued_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            jeanSoftTextBoxSearch.Texts = dataGridViewIssued.SelectedRows[0].Cells[2].Value.ToString();
            numberCard = dataGridViewIssued.SelectedRows[0].Cells[2].Value.ToString();
            dateOver = dataGridViewIssued.SelectedRows[0].Cells[3].Value.ToString();
        }

        private void jeanModernButtonFreeze_Click(object sender, EventArgs e)
        {
            Regex regex = new Regex(@"^\d{13}$");
            if (!regex.IsMatch(numberCard))
            {
                Message.MessageWindowOk("Выберете номер клиента из таблицы");
                return;
            }

            object status = IssuedMembershipContext.GetElementIssued("SELECT Статус FROM Issued WHERE №Карты = '" + numberCard + "';");
            object name = IssuedMembershipContext.GetElementIssued("SELECT Клиент FROM Issued WHERE №Карты = '" + numberCard + "';");

            if (status.ToString() == "заморожен")
            {
                Message.MessageWindowOk("Абонемент уже заморожен\n " + name.ToString());
                return;
            }

            DialogResult result = Message.MessageWindowYesNo("Заморозить абонемент\n " + name.ToString());

            if(result == DialogResult.No)
            {
                return;
            }

            IssuedMembershipContext.CommandDataIssued("UPDATE Issued SET " +
                    "Статус = '" + "заморожен" + "', " +
                    "Дата_окончания = '" + Convert.ToDateTime(dateOver).Add(new TimeSpan(60, 0, 0, 0)).ToShortDateString() + "', " +
                    "Окончание_заморозки = '" + Convert.ToDateTime(dateOver).Add(new TimeSpan(60, 0, 0, 0)).ToShortDateString() + "' " +
                    "WHERE №Карты = '" + numberCard + "';");

            Message.MessageWindowOk("Абонемент заморожен");

            dataGridViewIssued.DataSource = IssuedMembershipContext.GetDataFromDatabase("SELECT * FROM Issued");
        }

        private void jeanModernButtonChangeData_Click(object sender, EventArgs e)
        {

        }

        private void jeanModernButtonChange_Click(object sender, EventArgs e)
        {
            /*
            Regex regex = new Regex(@"^\d{13}$");
            if (!regex.IsMatch(numberCard))
            {
                Message.MessageWindowOk("Выберете номер клиента из таблицы");
                return;
            }

            ChangeArchiveService changeArchiveService = new ChangeArchiveService();
            changeArchiveService.jeanSoftTextBoxClient.Texts = client;
            changeArchiveService.jeanSoftTextBoxCard.Texts = numberCard;
            changeArchiveService.jeanSoftTextBoxMembership.Texts = membership;
            changeArchiveService.jeanSoftTextBoxTerm.Texts = term;
            changeArchiveService.jeanSoftTextBoxCost.Texts = cost;
            changeArchiveService.jeanSoftTextBoxVisits.Texts = visits;
            changeArchiveService.ShowDialog();

            dataGridViewArchive.DataSource = ArchiveServicesContext.GetDataFromDatabase("SELECT Клиент, №Карты, Дата_окончания, Абонемент, Оплата, Посещений_осталось FROM Archive");
            */        
        }
    }
}
