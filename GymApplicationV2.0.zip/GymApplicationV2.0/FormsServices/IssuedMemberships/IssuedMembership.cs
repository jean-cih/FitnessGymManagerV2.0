﻿using GymApplicationV2._0.Components;
using GymApplicationV2._0.Connections;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymApplicationV2._0.FormsServices.IssuedMemberships
{
    public partial class IssuedMembership : Form
    {
        public IssuedMembership()
        {
            InitializeComponent();
        }

        private void IssuedMembership_Load(object sender, EventArgs e)
        {
            dataGridViewIssued.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            JeanFormStyle.fStyle style = JeanFormStyle.fStyle.None;
            if (DataClass.styleForm == "UserStyle")
            {
                style = JeanFormStyle.fStyle.UserStyle;
            }
            else if (DataClass.styleForm == "SimpleDark")
            {
                style = JeanFormStyle.fStyle.SimpleDark;
            }
            else if (DataClass.styleForm == "TelegramStyle")
            {
                style = JeanFormStyle.fStyle.TelegramStyle;
            }

            jeanFormStyle.FormStyle = style;

            dataGridViewIssued.DataSource = IssuedMembershipContext.GetDataFromDatabase("SELECT * FROM Issued");

            dataGridViewIssued.DefaultCellStyle.Font = new Font("Issued", DataClass.sizeFontTables);
            dataGridViewIssued.ColumnHeadersDefaultCellStyle.Font = new Font("Issued", DataClass.sizeFontTables);
        }

        private void jeanModernButtonRefresh_Click(object sender, EventArgs e)
        {

        }

        private void jeanModernButtonErase_Click(object sender, EventArgs e)
        {

        }

        private void jeanSoftTextBoxSearch__TextChanged(object sender, EventArgs e)
        {

        }

        private void jeanModernButtonFreeze_Click(object sender, EventArgs e)
        {

        }
    }
}
