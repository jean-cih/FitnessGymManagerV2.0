﻿namespace GymApplicationV2._0
{
    partial class ChangeService
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridViewService = new System.Windows.Forms.DataGridView();
            this.jeanModernButtonSave = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanSoftTextBoxName = new GymApplicationV2._0.Controls.jeanSoftTextBox();
            this.jeanSoftTextBoxPrice = new GymApplicationV2._0.Controls.jeanSoftTextBox();
            this.jeanSoftTextBoxQuantity = new GymApplicationV2._0.Controls.jeanSoftTextBox();
            this.jeanSoftTextBoxTerm = new GymApplicationV2._0.Controls.jeanSoftTextBox();
            this.jeanFormStyle = new GymApplicationV2._0.Components.JeanFormStyle(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewService)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewService
            // 
            this.dataGridViewService.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridViewService.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewService.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewService.GridColor = System.Drawing.Color.Gainsboro;
            this.dataGridViewService.Location = new System.Drawing.Point(352, 107);
            this.dataGridViewService.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridViewService.Name = "dataGridViewService";
            this.dataGridViewService.ReadOnly = true;
            this.dataGridViewService.RowHeadersWidth = 51;
            this.dataGridViewService.RowTemplate.Height = 24;
            this.dataGridViewService.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewService.Size = new System.Drawing.Size(417, 193);
            this.dataGridViewService.TabIndex = 10;
            // 
            // jeanModernButtonSave
            // 
            this.jeanModernButtonSave.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonSave.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonSave.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButtonSave.BorderRadius = 20;
            this.jeanModernButtonSave.BorderSize = 2;
            this.jeanModernButtonSave.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonSave.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonSave.Location = new System.Drawing.Point(325, 366);
            this.jeanModernButtonSave.Name = "jeanModernButtonSave";
            this.jeanModernButtonSave.Size = new System.Drawing.Size(150, 55);
            this.jeanModernButtonSave.TabIndex = 55;
            this.jeanModernButtonSave.Text = "Сохранить";
            this.jeanModernButtonSave.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonSave.UseVisualStyleBackColor = false;
            this.jeanModernButtonSave.Click += new System.EventHandler(this.jeanModernButtonSave_Click);
            // 
            // jeanSoftTextBoxName
            // 
            this.jeanSoftTextBoxName.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanSoftTextBoxName.BorderFocusColor = System.Drawing.Color.HotPink;
            this.jeanSoftTextBoxName.BorderRadius = 0;
            this.jeanSoftTextBoxName.BorderSize = 2;
            this.jeanSoftTextBoxName.Location = new System.Drawing.Point(24, 107);
            this.jeanSoftTextBoxName.Margin = new System.Windows.Forms.Padding(4);
            this.jeanSoftTextBoxName.Multiline = false;
            this.jeanSoftTextBoxName.Name = "jeanSoftTextBoxName";
            this.jeanSoftTextBoxName.Padding = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.jeanSoftTextBoxName.PasswordChar = false;
            this.jeanSoftTextBoxName.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.jeanSoftTextBoxName.PlaceholderText = "";
            this.jeanSoftTextBoxName.Size = new System.Drawing.Size(303, 40);
            this.jeanSoftTextBoxName.TabIndex = 56;
            this.jeanSoftTextBoxName.Texts = "";
            this.jeanSoftTextBoxName.UnderlinedStyle = false;
            // 
            // jeanSoftTextBoxPrice
            // 
            this.jeanSoftTextBoxPrice.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanSoftTextBoxPrice.BorderFocusColor = System.Drawing.Color.HotPink;
            this.jeanSoftTextBoxPrice.BorderRadius = 0;
            this.jeanSoftTextBoxPrice.BorderSize = 2;
            this.jeanSoftTextBoxPrice.Location = new System.Drawing.Point(24, 157);
            this.jeanSoftTextBoxPrice.Margin = new System.Windows.Forms.Padding(4);
            this.jeanSoftTextBoxPrice.Multiline = false;
            this.jeanSoftTextBoxPrice.Name = "jeanSoftTextBoxPrice";
            this.jeanSoftTextBoxPrice.Padding = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.jeanSoftTextBoxPrice.PasswordChar = false;
            this.jeanSoftTextBoxPrice.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.jeanSoftTextBoxPrice.PlaceholderText = "";
            this.jeanSoftTextBoxPrice.Size = new System.Drawing.Size(303, 40);
            this.jeanSoftTextBoxPrice.TabIndex = 57;
            this.jeanSoftTextBoxPrice.Texts = "";
            this.jeanSoftTextBoxPrice.UnderlinedStyle = false;
            // 
            // jeanSoftTextBoxQuantity
            // 
            this.jeanSoftTextBoxQuantity.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanSoftTextBoxQuantity.BorderFocusColor = System.Drawing.Color.HotPink;
            this.jeanSoftTextBoxQuantity.BorderRadius = 0;
            this.jeanSoftTextBoxQuantity.BorderSize = 2;
            this.jeanSoftTextBoxQuantity.Location = new System.Drawing.Point(24, 260);
            this.jeanSoftTextBoxQuantity.Margin = new System.Windows.Forms.Padding(4);
            this.jeanSoftTextBoxQuantity.Multiline = false;
            this.jeanSoftTextBoxQuantity.Name = "jeanSoftTextBoxQuantity";
            this.jeanSoftTextBoxQuantity.Padding = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.jeanSoftTextBoxQuantity.PasswordChar = false;
            this.jeanSoftTextBoxQuantity.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.jeanSoftTextBoxQuantity.PlaceholderText = "";
            this.jeanSoftTextBoxQuantity.Size = new System.Drawing.Size(303, 40);
            this.jeanSoftTextBoxQuantity.TabIndex = 59;
            this.jeanSoftTextBoxQuantity.Texts = "";
            this.jeanSoftTextBoxQuantity.UnderlinedStyle = false;
            // 
            // jeanSoftTextBoxTerm
            // 
            this.jeanSoftTextBoxTerm.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanSoftTextBoxTerm.BorderFocusColor = System.Drawing.Color.HotPink;
            this.jeanSoftTextBoxTerm.BorderRadius = 0;
            this.jeanSoftTextBoxTerm.BorderSize = 2;
            this.jeanSoftTextBoxTerm.Location = new System.Drawing.Point(24, 209);
            this.jeanSoftTextBoxTerm.Margin = new System.Windows.Forms.Padding(4);
            this.jeanSoftTextBoxTerm.Multiline = false;
            this.jeanSoftTextBoxTerm.Name = "jeanSoftTextBoxTerm";
            this.jeanSoftTextBoxTerm.Padding = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.jeanSoftTextBoxTerm.PasswordChar = false;
            this.jeanSoftTextBoxTerm.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.jeanSoftTextBoxTerm.PlaceholderText = "";
            this.jeanSoftTextBoxTerm.Size = new System.Drawing.Size(303, 40);
            this.jeanSoftTextBoxTerm.TabIndex = 58;
            this.jeanSoftTextBoxTerm.Texts = "";
            this.jeanSoftTextBoxTerm.UnderlinedStyle = false;
            // 
            // jeanFormStyle
            // 
            this.jeanFormStyle.AllowUserResize = false;
            this.jeanFormStyle.BackColor = System.Drawing.Color.White;
            this.jeanFormStyle.ContextMenuForm = null;
            this.jeanFormStyle.ControlBoxButtonsWidth = 20;
            this.jeanFormStyle.EnableControlBoxIconsLight = false;
            this.jeanFormStyle.EnableControlBoxMouseLight = false;
            this.jeanFormStyle.Form = this;
            this.jeanFormStyle.FormStyle = GymApplicationV2._0.Components.JeanFormStyle.fStyle.None;
            this.jeanFormStyle.HeaderColor = System.Drawing.Color.Black;
            this.jeanFormStyle.HeaderColorAdditional = System.Drawing.Color.DarkOrange;
            this.jeanFormStyle.HeaderColorGradientEnable = true;
            this.jeanFormStyle.HeaderColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.jeanFormStyle.HeaderHeight = 30;
            this.jeanFormStyle.HeaderImage = null;
            this.jeanFormStyle.HeaderTextColor = System.Drawing.Color.White;
            this.jeanFormStyle.HeaderTextFont = new System.Drawing.Font("Segoe UI", 9.75F);
            // 
            // ChangeService
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.jeanSoftTextBoxQuantity);
            this.Controls.Add(this.jeanSoftTextBoxTerm);
            this.Controls.Add(this.jeanSoftTextBoxPrice);
            this.Controls.Add(this.jeanSoftTextBoxName);
            this.Controls.Add(this.jeanModernButtonSave);
            this.Controls.Add(this.dataGridViewService);
            this.Name = "ChangeService";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ChangeService";
            this.Load += new System.EventHandler(this.ChangeService_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewService)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewService;
        protected internal Controls.JeanModernButton jeanModernButtonSave;
        private Controls.jeanSoftTextBox jeanSoftTextBoxName;
        private Controls.jeanSoftTextBox jeanSoftTextBoxPrice;
        private Controls.jeanSoftTextBox jeanSoftTextBoxQuantity;
        private Controls.jeanSoftTextBox jeanSoftTextBoxTerm;
        private Components.JeanFormStyle jeanFormStyle;
    }
}