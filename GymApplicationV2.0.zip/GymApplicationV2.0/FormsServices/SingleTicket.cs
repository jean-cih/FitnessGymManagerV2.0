﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Data.SQLite;
using GymApplicationV2._0.Components;

namespace GymApplicationV2._0
{
    public partial class SingleTicket : Form
    {
        public SingleTicket()
        {
            InitializeComponent();
        }

        private void SingleTicket_Load(object sender, EventArgs e)
        {
            JeanFormStyle.fStyle style = JeanFormStyle.fStyle.None;
            if (DataClass.styleForm == "UserStyle")
            {
                style = JeanFormStyle.fStyle.UserStyle;
            }
            else if (DataClass.styleForm == "SimpleDark")
            {
                style = JeanFormStyle.fStyle.SimpleDark;
            }
            else if (DataClass.styleForm == "TelegramStyle")
            {
                style = JeanFormStyle.fStyle.TelegramStyle;
            }

            jeanFormStyle.FormStyle = style;

            CheckIfDataExists();
            jeanModernButtonRefresh.Font = new Font("Обновить", DataClass.sizeFontButtons);
            jeanModernButtonSell.Font = new Font("Продать", DataClass.sizeFontButtons);

            dataGridViewClients.DefaultCellStyle.Font = new Font("Contacts", DataClass.sizeFontTables);
            dataGridViewClients.ColumnHeadersDefaultCellStyle.Font = new Font("Contacts", DataClass.sizeFontTables);

            checkBoxVisited.Font = new Font("Отметить посещение сразу", DataClass.sizeFontCaptions - 2);
        }

        private void CheckIfDataExists()
        {
            if (!File.Exists("Databases\\Clients.db"))
            {
                ClientsContext.CreatingDatabase();
            }
            else
            {
                dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts");
            }
        }

        int key = 0;
        string card = "";
        string surname = "";
        string name = "";
        string fatherName = "";
        private void dataGridViewClients_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            key = Convert.ToInt32(dataGridViewClients.SelectedRows[0].Cells[0].Value.ToString());
            surname = dataGridViewClients.SelectedRows[0].Cells[1].Value.ToString();
            name = dataGridViewClients.SelectedRows[0].Cells[2].Value.ToString();
            fatherName = dataGridViewClients.SelectedRows[0].Cells[11].Value.ToString();
            card = dataGridViewClients.SelectedRows[0].Cells[5].Value.ToString();
            jeanModernButtonSell.Text = "Продать\n" + name + " " + surname;
        }

        private void buttonSell_Click(object sender, EventArgs e)
        {
            if (key == 0)
            {
                Message.MessageWindowOk("Выберете клиента");
                return;
            }

            object purchase = ClientsContext.GetElementClient("SELECT Покупки FROM Contacts WHERE №Карты = '" + card + "';");

            int costs = 0;
            if (purchase != null)
                costs = Convert.ToInt32(purchase);

            int markVisited = 1;
            if(checkBoxVisited.Checked)
                markVisited = 0;

            ClientsContext.CommandDataClient("UPDATE Contacts SET " +
                    "Покупки = '" + (costs + 250).ToString() + "'," +
                    "Абонемент = '" + "Разовое" + "'," +
                    "Посещений_осталось = '" + markVisited + "' " +
                    "WHERE Id = '" + key + "';");

            //Получение максимального id клиента
            SQLiteConnection conn3 = new SQLiteConnection(HistoryPaymentContext.ConnectionStringPayment());
            conn3.Open();

            SQLiteCommand cmd3 = new SQLiteCommand("SELECT Id FROM History", conn3);
            SQLiteDataReader reader3 = cmd3.ExecuteReader();

            object idPay = null;
            while (reader3.Read())
            {
                idPay = reader3[0];
            }

            reader3.Close();
            cmd3.Dispose();
            conn3.Close();

            int numberPay;
            if (idPay != null)
                numberPay = Convert.ToInt32(idPay) + 1;
            else
                numberPay = 1;

            using (SQLiteConnection conn = new SQLiteConnection(HistoryPaymentContext.ConnectionStringPayment()))
            {
                //Добавить абонемент
                string commandStringNew = "INSERT INTO History (" +
                "[Id],[ФИО],[Абонемент],[Дата_начала],[Дата_окончания],[Цена],[Дата_платежа])" +
                " VALUES (@Id,@ФИО,@Абонемент,@Дата_начала,@Дата_окончания,@Цена,@Дата_платежа)";

                using (SQLiteCommand cmd = new SQLiteCommand(commandStringNew, conn))
                {
                    conn.Open();

                    cmd.Parameters.AddWithValue("@Id", numberPay);
                    cmd.Parameters.AddWithValue("@ФИО", surname + " " + name + " " + fatherName);
                    cmd.Parameters.AddWithValue("@Абонемент", "Разовое");
                    cmd.Parameters.AddWithValue("@Дата_начала", "");
                    cmd.Parameters.AddWithValue("@Дата_окончания", "");
                    cmd.Parameters.AddWithValue("@Цена", 250);
                    cmd.Parameters.AddWithValue("@Дата_платежа", DateTime.Now.ToShortDateString());

                    cmd.ExecuteNonQuery();
                }
            }

            Message.MessageWindowOk("Разовое посещение продано");
        }

        private void jeanModernButtonRefresh_Click(object sender, EventArgs e)
        {
            jeanSoftTextBoxSearch.Texts = "";
            dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts");
        }

        private void jeanSoftTextBoxSearch__TextChanged(object sender, EventArgs e)
        {
            if (jeanSoftTextBoxSearch.Texts.Length > 0)
            {
                jeanModernButtonErase.Visible = true;
            }
            else
            {
                jeanModernButtonErase.Visible = false;
                dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts");
                return;
            }

            string[] fullName = jeanSoftTextBoxSearch.Texts.Split(' ');
            fullName[0] = Char.ToUpper(fullName[0][0]) + fullName[0].Substring(1);
            try
            {
                fullName[1] = Char.ToUpper(fullName[1][0]) + fullName[1].Substring(1);

                dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase($"" +
                    $"SELECT * " +
                    $"FROM Contacts " +
                    $"WHERE №Карты LIKE '%{fullName[0]}%' " +
                    $"OR Фамилия LIKE '%{fullName[0]}%' " +
                    $"AND Имя LIKE '%{fullName[1]}%'");
            }
            catch
            {
                dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase($"" +
                    $"SELECT * " +
                    $"FROM Contacts " +
                    $"WHERE №Карты LIKE '%{fullName[0]}%' " +
                    $"OR Фамилия LIKE '%{fullName[0]}%' " +
                    $"OR Имя LIKE '%{fullName[0]}%'");
            }
        }

        private void jeanModernButtonErase_Click(object sender, EventArgs e)
        {
            jeanSoftTextBoxSearch.Texts = "";
        }
    }
}
