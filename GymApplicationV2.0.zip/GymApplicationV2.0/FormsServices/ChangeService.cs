﻿using GymApplicationV2._0.Components;
using Microsoft.Office.Interop.Excel;
using Shadow;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace GymApplicationV2._0
{
    public partial class ChangeService : ShadowedForm
    {
        public ChangeService()
        {
            InitializeComponent();
        }

        private bool isMousePress = false;
        private System.Drawing.Point _clickPoint;
        private System.Drawing.Point _formStartPoint;

        private void ChangeService_MouseDown(object sender, MouseEventArgs e)
        {
            isMousePress = true;
            _clickPoint = Cursor.Position;
            _formStartPoint = Location;
        }

        private void ChangeService_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMousePress)
            {
                var cursorOffsetPoint = new System.Drawing.Point(
                    Cursor.Position.X - _clickPoint.X,
                    Cursor.Position.Y - _clickPoint.Y);

                Location = new System.Drawing.Point(
                    _formStartPoint.X + cursorOffsetPoint.X,
                    _formStartPoint.Y + cursorOffsetPoint.Y);
            }
        }

        private void ChangeService_MouseUp(object sender, MouseEventArgs e)
        {
            isMousePress = false;
            _clickPoint = System.Drawing.Point.Empty;
        }

        private void ChangeService_Load(object sender, EventArgs e)
        {
            dataGridViewService.DataSource = ServicesContext.GetDataFromDatabase("SELECT Наименование, Цена, СрокДействия, Количество FROM Descriptions WHERE Наименование = '" + DataClass.nameMembership + "';");
            jeanSoftTextBoxName.Texts = DataClass.nameMembership;
            jeanSoftTextBoxPrice.Texts = dataGridViewService.SelectedRows[0].Cells[1].Value.ToString();
            jeanSoftTextBoxTerm.Texts = dataGridViewService.SelectedRows[0].Cells[2].Value.ToString();
            jeanSoftTextBoxQuantity.Texts = dataGridViewService.SelectedRows[0].Cells[3].Value.ToString();
        }

        private void jeanModernButtonSave_Click(object sender, EventArgs e)
        {
            ServicesContext.CommandDataServices("UPDATE Descriptions SET " +
                    "Наименование = '" + jeanSoftTextBoxName.Texts.Trim() + "'," +
                    "Цена = '" + jeanSoftTextBoxPrice.Texts.Trim() + "'," +
                    "СрокДействия = '" + jeanSoftTextBoxTerm.Texts.Trim() + "'," +
                    "Количество = '" + jeanSoftTextBoxQuantity.Texts.Trim() + "' " +
                    "WHERE Наименование = '" + DataClass.nameMembership + "';");

            DataClass.nameMembership = jeanSoftTextBoxName.Texts;

            Message.MessageWindowOk("Абонемент изменен");

            dataGridViewService.DataSource = ServicesContext.GetDataFromDatabase("SELECT Наименование, Цена, СрокДействия, Количество FROM Descriptions WHERE Наименование = '" + DataClass.nameMembership + "';");
        }

        private void jeanModernButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
