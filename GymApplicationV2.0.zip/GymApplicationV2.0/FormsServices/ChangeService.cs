﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace GymApplicationV2._0
{
    public partial class ChangeService : Form
    {
        public ChangeService()
        {
            InitializeComponent();
        }

        private void ChangeService_Load(object sender, EventArgs e)
        {
            dataGridViewService.DataSource = ServicesContext.GetDataFromDatabase("SELECT Наименование, Цена, СрокДействия, Количество FROM Descriptions WHERE Наименование = '" + DataClass.nameMembership + "';");
            jeanSoftTextBoxName.Texts = DataClass.nameMembership;
            jeanSoftTextBoxPrice.Texts = dataGridViewService.SelectedRows[0].Cells[1].Value.ToString();
            jeanSoftTextBoxTerm.Texts = dataGridViewService.SelectedRows[0].Cells[2].Value.ToString();
            jeanSoftTextBoxQuantity.Texts = dataGridViewService.SelectedRows[0].Cells[3].Value.ToString();
        }

        private void jeanModernButtonSave_Click(object sender, EventArgs e)
        {
            ServicesContext.CommandDataServices("UPDATE Descriptions SET " +
                    "Наименование = '" + jeanSoftTextBoxName.Texts.Trim() + "'," +
                    "Цена = '" + jeanSoftTextBoxPrice.Texts.Trim() + "'," +
                    "СрокДействия = '" + jeanSoftTextBoxTerm.Texts.Trim() + "'," +
                    "Количество = '" + jeanSoftTextBoxQuantity.Texts.Trim() + "' " +
                    "WHERE Наименование = '" + DataClass.nameMembership + "';");

            DataClass.nameMembership = jeanSoftTextBoxName.Texts;

            Message.MessageWindowOk("Абонемент изменен");

            dataGridViewService.DataSource = ServicesContext.GetDataFromDatabase("SELECT Наименование, Цена, СрокДействия, Количество FROM Descriptions WHERE Наименование = '" + DataClass.nameMembership + "';");
        }
    }
}
