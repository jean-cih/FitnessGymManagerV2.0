﻿using GymApplicationV2._0.Components;
using Shadow;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymApplicationV2._0
{
    public partial class FieldForService : ShadowedForm
    {
        public FieldForService()
        {
            InitializeComponent();
        }

        private bool isMousePress = false;
        private System.Drawing.Point _clickPoint;
        private System.Drawing.Point _formStartPoint;

        private void FieldForService_MouseDown(object sender, MouseEventArgs e)
        {
            isMousePress = true;
            _clickPoint = Cursor.Position;
            _formStartPoint = Location;
        }

        private void FieldForService_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMousePress)
            {
                var cursorOffsetPoint = new System.Drawing.Point(
                    Cursor.Position.X - _clickPoint.X,
                    Cursor.Position.Y - _clickPoint.Y);

                Location = new System.Drawing.Point(
                    _formStartPoint.X + cursorOffsetPoint.X,
                    _formStartPoint.Y + cursorOffsetPoint.Y);
            }
        }

        private void FieldForService_MouseUp(object sender, MouseEventArgs e)
        {
            isMousePress = false;
            _clickPoint = System.Drawing.Point.Empty;
        }

        private void FieldForService_Load(object sender, EventArgs e)
        {
            jeanModernButtonAdd.Font = new Font("Добавить", DataClass.sizeFontButtons);
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            if (jeanTextBoxName.Text == "" || jeanTextBoxPrice.Text == "" || jeanTextBoxTerm.Text == "")
            {
                Message.MessageWindowOk("Незаполненные поля");
 
                return;
            }

            if (jeanTextBoxName.Text.Length > 100 || jeanTextBoxPrice.Text.Length > 20 || (jeanTextBoxVisited.Text != "" && jeanTextBoxVisited.Text.Length > 20))
            {
                Message.MessageWindowOk("Превышен лимит количества символов");

                return;
            }

            if (!int.TryParse(jeanTextBoxTerm.Text, out int term) || term < 0 || !int.TryParse(jeanTextBoxPrice.Text, out int cost) || cost < 0 || ((!int.TryParse(jeanTextBoxVisited.Text, out int quantity) || quantity < 0) && jeanTextBoxVisited.Text != ""))
            {
                Message.MessageWindowOk("Поля \"Цена\", \"Срок\" и \"Кол-во\" должны быть положительными числами");

                return;
            }

            SQLiteConnection conn2 = new SQLiteConnection(ServicesContext.ConnectionStringServices());
            conn2.Open();

            SQLiteCommand cmd2 = new SQLiteCommand("SELECT Id FROM Contacts", conn2);
            SQLiteDataReader reader = cmd2.ExecuteReader();

            object id = null;
            while (reader.Read())
            {
                id = reader[0];
            }

            reader.Close();
            cmd2.Dispose();
            conn2.Close();

            int number;

            if (id.ToString() == "")
                number = 1;
            else
                number = Convert.ToInt32(id) + 1;


            using (SQLiteConnection conn = new SQLiteConnection(ServicesContext.ConnectionStringServices()))
            {
                string commandString = "INSERT INTO Descriptions ([Id],[Наименование],[Цена],[СрокДействия],[Количество],[ПроданныхЗаМесяц]) VALUES (@Id,@Наименование,@Цена,@СрокДействия,@Количество,@ПроданныхЗаМесяц)";
                using (SQLiteCommand cmd = new SQLiteCommand(commandString, conn))
                {
                    conn.Open();
                    cmd.Parameters.AddWithValue("@Id", number.ToString());
                    cmd.Parameters.AddWithValue("@Наименование", jeanTextBoxName.Text);
                    cmd.Parameters.AddWithValue("@Цена", jeanTextBoxPrice.Text);
                    cmd.Parameters.AddWithValue("@СрокДействия", jeanTextBoxTerm.Text);
                    cmd.Parameters.AddWithValue("@Количество", jeanTextBoxVisited.Text);
                    cmd.Parameters.AddWithValue("@ПроданныхЗаМесяц", 0);

                    cmd.ExecuteNonQuery();
                }
            }

            Services service = new Services();
            service.Show();
            this.Close();
        }

        private void jeanModernButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
