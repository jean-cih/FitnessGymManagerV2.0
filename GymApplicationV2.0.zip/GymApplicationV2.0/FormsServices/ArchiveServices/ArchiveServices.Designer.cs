﻿namespace GymApplicationV2._0
{
    partial class ArchiveServices
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ArchiveServices));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pictureBoxSearch = new System.Windows.Forms.PictureBox();
            this.dataGridViewArchive = new System.Windows.Forms.DataGridView();
            this.panelChooseAction = new System.Windows.Forms.Panel();
            this.jeanModernButtonBackLife = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanModernButtonChange = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanModernButtonChangeData = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanModernButtonErase = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanSoftTextBoxSearch = new GymApplicationV2._0.Controls.jeanSoftTextBox();
            this.jeanModernButtonRefresh = new GymApplicationV2._0.Controls.JeanModernButton();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSearch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewArchive)).BeginInit();
            this.panelChooseAction.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBoxSearch
            // 
            this.pictureBoxSearch.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxSearch.Image")));
            this.pictureBoxSearch.Location = new System.Drawing.Point(434, 48);
            this.pictureBoxSearch.Name = "pictureBoxSearch";
            this.pictureBoxSearch.Size = new System.Drawing.Size(35, 30);
            this.pictureBoxSearch.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxSearch.TabIndex = 52;
            this.pictureBoxSearch.TabStop = false;
            // 
            // dataGridViewArchive
            // 
            this.dataGridViewArchive.AllowUserToAddRows = false;
            this.dataGridViewArchive.AllowUserToDeleteRows = false;
            this.dataGridViewArchive.AllowUserToResizeColumns = false;
            this.dataGridViewArchive.AllowUserToResizeRows = false;
            this.dataGridViewArchive.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewArchive.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewArchive.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewArchive.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewArchive.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewArchive.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewArchive.DefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridViewArchive.GridColor = System.Drawing.Color.Black;
            this.dataGridViewArchive.Location = new System.Drawing.Point(31, 94);
            this.dataGridViewArchive.Name = "dataGridViewArchive";
            this.dataGridViewArchive.ReadOnly = true;
            this.dataGridViewArchive.RowHeadersWidth = 40;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            this.dataGridViewArchive.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridViewArchive.RowTemplate.Height = 24;
            this.dataGridViewArchive.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewArchive.Size = new System.Drawing.Size(1301, 575);
            this.dataGridViewArchive.TabIndex = 48;
            this.dataGridViewArchive.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewArchive_CellContentClick);
            // 
            // panelChooseAction
            // 
            this.panelChooseAction.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.panelChooseAction.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelChooseAction.Controls.Add(this.jeanModernButtonBackLife);
            this.panelChooseAction.Controls.Add(this.jeanModernButtonChange);
            this.panelChooseAction.Location = new System.Drawing.Point(1097, 81);
            this.panelChooseAction.Name = "panelChooseAction";
            this.panelChooseAction.Size = new System.Drawing.Size(255, 92);
            this.panelChooseAction.TabIndex = 54;
            this.panelChooseAction.Visible = false;
            // 
            // jeanModernButtonBackLife
            // 
            this.jeanModernButtonBackLife.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.jeanModernButtonBackLife.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.jeanModernButtonBackLife.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.jeanModernButtonBackLife.BorderRadius = 0;
            this.jeanModernButtonBackLife.BorderSize = 0;
            this.jeanModernButtonBackLife.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonBackLife.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonBackLife.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonBackLife.ForeColor = System.Drawing.Color.Black;
            this.jeanModernButtonBackLife.Location = new System.Drawing.Point(0, 0);
            this.jeanModernButtonBackLife.Name = "jeanModernButtonBackLife";
            this.jeanModernButtonBackLife.Size = new System.Drawing.Size(252, 45);
            this.jeanModernButtonBackLife.TabIndex = 2;
            this.jeanModernButtonBackLife.Text = "Вернуть из архива";
            this.jeanModernButtonBackLife.TextColor = System.Drawing.Color.Black;
            this.jeanModernButtonBackLife.UseVisualStyleBackColor = false;
            this.jeanModernButtonBackLife.Click += new System.EventHandler(this.jeanModernButtonBackLife_Click);
            // 
            // jeanModernButtonChange
            // 
            this.jeanModernButtonChange.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.jeanModernButtonChange.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.jeanModernButtonChange.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.jeanModernButtonChange.BorderRadius = 0;
            this.jeanModernButtonChange.BorderSize = 0;
            this.jeanModernButtonChange.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonChange.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonChange.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonChange.ForeColor = System.Drawing.Color.Black;
            this.jeanModernButtonChange.Location = new System.Drawing.Point(0, 46);
            this.jeanModernButtonChange.Name = "jeanModernButtonChange";
            this.jeanModernButtonChange.Size = new System.Drawing.Size(252, 45);
            this.jeanModernButtonChange.TabIndex = 0;
            this.jeanModernButtonChange.Text = "Изменить параметры";
            this.jeanModernButtonChange.TextColor = System.Drawing.Color.Black;
            this.jeanModernButtonChange.UseVisualStyleBackColor = false;
            this.jeanModernButtonChange.Click += new System.EventHandler(this.jeanModernButtonChange_Click);
            // 
            // jeanModernButtonChangeData
            // 
            this.jeanModernButtonChangeData.BackColor = System.Drawing.Color.White;
            this.jeanModernButtonChangeData.BackgroundColor = System.Drawing.Color.White;
            this.jeanModernButtonChangeData.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButtonChangeData.BorderRadius = 20;
            this.jeanModernButtonChangeData.BorderSize = 2;
            this.jeanModernButtonChangeData.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonChangeData.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonChangeData.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonChangeData.ForeColor = System.Drawing.Color.Black;
            this.jeanModernButtonChangeData.Location = new System.Drawing.Point(1190, 40);
            this.jeanModernButtonChangeData.Name = "jeanModernButtonChangeData";
            this.jeanModernButtonChangeData.Size = new System.Drawing.Size(142, 45);
            this.jeanModernButtonChangeData.TabIndex = 53;
            this.jeanModernButtonChangeData.Text = "Изменить";
            this.jeanModernButtonChangeData.TextColor = System.Drawing.Color.Black;
            this.jeanModernButtonChangeData.UseVisualStyleBackColor = false;
            this.jeanModernButtonChangeData.Click += new System.EventHandler(this.jeanModernButton1_Click);
            // 
            // jeanModernButtonErase
            // 
            this.jeanModernButtonErase.BackColor = System.Drawing.Color.White;
            this.jeanModernButtonErase.BackgroundColor = System.Drawing.Color.White;
            this.jeanModernButtonErase.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("jeanModernButtonErase.BackgroundImage")));
            this.jeanModernButtonErase.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.jeanModernButtonErase.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.jeanModernButtonErase.BorderRadius = 30;
            this.jeanModernButtonErase.BorderSize = 0;
            this.jeanModernButtonErase.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonErase.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonErase.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonErase.Location = new System.Drawing.Point(776, 48);
            this.jeanModernButtonErase.Name = "jeanModernButtonErase";
            this.jeanModernButtonErase.Size = new System.Drawing.Size(35, 30);
            this.jeanModernButtonErase.TabIndex = 51;
            this.jeanModernButtonErase.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonErase.UseVisualStyleBackColor = false;
            this.jeanModernButtonErase.Visible = false;
            this.jeanModernButtonErase.Click += new System.EventHandler(this.jeanModernButtonErase_Click);
            // 
            // jeanSoftTextBoxSearch
            // 
            this.jeanSoftTextBoxSearch.BorderColor = System.Drawing.Color.Black;
            this.jeanSoftTextBoxSearch.BorderFocusColor = System.Drawing.Color.HotPink;
            this.jeanSoftTextBoxSearch.BorderRadius = 15;
            this.jeanSoftTextBoxSearch.BorderSize = 2;
            this.jeanSoftTextBoxSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanSoftTextBoxSearch.Location = new System.Drawing.Point(423, 42);
            this.jeanSoftTextBoxSearch.Margin = new System.Windows.Forms.Padding(4);
            this.jeanSoftTextBoxSearch.Multiline = false;
            this.jeanSoftTextBoxSearch.Name = "jeanSoftTextBoxSearch";
            this.jeanSoftTextBoxSearch.Padding = new System.Windows.Forms.Padding(50, 10, 50, 10);
            this.jeanSoftTextBoxSearch.PasswordChar = false;
            this.jeanSoftTextBoxSearch.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.jeanSoftTextBoxSearch.PlaceholderText = "  Фамилия, Имя или №Карты";
            this.jeanSoftTextBoxSearch.Size = new System.Drawing.Size(393, 41);
            this.jeanSoftTextBoxSearch.TabIndex = 50;
            this.jeanSoftTextBoxSearch.Texts = "";
            this.jeanSoftTextBoxSearch.UnderlinedStyle = false;
            this.jeanSoftTextBoxSearch._TextChanged += new System.EventHandler(this.jeanSoftTextBoxSearch__TextChanged);
            // 
            // jeanModernButtonRefresh
            // 
            this.jeanModernButtonRefresh.BackColor = System.Drawing.Color.White;
            this.jeanModernButtonRefresh.BackgroundColor = System.Drawing.Color.White;
            this.jeanModernButtonRefresh.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButtonRefresh.BorderRadius = 20;
            this.jeanModernButtonRefresh.BorderSize = 2;
            this.jeanModernButtonRefresh.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonRefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonRefresh.ForeColor = System.Drawing.Color.Black;
            this.jeanModernButtonRefresh.Location = new System.Drawing.Point(823, 40);
            this.jeanModernButtonRefresh.Name = "jeanModernButtonRefresh";
            this.jeanModernButtonRefresh.Size = new System.Drawing.Size(142, 45);
            this.jeanModernButtonRefresh.TabIndex = 49;
            this.jeanModernButtonRefresh.Text = "Обновить";
            this.jeanModernButtonRefresh.TextColor = System.Drawing.Color.Black;
            this.jeanModernButtonRefresh.UseVisualStyleBackColor = false;
            this.jeanModernButtonRefresh.Click += new System.EventHandler(this.jeanModernButtonRefresh_Click);
            // 
            // ArchiveServices
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1364, 701);
            this.Controls.Add(this.panelChooseAction);
            this.Controls.Add(this.jeanModernButtonChangeData);
            this.Controls.Add(this.pictureBoxSearch);
            this.Controls.Add(this.jeanModernButtonErase);
            this.Controls.Add(this.jeanSoftTextBoxSearch);
            this.Controls.Add(this.jeanModernButtonRefresh);
            this.Controls.Add(this.dataGridViewArchive);
            this.Name = "ArchiveServices";
            this.Text = "AchiveServices";
            this.Load += new System.EventHandler(this.ArchiveServices_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSearch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewArchive)).EndInit();
            this.panelChooseAction.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBoxSearch;
        private Controls.JeanModernButton jeanModernButtonErase;
        protected internal Controls.jeanSoftTextBox jeanSoftTextBoxSearch;
        private Controls.JeanModernButton jeanModernButtonRefresh;
        protected internal System.Windows.Forms.DataGridView dataGridViewArchive;
        private Controls.JeanModernButton jeanModernButtonChangeData;
        private System.Windows.Forms.Panel panelChooseAction;
        private Controls.JeanModernButton jeanModernButtonBackLife;
        private Controls.JeanModernButton jeanModernButtonChange;
    }
}