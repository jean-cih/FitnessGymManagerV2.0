﻿using GymApplicationV2._0.FormsServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymApplicationV2._0
{
    public partial class ArchiveServices : Form
    {
        bool clickFlag = false;
        public ArchiveServices()
        {
            InitializeComponent();

            foreach (Control control in this.Controls)
            {
                control.MouseEnter += Control_MouseEnter;
                //control.MouseLeave += Control_MouseLeave;
            }
            panelChooseAction.Visible = false;
        }

        private void Control_MouseEnter(object sender, EventArgs e)
        {
            panelChooseAction.Visible = false;
        }

        /*
        private void Control_MouseLeave(object sender, EventArgs e)
        {
            panelChooseAction.Visible = false;
        }
        */
        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);

            bool isInsideAnyControl = false;
            foreach (Control control in this.Controls)
            {
                if (jeanModernButtonChangeData.Bounds.Contains(e.Location) || (clickFlag && panelChooseAction.Bounds.Contains(e.Location)))
                {
                    isInsideAnyControl = true;
                }
                else
                {
                    clickFlag = false;
                }
                panelChooseAction.Visible = isInsideAnyControl ? true : false;
            }
        }

        /*
        private void MainForm_Load(object sender, EventArgs e)
        {
            panelChooseAction.Visible = false;
        }
        */
        private void ArchiveServices_Load(object sender, EventArgs e)
        {
            dataGridViewArchive.DataSource = ArchiveServicesContext.GetDataFromDatabase("SELECT * FROM Archive");
        }

        private void jeanSoftTextBoxSearch__TextChanged(object sender, EventArgs e)
        {
            if (jeanSoftTextBoxSearch.Texts.Length > 0)
            {
                jeanModernButtonErase.Visible = true;
            }
            else
            {
                jeanModernButtonErase.Visible = false;
            }

            dataGridViewArchive.DataSource = ArchiveServicesContext.GetDataFromDatabase($"" +
                $"SELECT * " +
                $"FROM Archive " +
                $"WHERE №Карты LIKE '%{jeanSoftTextBoxSearch.Texts}%' " +
                $"OR Фамилия LIKE '%{jeanSoftTextBoxSearch.Texts}%' " +
                $"OR Имя LIKE '%{jeanSoftTextBoxSearch.Texts}%'");
        }

        private void jeanModernButtonErase_Click(object sender, EventArgs e)
        {
            jeanSoftTextBoxSearch.Texts = "";
        }

        private void jeanModernButtonRefresh_Click(object sender, EventArgs e)
        {
            dataGridViewArchive.DataSource = ArchiveServicesContext.GetDataFromDatabase("SELECT * FROM Archive");
        }

        string surname = "", name = "", membership = "", term = "", visits = "", numberCard = ""; 
        private void dataGridViewArchive_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            jeanSoftTextBoxSearch.ForeColor = Color.Black;

            surname = dataGridViewArchive.SelectedRows[0].Cells[1].Value.ToString();
            name = dataGridViewArchive.SelectedRows[0].Cells[2].Value.ToString();
            jeanSoftTextBoxSearch.Texts = dataGridViewArchive.SelectedRows[0].Cells[5].Value.ToString();
            numberCard = dataGridViewArchive.SelectedRows[0].Cells[5].Value.ToString();
            membership = dataGridViewArchive.SelectedRows[0].Cells[6].Value.ToString();
            term = dataGridViewArchive.SelectedRows[0].Cells[7].Value.ToString();
            visits = dataGridViewArchive.SelectedRows[0].Cells[8].Value.ToString();

            jeanModernButtonErase.Visible = true;
        }

        private void jeanModernButton1_Click(object sender, EventArgs e)
        {
            panelChooseAction.Visible = true;
            clickFlag = true;
        }

        private void jeanModernButtonBackLife_Click(object sender, EventArgs e)
        {
            Regex regex = new Regex(@"^\d{13}$");
            if (!regex.IsMatch(numberCard))
            {
                Message.MessageWindowOk("Выберете номер клиента из таблицы");
                return;
            }

            BackToLife backToLife = new BackToLife();
            backToLife.labelNameClient.Text = surname + " " + name;
            backToLife.labelNubmerCard.Text = numberCard;
            backToLife.jeanSoftTextBoxMembership.Texts = membership;
            backToLife.jeanSoftTextBoxTerm.Texts = term;
            backToLife.jeanSoftTextBoxVisits.Texts = visits;
            backToLife.ShowDialog();

            dataGridViewArchive.DataSource = ArchiveServicesContext.GetDataFromDatabase("SELECT * FROM Archive");
        }

        private void jeanModernButtonChange_Click(object sender, EventArgs e)
        {
            Regex regex = new Regex(@"^\d{13}$");
            if (!regex.IsMatch(numberCard))
            {
                Message.MessageWindowOk("Выберете номер клиента из таблицы");
                return;
            }

            ChangeArchiveService changeArchiveService = new ChangeArchiveService();
            changeArchiveService.jeanSoftTextBoxSurname.Texts = surname;
            changeArchiveService.jeanSoftTextBoxName.Texts = name;
            changeArchiveService.jeanSoftTextBoxCard.Texts = numberCard;
            changeArchiveService.jeanSoftTextBoxMembership.Texts = membership;
            changeArchiveService.jeanSoftTextBoxTerm.Texts = term;
            changeArchiveService.jeanSoftTextBoxVisits.Texts = visits;
            changeArchiveService.ShowDialog();

            dataGridViewArchive.DataSource = ArchiveServicesContext.GetDataFromDatabase("SELECT * FROM Archive");
        }
    }
}
