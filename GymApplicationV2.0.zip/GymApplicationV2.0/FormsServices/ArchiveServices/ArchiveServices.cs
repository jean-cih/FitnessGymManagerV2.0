﻿using GymApplicationV2._0.Components;
using GymApplicationV2._0.Controls;
using GymApplicationV2._0.FormsServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymApplicationV2._0
{
    public partial class ArchiveServices : Form
    {
        private ToolStripDropDownMenu _menu;

        public ArchiveServices()
        {
            InitializeComponent();

            jeanModernButtonChangeData.Click += Button_Click;
            Controls.Add(jeanModernButtonChangeData);

            _menu = new ToolStripDropDownMenu();
            _menu.Font = new System.Drawing.Font("Arial", 12, FontStyle.Regular);
            ToolStripMenuItem item1 = new ToolStripMenuItem("Вернуть из архива", Properties.Resources.backToLife);
            ToolStripMenuItem item2 = new ToolStripMenuItem("Изменить параметры", Properties.Resources.change);
            _menu.Items.Add(item1);
            _menu.Items.Add(item2);

            _menu.Items[0].Click += jeanModernButtonBackLife_Click;
            _menu.Items[1].Click += jeanModernButtonChange_Click;
        }

        private void Button_Click(object sender, EventArgs e)
        {
            _menu.Show(jeanModernButtonChangeData, new Point(0, jeanModernButtonChangeData.Height));
        }
       
        private void ArchiveServices_Load(object sender, EventArgs e)
        {
            dataGridViewArchive.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            JeanFormStyle.fStyle style = JeanFormStyle.fStyle.None;
            if (DataClass.styleForm == "UserStyle")
            {
                style = JeanFormStyle.fStyle.UserStyle;
            }
            else if (DataClass.styleForm == "SimpleDark")
            {
                style = JeanFormStyle.fStyle.SimpleDark;
            }
            else if (DataClass.styleForm == "TelegramStyle")
            {
                style = JeanFormStyle.fStyle.TelegramStyle;
            }

            jeanFormStyle.FormStyle = style;

            dataGridViewArchive.DataSource = ArchiveServicesContext.GetDataFromDatabase("SELECT * FROM Archive");
        }

        private void jeanSoftTextBoxSearch__TextChanged(object sender, EventArgs e)
        {
            if (jeanSoftTextBoxSearch.Texts.Length > 0)
            {
                jeanModernButtonErase.Visible = true;
            }
            else
            {
                jeanModernButtonErase.Visible = false;
                dataGridViewArchive.DataSource = ArchiveServicesContext.GetDataFromDatabase("SELECT * FROM Archive");
                return;
            }

            string[] fullName = jeanSoftTextBoxSearch.Texts.Split(' ');
            fullName[0] = Char.ToUpper(fullName[0][0]) + fullName[0].Substring(1);
            try
            {
                fullName[1] = Char.ToUpper(fullName[1][0]) + fullName[1].Substring(1);

                dataGridViewArchive.DataSource = ArchiveServicesContext.GetDataFromDatabase($"" +
                    $"SELECT * " +
                    $"FROM Archive " +
                    $"WHERE №Карты LIKE '%{fullName[0]}%' " +
                    $"OR Фамилия LIKE '%{fullName[0]}%' " +
                    $"AND Имя LIKE '%{fullName[1]}%'");
            }
            catch
            {
                dataGridViewArchive.DataSource = ArchiveServicesContext.GetDataFromDatabase($"" +
                    $"SELECT * " +
                    $"FROM Archive " +
                    $"WHERE №Карты LIKE '%{fullName[0]}%' " +
                    $"OR Фамилия LIKE '%{fullName[0]}%' " +
                    $"OR Имя LIKE '%{fullName[0]}%'");
            }
        }

        private void jeanModernButtonErase_Click(object sender, EventArgs e)
        {
            jeanSoftTextBoxSearch.Texts = "";
        }

        private void jeanModernButtonRefresh_Click(object sender, EventArgs e)
        {
            dataGridViewArchive.DataSource = ArchiveServicesContext.GetDataFromDatabase("SELECT * FROM Archive");
        }

        string surname = "", name = "", membership = "", term = "", visits = "", numberCard = "";

        private void jeanModernButtonChangeData_Click(object sender, EventArgs e)
        {

        }

        private void dataGridViewArchive_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            jeanSoftTextBoxSearch.ForeColor = Color.Black;

            surname = dataGridViewArchive.SelectedRows[0].Cells[1].Value.ToString();
            name = dataGridViewArchive.SelectedRows[0].Cells[2].Value.ToString();
            jeanSoftTextBoxSearch.Texts = dataGridViewArchive.SelectedRows[0].Cells[5].Value.ToString();
            numberCard = dataGridViewArchive.SelectedRows[0].Cells[5].Value.ToString();
            membership = dataGridViewArchive.SelectedRows[0].Cells[6].Value.ToString();
            term = dataGridViewArchive.SelectedRows[0].Cells[7].Value.ToString();
            visits = dataGridViewArchive.SelectedRows[0].Cells[8].Value.ToString();

            jeanModernButtonErase.Visible = true;
        }

        private void jeanModernButtonBackLife_Click(object sender, EventArgs e)
        {
            Regex regex = new Regex(@"^\d{13}$");
            if (!regex.IsMatch(numberCard))
            {
                Message.MessageWindowOk("Выберете номер клиента из таблицы");
                return;
            }

            BackToLife backToLife = new BackToLife();
            backToLife.labelNameClient.Text = surname + " " + name;
            backToLife.labelNubmerCard.Text = numberCard;
            backToLife.jeanSoftTextBoxMembership.Texts = membership;
            backToLife.jeanSoftTextBoxTerm.Texts = term;
            backToLife.jeanSoftTextBoxVisits.Texts = visits;
            backToLife.ShowDialog();

            dataGridViewArchive.DataSource = ArchiveServicesContext.GetDataFromDatabase("SELECT * FROM Archive");
        }

        private void jeanModernButtonChange_Click(object sender, EventArgs e)
        {
            Regex regex = new Regex(@"^\d{13}$");
            if (!regex.IsMatch(numberCard))
            {
                Message.MessageWindowOk("Выберете номер клиента из таблицы");
                return;
            }

            ChangeArchiveService changeArchiveService = new ChangeArchiveService();
            changeArchiveService.jeanSoftTextBoxSurname.Texts = surname;
            changeArchiveService.jeanSoftTextBoxName.Texts = name;
            changeArchiveService.jeanSoftTextBoxCard.Texts = numberCard;
            changeArchiveService.jeanSoftTextBoxMembership.Texts = membership;
            changeArchiveService.jeanSoftTextBoxTerm.Texts = term;
            changeArchiveService.jeanSoftTextBoxVisits.Texts = visits;
            changeArchiveService.ShowDialog();

            dataGridViewArchive.DataSource = ArchiveServicesContext.GetDataFromDatabase("SELECT * FROM Archive");
        }
    }
}
