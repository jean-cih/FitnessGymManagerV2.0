﻿using GymApplicationV2._0.Components;
using GymApplicationV2._0.Controls;
using GymApplicationV2._0.FormsServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymApplicationV2._0
{
    public partial class ArchiveServices : Form
    {
        private ToolStripDropDownMenu _menu;

        public ArchiveServices()
        {
            InitializeComponent();

            jeanModernButtonChangeData.Click += Button_Click;
            Controls.Add(jeanModernButtonChangeData);

            _menu = new ToolStripDropDownMenu();
            _menu.Font = new System.Drawing.Font("Arial", 12, FontStyle.Regular);
            ToolStripMenuItem item1 = new ToolStripMenuItem("Вернуть из архива", Properties.Resources.backToLife);
            ToolStripMenuItem item2 = new ToolStripMenuItem("Изменить параметры", Properties.Resources.change);
            _menu.Items.Add(item1);
            _menu.Items.Add(item2);

            _menu.Items[0].Click += jeanModernButtonBackLife_Click;
            _menu.Items[1].Click += jeanModernButtonChange_Click;
        }

        private void Button_Click(object sender, EventArgs e)
        {
            _menu.Show(jeanModernButtonChangeData, new Point(0, jeanModernButtonChangeData.Height));
        }
       
        private void ArchiveServices_Load(object sender, EventArgs e)
        {
            this.Width = Convert.ToInt32(Screen.PrimaryScreen.Bounds.Width * 0.75);
            this.Height = Convert.ToInt32(Screen.PrimaryScreen.Bounds.Height * 0.75);

            jeanPanel.Size = new Size(this.Width - 40, this.Height - 180);
            jeanSoftTextBoxSearch.Location = new System.Drawing.Point(this.Width / 2 - 150, 30);
            jeanModernButtonErase.Location = new System.Drawing.Point(this.Width / 2 - 150 + 260, 35);
            pictureBoxSearch.Location = new System.Drawing.Point(this.Width / 2 - 140, 35);
            jeanModernButtonChangeData.Location = new System.Drawing.Point(this.Width - 150, 30);

            dataGridViewArchive.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            dataGridViewArchive.DataSource = ArchiveServicesContext.GetDataFromDatabase("SELECT Клиент, №Карты, Дата_окончания, Абонемент, Оплата, Посещений_осталось FROM Archive");
        }

        private void jeanSoftTextBoxSearch__TextChanged(object sender, EventArgs e)
        {
            if (jeanSoftTextBoxSearch.Texts.Length > 0)
            {
                jeanModernButtonErase.Visible = true;
            }
            else
            {
                jeanModernButtonErase.Visible = false;
                dataGridViewArchive.DataSource = ArchiveServicesContext.GetDataFromDatabase("SELECT Клиент, №Карты, Дата_окончания, Абонемент, Оплата, Посещений_осталось FROM Archive");
                return;
            }

            dataGridViewArchive.DataSource = ArchiveServicesContext.GetDataFromDatabase($"" +
                $"SELECT Клиент, №Карты, Дата_окончания, Абонемент, Оплата, Посещений_осталось " +
                $"FROM Archive " +
                $"WHERE №Карты LIKE '%{jeanSoftTextBoxSearch.Texts}%' " +
                $"OR Клиент LIKE '%{jeanSoftTextBoxSearch.Texts}%'");
        }

        private void jeanModernButtonErase_Click(object sender, EventArgs e)
        {
            jeanSoftTextBoxSearch.Texts = "";
        }

        private void jeanModernButtonRefresh_Click(object sender, EventArgs e)
        {
            dataGridViewArchive.DataSource = ArchiveServicesContext.GetDataFromDatabase("SELECT Клиент, №Карты, Дата_окончания, Абонемент, Оплата, Посещений_осталось FROM Archive");
        }


        string client = "", membership = "", term = "", cost = "", numberCard = "", visits = "";

        private void jeanModernButtonChangeData_Click(object sender, EventArgs e)
        {

        }

        private void dataGridViewArchive_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            client = dataGridViewArchive.SelectedRows[0].Cells[0].Value.ToString();
            numberCard = dataGridViewArchive.SelectedRows[0].Cells[1].Value.ToString();
            term = dataGridViewArchive.SelectedRows[0].Cells[2].Value.ToString();
            membership = dataGridViewArchive.SelectedRows[0].Cells[3].Value.ToString();
            cost = dataGridViewArchive.SelectedRows[0].Cells[4].Value.ToString();
            visits = dataGridViewArchive.SelectedRows[0].Cells[5].Value.ToString();
        }

        private void jeanModernButtonBackLife_Click(object sender, EventArgs e)
        {
            Regex regex = new Regex(@"^\d{13}$");
            if (!regex.IsMatch(numberCard))
            {
                Message.MessageWindowOk("Выберете номер клиента из таблицы");
                return;
            }

            BackToLife backToLife = new BackToLife();
            backToLife.labelNameClient.Text = client;
            backToLife.labelNubmerCard.Text = numberCard;
            backToLife.jeanSoftTextBoxMembership.Texts = membership;
            backToLife.jeanSoftTextBoxTerm.Texts = term;
            backToLife.jeanSoftTextBoxVisits.Texts = visits;
            backToLife.ShowDialog();

            dataGridViewArchive.DataSource = ArchiveServicesContext.GetDataFromDatabase("SELECT Клиент, №Карты, Дата_окончания, Абонемент, Оплата, Посещений_осталось FROM Archive");
        }

        private void jeanModernButtonChange_Click(object sender, EventArgs e)
        {
            Regex regex = new Regex(@"^\d{13}$");
            if (!regex.IsMatch(numberCard))
            {
                Message.MessageWindowOk("Выберете номер клиента из таблицы");
                return;
            }

            ChangeArchiveService changeArchiveService = new ChangeArchiveService();
            changeArchiveService.jeanSoftTextBoxClient.Texts = client;
            changeArchiveService.jeanSoftTextBoxCard.Texts = numberCard;
            changeArchiveService.jeanSoftTextBoxMembership.Texts = membership;
            changeArchiveService.jeanSoftTextBoxTerm.Texts = term;
            changeArchiveService.jeanSoftTextBoxCost.Texts = cost;
            changeArchiveService.jeanSoftTextBoxVisits.Texts = visits;
            changeArchiveService.ShowDialog();

            dataGridViewArchive.DataSource = ArchiveServicesContext.GetDataFromDatabase("SELECT Клиент, №Карты, Дата_окончания, Абонемент, Оплата, Посещений_осталось FROM Archive");
        }
    }
}
