﻿namespace GymApplicationV2._0.FormsServices
{
    partial class BackToLife
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.labelNameClient = new System.Windows.Forms.Label();
            this.labelNubmerCard = new System.Windows.Forms.Label();
            this.jeanSoftTextBoxMembership = new GymApplicationV2._0.Controls.jeanSoftTextBox();
            this.jeanSoftTextBoxTerm = new GymApplicationV2._0.Controls.jeanSoftTextBox();
            this.jeanSoftTextBoxVisits = new GymApplicationV2._0.Controls.jeanSoftTextBox();
            this.jeanModernButtonBackToLife = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanFormStyle = new GymApplicationV2._0.Components.JeanFormStyle(this.components);
            this.SuspendLayout();
            // 
            // labelNameClient
            // 
            this.labelNameClient.AutoSize = true;
            this.labelNameClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelNameClient.Location = new System.Drawing.Point(294, 170);
            this.labelNameClient.Name = "labelNameClient";
            this.labelNameClient.Size = new System.Drawing.Size(174, 20);
            this.labelNameClient.TabIndex = 0;
            this.labelNameClient.Text = "Почекутов Евгений";
            // 
            // labelNubmerCard
            // 
            this.labelNubmerCard.AutoSize = true;
            this.labelNubmerCard.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelNubmerCard.Location = new System.Drawing.Point(474, 170);
            this.labelNubmerCard.Name = "labelNubmerCard";
            this.labelNubmerCard.Size = new System.Drawing.Size(126, 20);
            this.labelNubmerCard.TabIndex = 1;
            this.labelNubmerCard.Text = "2000000012345";
            // 
            // jeanSoftTextBoxMembership
            // 
            this.jeanSoftTextBoxMembership.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanSoftTextBoxMembership.BorderFocusColor = System.Drawing.Color.HotPink;
            this.jeanSoftTextBoxMembership.BorderRadius = 0;
            this.jeanSoftTextBoxMembership.BorderSize = 2;
            this.jeanSoftTextBoxMembership.Location = new System.Drawing.Point(326, 217);
            this.jeanSoftTextBoxMembership.Margin = new System.Windows.Forms.Padding(4);
            this.jeanSoftTextBoxMembership.Multiline = false;
            this.jeanSoftTextBoxMembership.Name = "jeanSoftTextBoxMembership";
            this.jeanSoftTextBoxMembership.Padding = new System.Windows.Forms.Padding(5);
            this.jeanSoftTextBoxMembership.PasswordChar = false;
            this.jeanSoftTextBoxMembership.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.jeanSoftTextBoxMembership.PlaceholderText = "";
            this.jeanSoftTextBoxMembership.Size = new System.Drawing.Size(250, 30);
            this.jeanSoftTextBoxMembership.TabIndex = 2;
            this.jeanSoftTextBoxMembership.Texts = "";
            this.jeanSoftTextBoxMembership.UnderlinedStyle = false;
            // 
            // jeanSoftTextBoxTerm
            // 
            this.jeanSoftTextBoxTerm.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanSoftTextBoxTerm.BorderFocusColor = System.Drawing.Color.HotPink;
            this.jeanSoftTextBoxTerm.BorderRadius = 0;
            this.jeanSoftTextBoxTerm.BorderSize = 2;
            this.jeanSoftTextBoxTerm.Location = new System.Drawing.Point(326, 267);
            this.jeanSoftTextBoxTerm.Margin = new System.Windows.Forms.Padding(4);
            this.jeanSoftTextBoxTerm.Multiline = false;
            this.jeanSoftTextBoxTerm.Name = "jeanSoftTextBoxTerm";
            this.jeanSoftTextBoxTerm.Padding = new System.Windows.Forms.Padding(5);
            this.jeanSoftTextBoxTerm.PasswordChar = false;
            this.jeanSoftTextBoxTerm.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.jeanSoftTextBoxTerm.PlaceholderText = "";
            this.jeanSoftTextBoxTerm.Size = new System.Drawing.Size(250, 30);
            this.jeanSoftTextBoxTerm.TabIndex = 3;
            this.jeanSoftTextBoxTerm.Texts = "";
            this.jeanSoftTextBoxTerm.UnderlinedStyle = false;
            // 
            // jeanSoftTextBoxVisits
            // 
            this.jeanSoftTextBoxVisits.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanSoftTextBoxVisits.BorderFocusColor = System.Drawing.Color.HotPink;
            this.jeanSoftTextBoxVisits.BorderRadius = 0;
            this.jeanSoftTextBoxVisits.BorderSize = 2;
            this.jeanSoftTextBoxVisits.Location = new System.Drawing.Point(326, 319);
            this.jeanSoftTextBoxVisits.Margin = new System.Windows.Forms.Padding(4);
            this.jeanSoftTextBoxVisits.Multiline = false;
            this.jeanSoftTextBoxVisits.Name = "jeanSoftTextBoxVisits";
            this.jeanSoftTextBoxVisits.Padding = new System.Windows.Forms.Padding(5);
            this.jeanSoftTextBoxVisits.PasswordChar = false;
            this.jeanSoftTextBoxVisits.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.jeanSoftTextBoxVisits.PlaceholderText = "";
            this.jeanSoftTextBoxVisits.Size = new System.Drawing.Size(250, 30);
            this.jeanSoftTextBoxVisits.TabIndex = 4;
            this.jeanSoftTextBoxVisits.Texts = "";
            this.jeanSoftTextBoxVisits.UnderlinedStyle = false;
            // 
            // jeanModernButtonBackToLife
            // 
            this.jeanModernButtonBackToLife.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonBackToLife.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonBackToLife.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButtonBackToLife.BorderRadius = 20;
            this.jeanModernButtonBackToLife.BorderSize = 2;
            this.jeanModernButtonBackToLife.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonBackToLife.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonBackToLife.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonBackToLife.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonBackToLife.Location = new System.Drawing.Point(393, 505);
            this.jeanModernButtonBackToLife.Name = "jeanModernButtonBackToLife";
            this.jeanModernButtonBackToLife.Size = new System.Drawing.Size(150, 45);
            this.jeanModernButtonBackToLife.TabIndex = 23;
            this.jeanModernButtonBackToLife.Text = "Вернуть";
            this.jeanModernButtonBackToLife.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonBackToLife.UseVisualStyleBackColor = false;
            this.jeanModernButtonBackToLife.Click += new System.EventHandler(this.jeanModernButtonBackToLife_Click);
            // 
            // jeanFormStyle
            // 
            this.jeanFormStyle.AllowUserResize = false;
            this.jeanFormStyle.BackColor = System.Drawing.Color.White;
            this.jeanFormStyle.ContextMenuForm = null;
            this.jeanFormStyle.ControlBoxButtonsWidth = 20;
            this.jeanFormStyle.EnableControlBoxIconsLight = false;
            this.jeanFormStyle.EnableControlBoxMouseLight = false;
            this.jeanFormStyle.Form = this;
            this.jeanFormStyle.FormStyle = GymApplicationV2._0.Components.JeanFormStyle.fStyle.UserStyle;
            this.jeanFormStyle.HeaderColor = System.Drawing.Color.Black;
            this.jeanFormStyle.HeaderColorAdditional = System.Drawing.Color.DarkOrange;
            this.jeanFormStyle.HeaderColorGradientEnable = true;
            this.jeanFormStyle.HeaderColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.jeanFormStyle.HeaderHeight = 30;
            this.jeanFormStyle.HeaderImage = null;
            this.jeanFormStyle.HeaderTextColor = System.Drawing.Color.White;
            this.jeanFormStyle.HeaderTextFont = new System.Drawing.Font("Segoe UI", 9.75F);
            // 
            // BackToLife
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(926, 573);
            this.Controls.Add(this.jeanModernButtonBackToLife);
            this.Controls.Add(this.jeanSoftTextBoxVisits);
            this.Controls.Add(this.jeanSoftTextBoxTerm);
            this.Controls.Add(this.jeanSoftTextBoxMembership);
            this.Controls.Add(this.labelNubmerCard);
            this.Controls.Add(this.labelNameClient);
            this.Name = "BackToLife";
            this.Text = "BackToLife";
            this.Load += new System.EventHandler(this.BackToLife_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        protected internal System.Windows.Forms.Label labelNameClient;
        protected internal System.Windows.Forms.Label labelNubmerCard;
        protected internal Controls.jeanSoftTextBox jeanSoftTextBoxMembership;
        protected internal Controls.jeanSoftTextBox jeanSoftTextBoxTerm;
        protected internal Controls.jeanSoftTextBox jeanSoftTextBoxVisits;
        private Controls.JeanModernButton jeanModernButtonBackToLife;
        private Components.JeanFormStyle jeanFormStyle;
    }
}