﻿namespace GymApplicationV2._0.FormsServices
{
    partial class BackToLife
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BackToLife));
            this.labelNameClient = new System.Windows.Forms.Label();
            this.labelNubmerCard = new System.Windows.Forms.Label();
            this.jeanModernButton1 = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanModernButtonBackToLife = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanSoftTextBoxVisits = new GymApplicationV2._0.Controls.jeanSoftTextBox();
            this.jeanSoftTextBoxTerm = new GymApplicationV2._0.Controls.jeanSoftTextBox();
            this.jeanSoftTextBoxMembership = new GymApplicationV2._0.Controls.jeanSoftTextBox();
            this.SuspendLayout();
            // 
            // labelNameClient
            // 
            this.labelNameClient.AutoSize = true;
            this.labelNameClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelNameClient.Location = new System.Drawing.Point(37, 77);
            this.labelNameClient.Name = "labelNameClient";
            this.labelNameClient.Size = new System.Drawing.Size(174, 20);
            this.labelNameClient.TabIndex = 0;
            this.labelNameClient.Text = "Почекутов Евгений";
            // 
            // labelNubmerCard
            // 
            this.labelNubmerCard.AutoSize = true;
            this.labelNubmerCard.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelNubmerCard.Location = new System.Drawing.Point(217, 77);
            this.labelNubmerCard.Name = "labelNubmerCard";
            this.labelNubmerCard.Size = new System.Drawing.Size(126, 20);
            this.labelNubmerCard.TabIndex = 1;
            this.labelNubmerCard.Text = "2000000012345";
            // 
            // jeanModernButton1
            // 
            this.jeanModernButton1.BackColor = System.Drawing.Color.White;
            this.jeanModernButton1.BackgroundColor = System.Drawing.Color.White;
            this.jeanModernButton1.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButton1.BorderRadius = 20;
            this.jeanModernButton1.BorderSize = 2;
            this.jeanModernButton1.FlatAppearance.BorderSize = 0;
            this.jeanModernButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButton1.ForeColor = System.Drawing.Color.Black;
            this.jeanModernButton1.Location = new System.Drawing.Point(348, 8);
            this.jeanModernButton1.Name = "jeanModernButton1";
            this.jeanModernButton1.Size = new System.Drawing.Size(40, 35);
            this.jeanModernButton1.TabIndex = 24;
            this.jeanModernButton1.Text = " X";
            this.jeanModernButton1.TextColor = System.Drawing.Color.Black;
            this.jeanModernButton1.UseVisualStyleBackColor = false;
            this.jeanModernButton1.Click += new System.EventHandler(this.jeanModernButton1_Click);
            // 
            // jeanModernButtonBackToLife
            // 
            this.jeanModernButtonBackToLife.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonBackToLife.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonBackToLife.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButtonBackToLife.BorderRadius = 20;
            this.jeanModernButtonBackToLife.BorderSize = 2;
            this.jeanModernButtonBackToLife.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonBackToLife.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonBackToLife.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonBackToLife.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonBackToLife.Location = new System.Drawing.Point(123, 309);
            this.jeanModernButtonBackToLife.Name = "jeanModernButtonBackToLife";
            this.jeanModernButtonBackToLife.Size = new System.Drawing.Size(150, 45);
            this.jeanModernButtonBackToLife.TabIndex = 23;
            this.jeanModernButtonBackToLife.Text = "Вернуть";
            this.jeanModernButtonBackToLife.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonBackToLife.UseVisualStyleBackColor = false;
            this.jeanModernButtonBackToLife.Click += new System.EventHandler(this.jeanModernButtonBackToLife_Click);
            // 
            // jeanSoftTextBoxVisits
            // 
            this.jeanSoftTextBoxVisits.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanSoftTextBoxVisits.BorderFocusColor = System.Drawing.Color.HotPink;
            this.jeanSoftTextBoxVisits.BorderRadius = 0;
            this.jeanSoftTextBoxVisits.BorderSize = 2;
            this.jeanSoftTextBoxVisits.Location = new System.Drawing.Point(69, 226);
            this.jeanSoftTextBoxVisits.Margin = new System.Windows.Forms.Padding(4);
            this.jeanSoftTextBoxVisits.Multiline = false;
            this.jeanSoftTextBoxVisits.Name = "jeanSoftTextBoxVisits";
            this.jeanSoftTextBoxVisits.Padding = new System.Windows.Forms.Padding(5);
            this.jeanSoftTextBoxVisits.PasswordChar = false;
            this.jeanSoftTextBoxVisits.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.jeanSoftTextBoxVisits.PlaceholderText = "";
            this.jeanSoftTextBoxVisits.Size = new System.Drawing.Size(250, 30);
            this.jeanSoftTextBoxVisits.TabIndex = 4;
            this.jeanSoftTextBoxVisits.Texts = "";
            this.jeanSoftTextBoxVisits.UnderlinedStyle = false;
            // 
            // jeanSoftTextBoxTerm
            // 
            this.jeanSoftTextBoxTerm.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanSoftTextBoxTerm.BorderFocusColor = System.Drawing.Color.HotPink;
            this.jeanSoftTextBoxTerm.BorderRadius = 0;
            this.jeanSoftTextBoxTerm.BorderSize = 2;
            this.jeanSoftTextBoxTerm.Location = new System.Drawing.Point(69, 174);
            this.jeanSoftTextBoxTerm.Margin = new System.Windows.Forms.Padding(4);
            this.jeanSoftTextBoxTerm.Multiline = false;
            this.jeanSoftTextBoxTerm.Name = "jeanSoftTextBoxTerm";
            this.jeanSoftTextBoxTerm.Padding = new System.Windows.Forms.Padding(5);
            this.jeanSoftTextBoxTerm.PasswordChar = false;
            this.jeanSoftTextBoxTerm.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.jeanSoftTextBoxTerm.PlaceholderText = "";
            this.jeanSoftTextBoxTerm.Size = new System.Drawing.Size(250, 30);
            this.jeanSoftTextBoxTerm.TabIndex = 3;
            this.jeanSoftTextBoxTerm.Texts = "";
            this.jeanSoftTextBoxTerm.UnderlinedStyle = false;
            // 
            // jeanSoftTextBoxMembership
            // 
            this.jeanSoftTextBoxMembership.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanSoftTextBoxMembership.BorderFocusColor = System.Drawing.Color.HotPink;
            this.jeanSoftTextBoxMembership.BorderRadius = 0;
            this.jeanSoftTextBoxMembership.BorderSize = 2;
            this.jeanSoftTextBoxMembership.Location = new System.Drawing.Point(69, 124);
            this.jeanSoftTextBoxMembership.Margin = new System.Windows.Forms.Padding(4);
            this.jeanSoftTextBoxMembership.Multiline = false;
            this.jeanSoftTextBoxMembership.Name = "jeanSoftTextBoxMembership";
            this.jeanSoftTextBoxMembership.Padding = new System.Windows.Forms.Padding(5);
            this.jeanSoftTextBoxMembership.PasswordChar = false;
            this.jeanSoftTextBoxMembership.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.jeanSoftTextBoxMembership.PlaceholderText = "";
            this.jeanSoftTextBoxMembership.Size = new System.Drawing.Size(250, 30);
            this.jeanSoftTextBoxMembership.TabIndex = 2;
            this.jeanSoftTextBoxMembership.Texts = "";
            this.jeanSoftTextBoxMembership.UnderlinedStyle = false;
            // 
            // BackToLife
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(400, 420);
            this.Controls.Add(this.jeanModernButton1);
            this.Controls.Add(this.jeanModernButtonBackToLife);
            this.Controls.Add(this.jeanSoftTextBoxVisits);
            this.Controls.Add(this.jeanSoftTextBoxTerm);
            this.Controls.Add(this.jeanSoftTextBoxMembership);
            this.Controls.Add(this.labelNubmerCard);
            this.Controls.Add(this.labelNameClient);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "BackToLife";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Возврат из архива";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.BackToLife_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.BackToLife_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.BackToLife_MouseUp);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        protected internal System.Windows.Forms.Label labelNameClient;
        protected internal System.Windows.Forms.Label labelNubmerCard;
        protected internal Controls.jeanSoftTextBox jeanSoftTextBoxMembership;
        protected internal Controls.jeanSoftTextBox jeanSoftTextBoxTerm;
        protected internal Controls.jeanSoftTextBox jeanSoftTextBoxVisits;
        private Controls.JeanModernButton jeanModernButtonBackToLife;
        private Controls.JeanModernButton jeanModernButton1;
    }
}