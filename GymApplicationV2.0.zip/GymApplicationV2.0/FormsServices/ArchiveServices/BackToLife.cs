﻿using GymApplicationV2._0.Components;
using Microsoft.Office.Interop.Excel;
using Shadow;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace GymApplicationV2._0.FormsServices
{
    public partial class BackToLife : ShadowedForm
    {
        public BackToLife()
        {
            InitializeComponent();
        }

        private bool isMousePress = false;
        private System.Drawing.Point _clickPoint;
        private System.Drawing.Point _formStartPoint;

        private void BackToLife_MouseDown(object sender, MouseEventArgs e)
        {
            isMousePress = true;
            _clickPoint = Cursor.Position;
            _formStartPoint = Location;
        }
        private void BackToLife_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMousePress)
            {
                var cursorOffsetPoint = new System.Drawing.Point(
                    Cursor.Position.X - _clickPoint.X,
                    Cursor.Position.Y - _clickPoint.Y);

                Location = new System.Drawing.Point(
                    _formStartPoint.X + cursorOffsetPoint.X,
                    _formStartPoint.Y + cursorOffsetPoint.Y);
            }
        }

        private void BackToLife_MouseUp(object sender, MouseEventArgs e)
        {
            isMousePress = false;
            _clickPoint = System.Drawing.Point.Empty;
        }

        private void jeanModernButtonBackToLife_Click(object sender, EventArgs e)
        {
            DialogResult result = Message.MessageWindowYesNo("Вы уверены что хотите восстановить абонемент");

            if(result == DialogResult.No)
            {
                return;
            }

            ClientsContext.CommandDataClient("UPDATE Contacts SET " +
                    "Абонемент = '" + jeanSoftTextBoxMembership.Texts + "'," +
                    "Срок_абонемента = '" + jeanSoftTextBoxTerm.Texts + "'," +
                    "Посещений_осталось = '" + jeanSoftTextBoxVisits.Texts + "' " +  
                    "WHERE №Карты = '" + labelNubmerCard.Text + "';");

            ArchiveServicesContext.CommandDataArchive("DELETE FROM Archive WHERE №Карты = '" + labelNubmerCard.Text + "' ");

            Message.MessageWindowOk("Абонемент восстановлен");
        }

        private void jeanModernButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
