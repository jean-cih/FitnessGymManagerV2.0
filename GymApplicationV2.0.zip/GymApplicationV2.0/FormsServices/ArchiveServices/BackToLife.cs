﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace GymApplicationV2._0.FormsServices
{
    public partial class BackToLife : Form
    {
        public BackToLife()
        {
            InitializeComponent();
        }

        private void jeanModernButtonBackToLife_Click(object sender, EventArgs e)
        {
            DialogResult result = Message.MessageWindowYesNo("Вы уверены что хотите восстановить абонемент");

            if(result == DialogResult.No)
            {
                return;
            }

            ClientsContext.CommandDataClient("UPDATE Contacts SET " +
                    "Абонемент = '" + jeanSoftTextBoxMembership.Texts + "'," +
                    "Срок_абонемента = '" + jeanSoftTextBoxTerm.Texts + "'," +
                    "Посещений_осталось = '" + jeanSoftTextBoxVisits.Texts + "' " +  
                    "WHERE №Карты = '" + labelNubmerCard.Text + "';");

            ArchiveServicesContext.CommandDataArchive("DELETE FROM Archive WHERE №Карты = '" + labelNubmerCard.Text + "' ");

            Message.MessageWindowOk("Абонемент восстановлен");
        }
    }
}
