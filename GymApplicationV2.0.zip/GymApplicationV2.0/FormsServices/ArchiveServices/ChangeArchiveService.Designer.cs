﻿namespace GymApplicationV2._0.FormsServices
{
    partial class ChangeArchiveService
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.jeanModernButtonChange = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanSoftTextBoxVisits = new GymApplicationV2._0.Controls.jeanSoftTextBox();
            this.jeanSoftTextBoxTerm = new GymApplicationV2._0.Controls.jeanSoftTextBox();
            this.jeanSoftTextBoxMembership = new GymApplicationV2._0.Controls.jeanSoftTextBox();
            this.jeanSoftTextBoxClient = new GymApplicationV2._0.Controls.jeanSoftTextBox();
            this.jeanSoftTextBoxCost = new GymApplicationV2._0.Controls.jeanSoftTextBox();
            this.jeanSoftTextBoxCard = new GymApplicationV2._0.Controls.jeanSoftTextBox();
            this.jeanModernButton1 = new GymApplicationV2._0.Controls.JeanModernButton();
            this.SuspendLayout();
            // 
            // jeanModernButtonChange
            // 
            this.jeanModernButtonChange.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonChange.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonChange.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButtonChange.BorderRadius = 20;
            this.jeanModernButtonChange.BorderSize = 2;
            this.jeanModernButtonChange.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonChange.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonChange.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonChange.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonChange.Location = new System.Drawing.Point(131, 412);
            this.jeanModernButtonChange.Name = "jeanModernButtonChange";
            this.jeanModernButtonChange.Size = new System.Drawing.Size(150, 45);
            this.jeanModernButtonChange.TabIndex = 29;
            this.jeanModernButtonChange.Text = "Изменить";
            this.jeanModernButtonChange.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonChange.UseVisualStyleBackColor = false;
            this.jeanModernButtonChange.Click += new System.EventHandler(this.jeanModernButtonChange_Click);
            // 
            // jeanSoftTextBoxVisits
            // 
            this.jeanSoftTextBoxVisits.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanSoftTextBoxVisits.BorderFocusColor = System.Drawing.Color.HotPink;
            this.jeanSoftTextBoxVisits.BorderRadius = 0;
            this.jeanSoftTextBoxVisits.BorderSize = 2;
            this.jeanSoftTextBoxVisits.Location = new System.Drawing.Point(89, 289);
            this.jeanSoftTextBoxVisits.Margin = new System.Windows.Forms.Padding(4);
            this.jeanSoftTextBoxVisits.Multiline = false;
            this.jeanSoftTextBoxVisits.Name = "jeanSoftTextBoxVisits";
            this.jeanSoftTextBoxVisits.Padding = new System.Windows.Forms.Padding(5);
            this.jeanSoftTextBoxVisits.PasswordChar = false;
            this.jeanSoftTextBoxVisits.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.jeanSoftTextBoxVisits.PlaceholderText = "";
            this.jeanSoftTextBoxVisits.Size = new System.Drawing.Size(250, 30);
            this.jeanSoftTextBoxVisits.TabIndex = 28;
            this.jeanSoftTextBoxVisits.Texts = "";
            this.jeanSoftTextBoxVisits.UnderlinedStyle = false;
            // 
            // jeanSoftTextBoxTerm
            // 
            this.jeanSoftTextBoxTerm.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanSoftTextBoxTerm.BorderFocusColor = System.Drawing.Color.HotPink;
            this.jeanSoftTextBoxTerm.BorderRadius = 0;
            this.jeanSoftTextBoxTerm.BorderSize = 2;
            this.jeanSoftTextBoxTerm.Location = new System.Drawing.Point(89, 237);
            this.jeanSoftTextBoxTerm.Margin = new System.Windows.Forms.Padding(4);
            this.jeanSoftTextBoxTerm.Multiline = false;
            this.jeanSoftTextBoxTerm.Name = "jeanSoftTextBoxTerm";
            this.jeanSoftTextBoxTerm.Padding = new System.Windows.Forms.Padding(5);
            this.jeanSoftTextBoxTerm.PasswordChar = false;
            this.jeanSoftTextBoxTerm.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.jeanSoftTextBoxTerm.PlaceholderText = "";
            this.jeanSoftTextBoxTerm.Size = new System.Drawing.Size(250, 30);
            this.jeanSoftTextBoxTerm.TabIndex = 27;
            this.jeanSoftTextBoxTerm.Texts = "";
            this.jeanSoftTextBoxTerm.UnderlinedStyle = false;
            // 
            // jeanSoftTextBoxMembership
            // 
            this.jeanSoftTextBoxMembership.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanSoftTextBoxMembership.BorderFocusColor = System.Drawing.Color.HotPink;
            this.jeanSoftTextBoxMembership.BorderRadius = 0;
            this.jeanSoftTextBoxMembership.BorderSize = 2;
            this.jeanSoftTextBoxMembership.Location = new System.Drawing.Point(89, 187);
            this.jeanSoftTextBoxMembership.Margin = new System.Windows.Forms.Padding(4);
            this.jeanSoftTextBoxMembership.Multiline = false;
            this.jeanSoftTextBoxMembership.Name = "jeanSoftTextBoxMembership";
            this.jeanSoftTextBoxMembership.Padding = new System.Windows.Forms.Padding(5);
            this.jeanSoftTextBoxMembership.PasswordChar = false;
            this.jeanSoftTextBoxMembership.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.jeanSoftTextBoxMembership.PlaceholderText = "";
            this.jeanSoftTextBoxMembership.Size = new System.Drawing.Size(250, 30);
            this.jeanSoftTextBoxMembership.TabIndex = 26;
            this.jeanSoftTextBoxMembership.Texts = "";
            this.jeanSoftTextBoxMembership.UnderlinedStyle = false;
            // 
            // jeanSoftTextBoxClient
            // 
            this.jeanSoftTextBoxClient.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanSoftTextBoxClient.BorderFocusColor = System.Drawing.Color.HotPink;
            this.jeanSoftTextBoxClient.BorderRadius = 0;
            this.jeanSoftTextBoxClient.BorderSize = 2;
            this.jeanSoftTextBoxClient.Location = new System.Drawing.Point(89, 78);
            this.jeanSoftTextBoxClient.Margin = new System.Windows.Forms.Padding(4);
            this.jeanSoftTextBoxClient.Multiline = false;
            this.jeanSoftTextBoxClient.Name = "jeanSoftTextBoxClient";
            this.jeanSoftTextBoxClient.Padding = new System.Windows.Forms.Padding(5);
            this.jeanSoftTextBoxClient.PasswordChar = false;
            this.jeanSoftTextBoxClient.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.jeanSoftTextBoxClient.PlaceholderText = "";
            this.jeanSoftTextBoxClient.Size = new System.Drawing.Size(250, 30);
            this.jeanSoftTextBoxClient.TabIndex = 32;
            this.jeanSoftTextBoxClient.Texts = "";
            this.jeanSoftTextBoxClient.UnderlinedStyle = false;
            // 
            // jeanSoftTextBoxCost
            // 
            this.jeanSoftTextBoxCost.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanSoftTextBoxCost.BorderFocusColor = System.Drawing.Color.HotPink;
            this.jeanSoftTextBoxCost.BorderRadius = 0;
            this.jeanSoftTextBoxCost.BorderSize = 2;
            this.jeanSoftTextBoxCost.Location = new System.Drawing.Point(89, 340);
            this.jeanSoftTextBoxCost.Margin = new System.Windows.Forms.Padding(4);
            this.jeanSoftTextBoxCost.Multiline = false;
            this.jeanSoftTextBoxCost.Name = "jeanSoftTextBoxCost";
            this.jeanSoftTextBoxCost.Padding = new System.Windows.Forms.Padding(5);
            this.jeanSoftTextBoxCost.PasswordChar = false;
            this.jeanSoftTextBoxCost.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.jeanSoftTextBoxCost.PlaceholderText = "";
            this.jeanSoftTextBoxCost.Size = new System.Drawing.Size(250, 30);
            this.jeanSoftTextBoxCost.TabIndex = 31;
            this.jeanSoftTextBoxCost.Texts = "";
            this.jeanSoftTextBoxCost.UnderlinedStyle = false;
            // 
            // jeanSoftTextBoxCard
            // 
            this.jeanSoftTextBoxCard.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanSoftTextBoxCard.BorderFocusColor = System.Drawing.Color.HotPink;
            this.jeanSoftTextBoxCard.BorderRadius = 0;
            this.jeanSoftTextBoxCard.BorderSize = 2;
            this.jeanSoftTextBoxCard.Location = new System.Drawing.Point(89, 132);
            this.jeanSoftTextBoxCard.Margin = new System.Windows.Forms.Padding(4);
            this.jeanSoftTextBoxCard.Multiline = false;
            this.jeanSoftTextBoxCard.Name = "jeanSoftTextBoxCard";
            this.jeanSoftTextBoxCard.Padding = new System.Windows.Forms.Padding(5);
            this.jeanSoftTextBoxCard.PasswordChar = false;
            this.jeanSoftTextBoxCard.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.jeanSoftTextBoxCard.PlaceholderText = "";
            this.jeanSoftTextBoxCard.Size = new System.Drawing.Size(250, 30);
            this.jeanSoftTextBoxCard.TabIndex = 30;
            this.jeanSoftTextBoxCard.Texts = "";
            this.jeanSoftTextBoxCard.UnderlinedStyle = false;
            // 
            // jeanModernButton1
            // 
            this.jeanModernButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jeanModernButton1.BackColor = System.Drawing.Color.White;
            this.jeanModernButton1.BackgroundColor = System.Drawing.Color.White;
            this.jeanModernButton1.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButton1.BorderRadius = 35;
            this.jeanModernButton1.BorderSize = 2;
            this.jeanModernButton1.FlatAppearance.BorderSize = 0;
            this.jeanModernButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButton1.ForeColor = System.Drawing.Color.Black;
            this.jeanModernButton1.Location = new System.Drawing.Point(382, 12);
            this.jeanModernButton1.Name = "jeanModernButton1";
            this.jeanModernButton1.Size = new System.Drawing.Size(40, 35);
            this.jeanModernButton1.TabIndex = 33;
            this.jeanModernButton1.Text = " X";
            this.jeanModernButton1.TextColor = System.Drawing.Color.Black;
            this.jeanModernButton1.UseVisualStyleBackColor = false;
            this.jeanModernButton1.Click += new System.EventHandler(this.jeanModernButton1_Click);
            // 
            // ChangeArchiveService
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(434, 499);
            this.Controls.Add(this.jeanModernButton1);
            this.Controls.Add(this.jeanSoftTextBoxClient);
            this.Controls.Add(this.jeanSoftTextBoxCost);
            this.Controls.Add(this.jeanSoftTextBoxCard);
            this.Controls.Add(this.jeanModernButtonChange);
            this.Controls.Add(this.jeanSoftTextBoxVisits);
            this.Controls.Add(this.jeanSoftTextBoxTerm);
            this.Controls.Add(this.jeanSoftTextBoxMembership);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ChangeArchiveService";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "ChangeArchiveService";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.ChangeArchiveService_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.ChangeArchiveService_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.ChangeArchiveService_MouseUp);
            this.ResumeLayout(false);

        }

        #endregion

        private Controls.JeanModernButton jeanModernButtonChange;
        protected internal Controls.jeanSoftTextBox jeanSoftTextBoxVisits;
        protected internal Controls.jeanSoftTextBox jeanSoftTextBoxTerm;
        protected internal Controls.jeanSoftTextBox jeanSoftTextBoxMembership;
        protected internal Controls.jeanSoftTextBox jeanSoftTextBoxClient;
        protected internal Controls.jeanSoftTextBox jeanSoftTextBoxCost;
        protected internal Controls.jeanSoftTextBox jeanSoftTextBoxCard;
        private Controls.JeanModernButton jeanModernButton1;
    }
}