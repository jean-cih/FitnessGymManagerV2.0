﻿namespace GymApplicationV2._0.FormsServices
{
    partial class ChangeArchiveService
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.jeanModernButtonChange = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanSoftTextBoxVisits = new GymApplicationV2._0.Controls.jeanSoftTextBox();
            this.jeanSoftTextBoxTerm = new GymApplicationV2._0.Controls.jeanSoftTextBox();
            this.jeanSoftTextBoxMembership = new GymApplicationV2._0.Controls.jeanSoftTextBox();
            this.jeanSoftTextBoxName = new GymApplicationV2._0.Controls.jeanSoftTextBox();
            this.jeanSoftTextBoxSurname = new GymApplicationV2._0.Controls.jeanSoftTextBox();
            this.jeanSoftTextBoxCard = new GymApplicationV2._0.Controls.jeanSoftTextBox();
            this.SuspendLayout();
            // 
            // jeanModernButtonChange
            // 
            this.jeanModernButtonChange.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonChange.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonChange.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButtonChange.BorderRadius = 20;
            this.jeanModernButtonChange.BorderSize = 2;
            this.jeanModernButtonChange.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonChange.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonChange.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonChange.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonChange.Location = new System.Drawing.Point(306, 381);
            this.jeanModernButtonChange.Name = "jeanModernButtonChange";
            this.jeanModernButtonChange.Size = new System.Drawing.Size(150, 45);
            this.jeanModernButtonChange.TabIndex = 29;
            this.jeanModernButtonChange.Text = "Изменить";
            this.jeanModernButtonChange.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonChange.UseVisualStyleBackColor = false;
            this.jeanModernButtonChange.Click += new System.EventHandler(this.jeanModernButtonChange_Click);
            // 
            // jeanSoftTextBoxVisits
            // 
            this.jeanSoftTextBoxVisits.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanSoftTextBoxVisits.BorderFocusColor = System.Drawing.Color.HotPink;
            this.jeanSoftTextBoxVisits.BorderRadius = 0;
            this.jeanSoftTextBoxVisits.BorderSize = 2;
            this.jeanSoftTextBoxVisits.Location = new System.Drawing.Point(256, 318);
            this.jeanSoftTextBoxVisits.Margin = new System.Windows.Forms.Padding(4);
            this.jeanSoftTextBoxVisits.Multiline = false;
            this.jeanSoftTextBoxVisits.Name = "jeanSoftTextBoxVisits";
            this.jeanSoftTextBoxVisits.Padding = new System.Windows.Forms.Padding(5);
            this.jeanSoftTextBoxVisits.PasswordChar = false;
            this.jeanSoftTextBoxVisits.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.jeanSoftTextBoxVisits.PlaceholderText = "";
            this.jeanSoftTextBoxVisits.Size = new System.Drawing.Size(250, 30);
            this.jeanSoftTextBoxVisits.TabIndex = 28;
            this.jeanSoftTextBoxVisits.Texts = "";
            this.jeanSoftTextBoxVisits.UnderlinedStyle = false;
            // 
            // jeanSoftTextBoxTerm
            // 
            this.jeanSoftTextBoxTerm.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanSoftTextBoxTerm.BorderFocusColor = System.Drawing.Color.HotPink;
            this.jeanSoftTextBoxTerm.BorderRadius = 0;
            this.jeanSoftTextBoxTerm.BorderSize = 2;
            this.jeanSoftTextBoxTerm.Location = new System.Drawing.Point(256, 266);
            this.jeanSoftTextBoxTerm.Margin = new System.Windows.Forms.Padding(4);
            this.jeanSoftTextBoxTerm.Multiline = false;
            this.jeanSoftTextBoxTerm.Name = "jeanSoftTextBoxTerm";
            this.jeanSoftTextBoxTerm.Padding = new System.Windows.Forms.Padding(5);
            this.jeanSoftTextBoxTerm.PasswordChar = false;
            this.jeanSoftTextBoxTerm.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.jeanSoftTextBoxTerm.PlaceholderText = "";
            this.jeanSoftTextBoxTerm.Size = new System.Drawing.Size(250, 30);
            this.jeanSoftTextBoxTerm.TabIndex = 27;
            this.jeanSoftTextBoxTerm.Texts = "";
            this.jeanSoftTextBoxTerm.UnderlinedStyle = false;
            // 
            // jeanSoftTextBoxMembership
            // 
            this.jeanSoftTextBoxMembership.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanSoftTextBoxMembership.BorderFocusColor = System.Drawing.Color.HotPink;
            this.jeanSoftTextBoxMembership.BorderRadius = 0;
            this.jeanSoftTextBoxMembership.BorderSize = 2;
            this.jeanSoftTextBoxMembership.Location = new System.Drawing.Point(256, 216);
            this.jeanSoftTextBoxMembership.Margin = new System.Windows.Forms.Padding(4);
            this.jeanSoftTextBoxMembership.Multiline = false;
            this.jeanSoftTextBoxMembership.Name = "jeanSoftTextBoxMembership";
            this.jeanSoftTextBoxMembership.Padding = new System.Windows.Forms.Padding(5);
            this.jeanSoftTextBoxMembership.PasswordChar = false;
            this.jeanSoftTextBoxMembership.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.jeanSoftTextBoxMembership.PlaceholderText = "";
            this.jeanSoftTextBoxMembership.Size = new System.Drawing.Size(250, 30);
            this.jeanSoftTextBoxMembership.TabIndex = 26;
            this.jeanSoftTextBoxMembership.Texts = "";
            this.jeanSoftTextBoxMembership.UnderlinedStyle = false;
            // 
            // jeanSoftTextBoxName
            // 
            this.jeanSoftTextBoxName.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanSoftTextBoxName.BorderFocusColor = System.Drawing.Color.HotPink;
            this.jeanSoftTextBoxName.BorderRadius = 0;
            this.jeanSoftTextBoxName.BorderSize = 2;
            this.jeanSoftTextBoxName.Location = new System.Drawing.Point(256, 107);
            this.jeanSoftTextBoxName.Margin = new System.Windows.Forms.Padding(4);
            this.jeanSoftTextBoxName.Multiline = false;
            this.jeanSoftTextBoxName.Name = "jeanSoftTextBoxName";
            this.jeanSoftTextBoxName.Padding = new System.Windows.Forms.Padding(5);
            this.jeanSoftTextBoxName.PasswordChar = false;
            this.jeanSoftTextBoxName.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.jeanSoftTextBoxName.PlaceholderText = "";
            this.jeanSoftTextBoxName.Size = new System.Drawing.Size(250, 30);
            this.jeanSoftTextBoxName.TabIndex = 32;
            this.jeanSoftTextBoxName.Texts = "";
            this.jeanSoftTextBoxName.UnderlinedStyle = false;
            // 
            // jeanSoftTextBoxSurname
            // 
            this.jeanSoftTextBoxSurname.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanSoftTextBoxSurname.BorderFocusColor = System.Drawing.Color.HotPink;
            this.jeanSoftTextBoxSurname.BorderRadius = 0;
            this.jeanSoftTextBoxSurname.BorderSize = 2;
            this.jeanSoftTextBoxSurname.Location = new System.Drawing.Point(256, 55);
            this.jeanSoftTextBoxSurname.Margin = new System.Windows.Forms.Padding(4);
            this.jeanSoftTextBoxSurname.Multiline = false;
            this.jeanSoftTextBoxSurname.Name = "jeanSoftTextBoxSurname";
            this.jeanSoftTextBoxSurname.Padding = new System.Windows.Forms.Padding(5);
            this.jeanSoftTextBoxSurname.PasswordChar = false;
            this.jeanSoftTextBoxSurname.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.jeanSoftTextBoxSurname.PlaceholderText = "";
            this.jeanSoftTextBoxSurname.Size = new System.Drawing.Size(250, 30);
            this.jeanSoftTextBoxSurname.TabIndex = 31;
            this.jeanSoftTextBoxSurname.Texts = "";
            this.jeanSoftTextBoxSurname.UnderlinedStyle = false;
            // 
            // jeanSoftTextBoxCard
            // 
            this.jeanSoftTextBoxCard.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanSoftTextBoxCard.BorderFocusColor = System.Drawing.Color.HotPink;
            this.jeanSoftTextBoxCard.BorderRadius = 0;
            this.jeanSoftTextBoxCard.BorderSize = 2;
            this.jeanSoftTextBoxCard.Location = new System.Drawing.Point(256, 161);
            this.jeanSoftTextBoxCard.Margin = new System.Windows.Forms.Padding(4);
            this.jeanSoftTextBoxCard.Multiline = false;
            this.jeanSoftTextBoxCard.Name = "jeanSoftTextBoxCard";
            this.jeanSoftTextBoxCard.Padding = new System.Windows.Forms.Padding(5);
            this.jeanSoftTextBoxCard.PasswordChar = false;
            this.jeanSoftTextBoxCard.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.jeanSoftTextBoxCard.PlaceholderText = "";
            this.jeanSoftTextBoxCard.Size = new System.Drawing.Size(250, 30);
            this.jeanSoftTextBoxCard.TabIndex = 30;
            this.jeanSoftTextBoxCard.Texts = "";
            this.jeanSoftTextBoxCard.UnderlinedStyle = false;
            // 
            // ChangeArchiveService
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.jeanSoftTextBoxName);
            this.Controls.Add(this.jeanSoftTextBoxSurname);
            this.Controls.Add(this.jeanSoftTextBoxCard);
            this.Controls.Add(this.jeanModernButtonChange);
            this.Controls.Add(this.jeanSoftTextBoxVisits);
            this.Controls.Add(this.jeanSoftTextBoxTerm);
            this.Controls.Add(this.jeanSoftTextBoxMembership);
            this.Name = "ChangeArchiveService";
            this.Text = "ChangeArchiveService";
            this.ResumeLayout(false);

        }

        #endregion

        private Controls.JeanModernButton jeanModernButtonChange;
        protected internal Controls.jeanSoftTextBox jeanSoftTextBoxVisits;
        protected internal Controls.jeanSoftTextBox jeanSoftTextBoxTerm;
        protected internal Controls.jeanSoftTextBox jeanSoftTextBoxMembership;
        protected internal Controls.jeanSoftTextBox jeanSoftTextBoxName;
        protected internal Controls.jeanSoftTextBox jeanSoftTextBoxSurname;
        protected internal Controls.jeanSoftTextBox jeanSoftTextBoxCard;
    }
}