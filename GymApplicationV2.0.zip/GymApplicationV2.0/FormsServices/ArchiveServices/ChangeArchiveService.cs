﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace GymApplicationV2._0.FormsServices
{
    public partial class ChangeArchiveService : Form
    {
        public ChangeArchiveService()
        {
            InitializeComponent();
        }

        private void jeanModernButtonChange_Click(object sender, EventArgs e)
        {
            DialogResult result = Message.MessageWindowYesNo("Вы уверены что хотите изменить данные?");

            if(result == DialogResult.No)
            {
                return;
            }

            ArchiveServicesContext.CommandDataArchive("UPDATE Archive SET " +
                    "Фамилия = '" + jeanSoftTextBoxSurname.Texts + "'," +
                    "Имя = '" + jeanSoftTextBoxName.Texts + "'," +
                    "Абонемент = '" + jeanSoftTextBoxMembership.Texts + "'," +
                    "Срок_абонемента = '" + jeanSoftTextBoxTerm.Texts + "'," +
                    "Посещений_осталось = '" + jeanSoftTextBoxVisits.Texts + "' " +
                    "WHERE №Карты = '" + jeanSoftTextBoxCard.Texts + "';");

            Message.MessageWindowOk("Данные в архиве обновлены");

            this.Close();
        }
    }
}
