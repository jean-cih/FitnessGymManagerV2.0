﻿using GymApplicationV2._0.Components;
using Microsoft.Office.Interop.Excel;
using Shadow;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace GymApplicationV2._0.FormsServices
{
    public partial class ChangeArchiveService : ShadowedForm
    {
        public ChangeArchiveService()
        {
            InitializeComponent();
        }

        private bool isMousePress = false;
        private System.Drawing.Point _clickPoint;
        private System.Drawing.Point _formStartPoint;

        private void ChangeArchiveService_MouseDown(object sender, MouseEventArgs e)
        {
            isMousePress = true;
            _clickPoint = Cursor.Position;
            _formStartPoint = Location;
        }

        private void ChangeArchiveService_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMousePress)
            {
                var cursorOffsetPoint = new System.Drawing.Point(
                    Cursor.Position.X - _clickPoint.X,
                    Cursor.Position.Y - _clickPoint.Y);

                Location = new System.Drawing.Point(
                    _formStartPoint.X + cursorOffsetPoint.X,
                    _formStartPoint.Y + cursorOffsetPoint.Y);
            }
        }

        private void ChangeArchiveService_MouseUp(object sender, MouseEventArgs e)
        {
            isMousePress = false;
            _clickPoint = System.Drawing.Point.Empty;
        }

        private void jeanModernButtonChange_Click(object sender, EventArgs e)
        {
            DialogResult result = Message.MessageWindowYesNo("Вы уверены что хотите изменить данные?");

            if(result == DialogResult.No)
            {
                return;
            }

            ArchiveServicesContext.CommandDataArchive("UPDATE Archive SET " +
                    "Фамилия = '" + jeanSoftTextBoxSurname.Texts + "'," +
                    "Имя = '" + jeanSoftTextBoxName.Texts + "'," +
                    "Абонемент = '" + jeanSoftTextBoxMembership.Texts + "'," +
                    "Срок_абонемента = '" + jeanSoftTextBoxTerm.Texts + "'," +
                    "Посещений_осталось = '" + jeanSoftTextBoxVisits.Texts + "' " +
                    "WHERE №Карты = '" + jeanSoftTextBoxCard.Texts + "';");

            Message.MessageWindowOk("Данные в архиве обновлены");

            this.Close();
        }

        private void jeanModernButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
