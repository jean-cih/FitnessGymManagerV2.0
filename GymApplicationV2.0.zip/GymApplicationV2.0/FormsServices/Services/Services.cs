﻿using System;
using System.Data.SQLite;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using GymApplicationV2._0.Components;
using GymApplicationV2._0.Connections;
using System.Data.Entity.Core.Common.CommandTrees.ExpressionBuilder;

namespace GymApplicationV2._0
{
    public partial class Services : Form
    {
        public Services()
        {
            InitializeComponent();
        }

        private void Services_Load(object sender, EventArgs e)
        {
            this.Width = Convert.ToInt32(Screen.PrimaryScreen.Bounds.Width * 0.65);
            this.Height = Convert.ToInt32(Screen.PrimaryScreen.Bounds.Height * 0.65);

            jeanPanel.Size = new Size(this.Width - 40, this.Height / 2 + 35);
            jeanModernButtonChange.Location = new System.Drawing.Point(this.Width - 150, 30);
            jeanModernButtonDelete.Location = new System.Drawing.Point(this.Width / 2, this.Height - 140);
            jeanModernButtonSell.Location = new System.Drawing.Point(this.Width / 2 - 60, this.Height - 140);
            jeanModernButtonAdd.Location = new System.Drawing.Point(this.Width / 2 - 120, this.Height - 140);
            jeanTextBoxPurchase.Location = new System.Drawing.Point(this.Width / 2 - 100, 40);

            JeanFormStyle.fStyle style = JeanFormStyle.fStyle.None;
            if (DataClass.styleForm == "UserStyle")
            {
                style = JeanFormStyle.fStyle.UserStyle;
            }
            else if (DataClass.styleForm == "SimpleDark")
            {
                style = JeanFormStyle.fStyle.SimpleDark;
            }
            else if (DataClass.styleForm == "TelegramStyle")
            {
                style = JeanFormStyle.fStyle.TelegramStyle;
            }

            jeanFormStyle.FormStyle = style;

            CheckIfDataExists();

            jeanModernButtonAdd.Font = new Font("Добавить", DataClass.sizeFontButtons);
            jeanModernButtonDelete.Font = new Font("Удалить", DataClass.sizeFontButtons);
            jeanModernButtonAdd.Font = new Font("Продать", DataClass.sizeFontButtons);

            dataGridViewServices.DefaultCellStyle.Font = new Font("Contacts", DataClass.sizeFontTables);
            dataGridViewServices.ColumnHeadersDefaultCellStyle.Font = new Font("Contacts", DataClass.sizeFontTables);
            checkBoxVisited.Font = new System.Drawing.Font("Отметить посещение сразу", DataClass.sizeFontCaptions - 2);
        }

        private void CheckIfDataExists()
        {
            if (!File.Exists("Databases\\Services.db"))
            {
                ServicesContext.CreatingDatabase();
            }
            else
            {
                dataGridViewServices.DataSource = ServicesContext.GetDataFromDatabase("SELECT Наименование, Цена, СрокДействия, Количество FROM Descriptions");
            }
        }

        string termMembership = "";
        int servicesCost = 0;
        private void dataGridViewServices_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            jeanTextBoxPurchase.Text = dataGridViewServices.SelectedRows[0].Cells[0].Value.ToString();
            termMembership = dataGridViewServices.SelectedRows[0].Cells[2].Value.ToString();
            servicesCost = Convert.ToInt32(dataGridViewServices.SelectedRows[0].Cells[1].Value.ToString());
        }

        private void buttonAddService_Click(object sender, EventArgs e)
        {
            FieldForService service = new FieldForService();
            service.ShowDialog();

            dataGridViewServices.DataSource = ServicesContext.GetDataFromDatabase("SELECT Наименование, Цена, СрокДействия, Количество FROM Descriptions");
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (jeanTextBoxPurchase.Text == "")
                return;

            DialogResult result = Message.MessageWindowYesNo("Вы действительно хотите удалить услугу?");

            if (result == DialogResult.No)
                return;
            
            ServicesContext.CommandDataServices("DELETE FROM Descriptions Where Наименование = '" + jeanTextBoxPurchase.Text + "' ");

            Message.MessageWindowOk("Услуга удалена");

            dataGridViewServices.DataSource = ServicesContext.GetDataFromDatabase("SELECT Наименование, Цена, СрокДействия, Количество FROM Descriptions");
        }

        private void buttonSell_Click(object sender, EventArgs e)
        {
            if (jeanTextBoxPurchase.Text == "")
            {
                Message.MessageWindowOk("Нужно сначала выбрать услугу");
                return;
            }
   
            object left = ServicesContext.GetElementService("SELECT Количество FROM Descriptions WHERE Наименование = '" + jeanTextBoxPurchase.Text + "';");

            int? number = null;
            if(left.ToString() != "")
                number = Convert.ToInt32(left);

            if (checkBoxVisited.Checked && number != null)
                number -= 1;

            object purchase = ClientsContext.GetElementClient("SELECT Покупки FROM Contacts WHERE №Карты = '" + labelNumberCard.Text + "';");

            int costs = 0;
            if (purchase != null)
                costs = Convert.ToInt32(purchase);

            string visit = "";
            if (checkBoxVisited.Checked)
            {
                visit = DateTime.Now.ToString();
            }

            if (labelNumberCard.Text != "")
            {
                DateTime now = DateTime.Now;

                ClientsContext.CommandDataClient("UPDATE Contacts SET " +
                    "Покупки = '" + (costs + servicesCost).ToString() + "'," +
                    "Посетил = '" + visit + "'," +
                    "Абонемент = '" + jeanTextBoxPurchase.Text + "'," +
                    "Срок_абонемента = '" + new DateTime(now.Year, now.Month + Convert.ToInt32(termMembership), now.Day) + "'," +
                    "Посещений_осталось = '" + number.ToString() + "' " +
                    "WHERE №Карты = '" + labelNumberCard.Text + "';");
            }

            object quantity = ServicesContext.GetElementService("SELECT ПроданныхЗаМесяц FROM Descriptions WHERE Наименование = '" + jeanTextBoxPurchase.Text + "';"); ;
            if (jeanTextBoxPurchase.Text != "")
            {
                ServicesContext.CommandDataServices("UPDATE Descriptions SET " +
                    "ПроданныхЗаМесяц = '" + (Convert.ToInt32(quantity) + 1).ToString() + "' " +
                    "WHERE Id = '" + jeanTextBoxPurchase.Text + "';");

                //Получение максимального id клиента
                int numberPay = GetIdFromTable(HistoryPaymentContext.ConnectionStringPayment(), "SELECT Id FROM History");                

                string fatherName = ClientsContext.GetElementClient("SELECT Отчество FROM Contacts WHERE №Карты = '" + labelNumberCard.Text + "';").ToString();

                using (SQLiteConnection conn = new SQLiteConnection(HistoryPaymentContext.ConnectionStringPayment()))
                {
                    //Добавить абонемент
                    string commandStringNew = "INSERT INTO History (" +
                    "[Id],[Клиент],[Абонемент],[Дата_начала],[Дата_окончания],[Цена],[Дата_платежа])" +
                    " VALUES (@Id,@Клиент,@Абонемент,@Дата_начала,@Дата_окончания,@Цена,@Дата_платежа)";

                    using (SQLiteCommand cmd = new SQLiteCommand(commandStringNew, conn))
                    {
                        DateTime now = DateTime.Now;

                        conn.Open();

                        cmd.Parameters.AddWithValue("@Id", numberPay);
                        cmd.Parameters.AddWithValue("@Клиент", labelName.Text + " " + fatherName);
                        cmd.Parameters.AddWithValue("@Абонемент", jeanTextBoxPurchase.Text);
                        cmd.Parameters.AddWithValue("@Дата_начала", DateTime.Now.ToString());
                        cmd.Parameters.AddWithValue("@Дата_окончания", new DateTime(now.Year, now.Month + Convert.ToInt32(termMembership), now.Day));
                        cmd.Parameters.AddWithValue("@Цена", servicesCost);
                        cmd.Parameters.AddWithValue("@Дата_платежа", DateTime.Now.ToShortDateString());

                        cmd.ExecuteNonQuery();
                    }
                }

                //Получение максимального id клиента
                int numberIssued = GetIdFromTable(IssuedMembershipContext.ConnectionStringIssued(), "SELECT Id FROM Issued");

                using (SQLiteConnection conn = new SQLiteConnection(IssuedMembershipContext.ConnectionStringIssued()))
                {
                    //Добавить абонемент в выданные
                    string commandStringNew = "INSERT INTO Issued (" +
                    "[Id],[Клиент],[№Карты],[Дата_окончания],[Дата_оформления],[Абонемент],[Оплата],[Статус],[Посещений_осталось],[Окончание_заморозки])" +
                    " VALUES (@Id,@Клиент,@№Карты,@Дата_окончания,@Дата_оформления,@Абонемент,@Оплата,@Статус,@Посещений_осталось,@Окончание_заморозки)";

                    using (SQLiteCommand cmd = new SQLiteCommand(commandStringNew, conn))
                    {
                        DateTime now = DateTime.Now;

                        conn.Open();

                        cmd.Parameters.AddWithValue("@Id", numberIssued);
                        cmd.Parameters.AddWithValue("@Клиент", labelName.Text + " " + fatherName);
                        cmd.Parameters.AddWithValue("@№Карты", labelNumberCard.Text);
                        cmd.Parameters.AddWithValue("@Дата_окончания", new DateTime(now.Year, now.Month + Convert.ToInt32(termMembership), now.Day));
                        cmd.Parameters.AddWithValue("@Дата_оформления", DateTime.Now.ToString());
                        cmd.Parameters.AddWithValue("@Абонемент", jeanTextBoxPurchase.Text);
                        cmd.Parameters.AddWithValue("@Оплата", servicesCost);
                        cmd.Parameters.AddWithValue("@Статус", "активирован");
                        cmd.Parameters.AddWithValue("@Посещений_осталось", number.ToString());
                        cmd.Parameters.AddWithValue("@Окончание_заморозки", "");

                        cmd.ExecuteNonQuery();
                    }
                }
            }

            Message.MessageWindowOk("Данные клиента обновлены");
        }

        private void jeanModernButton1_Click(object sender, EventArgs e)
        {
            if(jeanTextBoxPurchase.Text == "")
            {
                Message.MessageWindowOk("Услуга, которую нужно изменить, не выбрана");
                return;
            }
            try
            {
                object id = ServicesContext.GetElementService("SELECT Id FROM Descriptions WHERE Наименование = '" + jeanTextBoxPurchase.Text + "';");
                if(id == null)
                {
                    Message.MessageWindowOk("Такой услуги нет");
                    return;
                }
                DataClass.nameMembership = jeanTextBoxPurchase.Text;
                ChangeService changeService = new ChangeService();
                changeService.ShowDialog();

                dataGridViewServices.DataSource = ServicesContext.GetDataFromDatabase("SELECT Наименование, Цена, СрокДействия, Количество FROM Descriptions");
            }
            catch (Exception ex)
            {

            }
        }

        private int GetIdFromTable(string context, string request)
        {
            SQLiteConnection conn2 = new SQLiteConnection(context);
            conn2.Open();

            SQLiteCommand cmd2 = new SQLiteCommand(request, conn2);
            SQLiteDataReader reader = cmd2.ExecuteReader();

            object id = null;
            while (reader.Read())
            {
                id = reader[0];
            }

            reader.Close();
            cmd2.Dispose();
            conn2.Close();

            int number = 1;
            if (id != null)
            {
                number = Convert.ToInt32(id) + 1;
            }

            return number;
        }
    }
}
