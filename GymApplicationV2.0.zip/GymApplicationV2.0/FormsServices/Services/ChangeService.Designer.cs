﻿namespace GymApplicationV2._0
{
    partial class ChangeService
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.jeanModernButtonSave = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanSoftTextBoxName = new GymApplicationV2._0.Controls.jeanSoftTextBox();
            this.jeanSoftTextBoxPrice = new GymApplicationV2._0.Controls.jeanSoftTextBox();
            this.jeanSoftTextBoxQuantity = new GymApplicationV2._0.Controls.jeanSoftTextBox();
            this.jeanSoftTextBoxTerm = new GymApplicationV2._0.Controls.jeanSoftTextBox();
            this.jeanModernButton1 = new GymApplicationV2._0.Controls.JeanModernButton();
            this.dataGridViewService = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewService)).BeginInit();
            this.SuspendLayout();
            // 
            // jeanModernButtonSave
            // 
            this.jeanModernButtonSave.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonSave.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonSave.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButtonSave.BorderRadius = 20;
            this.jeanModernButtonSave.BorderSize = 2;
            this.jeanModernButtonSave.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonSave.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonSave.Location = new System.Drawing.Point(285, 374);
            this.jeanModernButtonSave.Name = "jeanModernButtonSave";
            this.jeanModernButtonSave.Size = new System.Drawing.Size(150, 55);
            this.jeanModernButtonSave.TabIndex = 55;
            this.jeanModernButtonSave.Text = "Сохранить";
            this.jeanModernButtonSave.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonSave.UseVisualStyleBackColor = false;
            this.jeanModernButtonSave.Click += new System.EventHandler(this.jeanModernButtonSave_Click);
            // 
            // jeanSoftTextBoxName
            // 
            this.jeanSoftTextBoxName.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanSoftTextBoxName.BorderFocusColor = System.Drawing.Color.HotPink;
            this.jeanSoftTextBoxName.BorderRadius = 0;
            this.jeanSoftTextBoxName.BorderSize = 2;
            this.jeanSoftTextBoxName.Location = new System.Drawing.Point(208, 163);
            this.jeanSoftTextBoxName.Margin = new System.Windows.Forms.Padding(4);
            this.jeanSoftTextBoxName.Multiline = false;
            this.jeanSoftTextBoxName.Name = "jeanSoftTextBoxName";
            this.jeanSoftTextBoxName.Padding = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.jeanSoftTextBoxName.PasswordChar = false;
            this.jeanSoftTextBoxName.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.jeanSoftTextBoxName.PlaceholderText = "";
            this.jeanSoftTextBoxName.Size = new System.Drawing.Size(303, 40);
            this.jeanSoftTextBoxName.TabIndex = 56;
            this.jeanSoftTextBoxName.Texts = "";
            this.jeanSoftTextBoxName.UnderlinedStyle = false;
            // 
            // jeanSoftTextBoxPrice
            // 
            this.jeanSoftTextBoxPrice.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanSoftTextBoxPrice.BorderFocusColor = System.Drawing.Color.HotPink;
            this.jeanSoftTextBoxPrice.BorderRadius = 0;
            this.jeanSoftTextBoxPrice.BorderSize = 2;
            this.jeanSoftTextBoxPrice.Location = new System.Drawing.Point(208, 213);
            this.jeanSoftTextBoxPrice.Margin = new System.Windows.Forms.Padding(4);
            this.jeanSoftTextBoxPrice.Multiline = false;
            this.jeanSoftTextBoxPrice.Name = "jeanSoftTextBoxPrice";
            this.jeanSoftTextBoxPrice.Padding = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.jeanSoftTextBoxPrice.PasswordChar = false;
            this.jeanSoftTextBoxPrice.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.jeanSoftTextBoxPrice.PlaceholderText = "";
            this.jeanSoftTextBoxPrice.Size = new System.Drawing.Size(303, 40);
            this.jeanSoftTextBoxPrice.TabIndex = 57;
            this.jeanSoftTextBoxPrice.Texts = "";
            this.jeanSoftTextBoxPrice.UnderlinedStyle = false;
            // 
            // jeanSoftTextBoxQuantity
            // 
            this.jeanSoftTextBoxQuantity.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanSoftTextBoxQuantity.BorderFocusColor = System.Drawing.Color.HotPink;
            this.jeanSoftTextBoxQuantity.BorderRadius = 0;
            this.jeanSoftTextBoxQuantity.BorderSize = 2;
            this.jeanSoftTextBoxQuantity.Location = new System.Drawing.Point(208, 316);
            this.jeanSoftTextBoxQuantity.Margin = new System.Windows.Forms.Padding(4);
            this.jeanSoftTextBoxQuantity.Multiline = false;
            this.jeanSoftTextBoxQuantity.Name = "jeanSoftTextBoxQuantity";
            this.jeanSoftTextBoxQuantity.Padding = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.jeanSoftTextBoxQuantity.PasswordChar = false;
            this.jeanSoftTextBoxQuantity.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.jeanSoftTextBoxQuantity.PlaceholderText = "";
            this.jeanSoftTextBoxQuantity.Size = new System.Drawing.Size(303, 40);
            this.jeanSoftTextBoxQuantity.TabIndex = 59;
            this.jeanSoftTextBoxQuantity.Texts = "";
            this.jeanSoftTextBoxQuantity.UnderlinedStyle = false;
            // 
            // jeanSoftTextBoxTerm
            // 
            this.jeanSoftTextBoxTerm.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanSoftTextBoxTerm.BorderFocusColor = System.Drawing.Color.HotPink;
            this.jeanSoftTextBoxTerm.BorderRadius = 0;
            this.jeanSoftTextBoxTerm.BorderSize = 2;
            this.jeanSoftTextBoxTerm.Location = new System.Drawing.Point(208, 265);
            this.jeanSoftTextBoxTerm.Margin = new System.Windows.Forms.Padding(4);
            this.jeanSoftTextBoxTerm.Multiline = false;
            this.jeanSoftTextBoxTerm.Name = "jeanSoftTextBoxTerm";
            this.jeanSoftTextBoxTerm.Padding = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.jeanSoftTextBoxTerm.PasswordChar = false;
            this.jeanSoftTextBoxTerm.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.jeanSoftTextBoxTerm.PlaceholderText = "";
            this.jeanSoftTextBoxTerm.Size = new System.Drawing.Size(303, 40);
            this.jeanSoftTextBoxTerm.TabIndex = 58;
            this.jeanSoftTextBoxTerm.Texts = "";
            this.jeanSoftTextBoxTerm.UnderlinedStyle = false;
            // 
            // jeanModernButton1
            // 
            this.jeanModernButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jeanModernButton1.BackColor = System.Drawing.Color.White;
            this.jeanModernButton1.BackgroundColor = System.Drawing.Color.White;
            this.jeanModernButton1.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButton1.BorderRadius = 20;
            this.jeanModernButton1.BorderSize = 2;
            this.jeanModernButton1.FlatAppearance.BorderSize = 0;
            this.jeanModernButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButton1.ForeColor = System.Drawing.Color.Black;
            this.jeanModernButton1.Location = new System.Drawing.Point(660, 12);
            this.jeanModernButton1.Name = "jeanModernButton1";
            this.jeanModernButton1.Size = new System.Drawing.Size(40, 35);
            this.jeanModernButton1.TabIndex = 60;
            this.jeanModernButton1.Text = " X";
            this.jeanModernButton1.TextColor = System.Drawing.Color.Black;
            this.jeanModernButton1.UseVisualStyleBackColor = false;
            this.jeanModernButton1.Click += new System.EventHandler(this.jeanModernButton1_Click);
            // 
            // dataGridViewService
            // 
            this.dataGridViewService.AllowUserToAddRows = false;
            this.dataGridViewService.AllowUserToDeleteRows = false;
            this.dataGridViewService.AllowUserToResizeColumns = false;
            this.dataGridViewService.AllowUserToResizeRows = false;
            this.dataGridViewService.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewService.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewService.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewService.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewService.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridViewService.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(230)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(230)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewService.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewService.ColumnHeadersHeight = 25;
            this.dataGridViewService.Enabled = false;
            this.dataGridViewService.EnableHeadersVisualStyles = false;
            this.dataGridViewService.GridColor = System.Drawing.Color.Black;
            this.dataGridViewService.Location = new System.Drawing.Point(35, 66);
            this.dataGridViewService.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridViewService.MultiSelect = false;
            this.dataGridViewService.Name = "dataGridViewService";
            this.dataGridViewService.ReadOnly = true;
            this.dataGridViewService.RowHeadersVisible = false;
            this.dataGridViewService.RowHeadersWidth = 40;
            this.dataGridViewService.RowTemplate.Height = 24;
            this.dataGridViewService.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewService.Size = new System.Drawing.Size(642, 79);
            this.dataGridViewService.TabIndex = 61;
            // 
            // ChangeService
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(712, 453);
            this.Controls.Add(this.dataGridViewService);
            this.Controls.Add(this.jeanModernButton1);
            this.Controls.Add(this.jeanSoftTextBoxQuantity);
            this.Controls.Add(this.jeanSoftTextBoxTerm);
            this.Controls.Add(this.jeanSoftTextBoxPrice);
            this.Controls.Add(this.jeanSoftTextBoxName);
            this.Controls.Add(this.jeanModernButtonSave);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ChangeService";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "ChangeService";
            this.Load += new System.EventHandler(this.ChangeService_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.ChangeService_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.ChangeService_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.ChangeService_MouseUp);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewService)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        protected internal Controls.JeanModernButton jeanModernButtonSave;
        private Controls.jeanSoftTextBox jeanSoftTextBoxName;
        private Controls.jeanSoftTextBox jeanSoftTextBoxPrice;
        private Controls.jeanSoftTextBox jeanSoftTextBoxQuantity;
        private Controls.jeanSoftTextBox jeanSoftTextBoxTerm;
        private Controls.JeanModernButton jeanModernButton1;
        private System.Windows.Forms.DataGridView dataGridViewService;
    }
}