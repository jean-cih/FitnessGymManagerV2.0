﻿namespace GymApplicationV2._0
{
    partial class Services
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Services));
            this.dataGridViewServices = new System.Windows.Forms.DataGridView();
            this.labelName = new System.Windows.Forms.Label();
            this.labelNumberCard = new System.Windows.Forms.Label();
            this.checkBoxVisited = new System.Windows.Forms.CheckBox();
            this.jeanModernButtonChange = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanModernButtonSell = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanModernButtonAdd = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanTextBoxPurchase = new GymApplicationV2._0.JeanTextBox();
            this.jeanModernButtonDelete = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanFormStyle = new GymApplicationV2._0.Components.JeanFormStyle(this.components);
            this.jeanPanel = new GymApplicationV2._0.Controls.JeanPanel();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewServices)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewServices
            // 
            this.dataGridViewServices.AllowUserToAddRows = false;
            this.dataGridViewServices.AllowUserToDeleteRows = false;
            this.dataGridViewServices.AllowUserToResizeColumns = false;
            this.dataGridViewServices.AllowUserToResizeRows = false;
            this.dataGridViewServices.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewServices.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewServices.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewServices.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewServices.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridViewServices.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(230)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(230)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewServices.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewServices.ColumnHeadersHeight = 35;
            this.dataGridViewServices.EnableHeadersVisualStyles = false;
            this.dataGridViewServices.GridColor = System.Drawing.Color.Black;
            this.dataGridViewServices.Location = new System.Drawing.Point(29, 114);
            this.dataGridViewServices.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridViewServices.Name = "dataGridViewServices";
            this.dataGridViewServices.ReadOnly = true;
            this.dataGridViewServices.RowHeadersVisible = false;
            this.dataGridViewServices.RowHeadersWidth = 50;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            this.dataGridViewServices.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewServices.RowTemplate.Height = 24;
            this.dataGridViewServices.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewServices.Size = new System.Drawing.Size(1123, 357);
            this.dataGridViewServices.TabIndex = 0;
            this.dataGridViewServices.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewServices_CellContentClick);
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelName.Location = new System.Drawing.Point(37, 60);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(0, 20);
            this.labelName.TabIndex = 20;
            this.labelName.Visible = false;
            // 
            // labelNumberCard
            // 
            this.labelNumberCard.AutoSize = true;
            this.labelNumberCard.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelNumberCard.Location = new System.Drawing.Point(72, 87);
            this.labelNumberCard.Name = "labelNumberCard";
            this.labelNumberCard.Size = new System.Drawing.Size(0, 20);
            this.labelNumberCard.TabIndex = 22;
            this.labelNumberCard.Visible = false;
            // 
            // checkBoxVisited
            // 
            this.checkBoxVisited.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.checkBoxVisited.AutoSize = true;
            this.checkBoxVisited.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBoxVisited.Location = new System.Drawing.Point(858, 526);
            this.checkBoxVisited.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkBoxVisited.Name = "checkBoxVisited";
            this.checkBoxVisited.Size = new System.Drawing.Size(209, 20);
            this.checkBoxVisited.TabIndex = 37;
            this.checkBoxVisited.Text = "Отметить посещение сразу";
            this.checkBoxVisited.UseVisualStyleBackColor = true;
            this.checkBoxVisited.Visible = false;
            // 
            // jeanModernButtonChange
            // 
            this.jeanModernButtonChange.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.jeanModernButtonChange.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonChange.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonChange.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButtonChange.BorderRadius = 20;
            this.jeanModernButtonChange.BorderSize = 2;
            this.jeanModernButtonChange.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonChange.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonChange.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonChange.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonChange.Location = new System.Drawing.Point(1002, 36);
            this.jeanModernButtonChange.Name = "jeanModernButtonChange";
            this.jeanModernButtonChange.Size = new System.Drawing.Size(150, 55);
            this.jeanModernButtonChange.TabIndex = 53;
            this.jeanModernButtonChange.Text = "Изменить";
            this.jeanModernButtonChange.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonChange.UseVisualStyleBackColor = false;
            this.jeanModernButtonChange.Click += new System.EventHandler(this.jeanModernButton1_Click);
            // 
            // jeanModernButtonSell
            // 
            this.jeanModernButtonSell.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.jeanModernButtonSell.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonSell.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonSell.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButtonSell.BorderRadius = 20;
            this.jeanModernButtonSell.BorderSize = 2;
            this.jeanModernButtonSell.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonSell.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonSell.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonSell.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonSell.Location = new System.Drawing.Point(514, 507);
            this.jeanModernButtonSell.Name = "jeanModernButtonSell";
            this.jeanModernButtonSell.Size = new System.Drawing.Size(150, 55);
            this.jeanModernButtonSell.TabIndex = 51;
            this.jeanModernButtonSell.Text = "Продать";
            this.jeanModernButtonSell.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonSell.UseVisualStyleBackColor = false;
            this.jeanModernButtonSell.Visible = false;
            this.jeanModernButtonSell.Click += new System.EventHandler(this.buttonSell_Click);
            // 
            // jeanModernButtonAdd
            // 
            this.jeanModernButtonAdd.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.jeanModernButtonAdd.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonAdd.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonAdd.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButtonAdd.BorderRadius = 20;
            this.jeanModernButtonAdd.BorderSize = 2;
            this.jeanModernButtonAdd.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonAdd.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonAdd.Location = new System.Drawing.Point(435, 507);
            this.jeanModernButtonAdd.Name = "jeanModernButtonAdd";
            this.jeanModernButtonAdd.Size = new System.Drawing.Size(150, 55);
            this.jeanModernButtonAdd.TabIndex = 50;
            this.jeanModernButtonAdd.Text = "Добавить";
            this.jeanModernButtonAdd.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonAdd.UseVisualStyleBackColor = false;
            this.jeanModernButtonAdd.Click += new System.EventHandler(this.buttonAddService_Click);
            // 
            // jeanTextBoxPurchase
            // 
            this.jeanTextBoxPurchase.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.jeanTextBoxPurchase.BackColor = System.Drawing.Color.White;
            this.jeanTextBoxPurchase.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBoxPurchase.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBoxPurchase.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBoxPurchase.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBoxPurchase.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBoxPurchase.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBoxPurchase.Location = new System.Drawing.Point(460, 52);
            this.jeanTextBoxPurchase.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.jeanTextBoxPurchase.Name = "jeanTextBoxPurchase";
            this.jeanTextBoxPurchase.SelectionStart = 0;
            this.jeanTextBoxPurchase.Size = new System.Drawing.Size(255, 39);
            this.jeanTextBoxPurchase.TabIndex = 44;
            this.jeanTextBoxPurchase.TextInput = "";
            this.jeanTextBoxPurchase.TextPreview = "Услуга";
            this.jeanTextBoxPurchase.UseSystemPasswordChar = false;
            // 
            // jeanModernButtonDelete
            // 
            this.jeanModernButtonDelete.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.jeanModernButtonDelete.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonDelete.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonDelete.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButtonDelete.BorderRadius = 20;
            this.jeanModernButtonDelete.BorderSize = 2;
            this.jeanModernButtonDelete.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonDelete.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonDelete.Location = new System.Drawing.Point(591, 507);
            this.jeanModernButtonDelete.Name = "jeanModernButtonDelete";
            this.jeanModernButtonDelete.Size = new System.Drawing.Size(150, 55);
            this.jeanModernButtonDelete.TabIndex = 52;
            this.jeanModernButtonDelete.Text = "Удалить";
            this.jeanModernButtonDelete.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonDelete.UseVisualStyleBackColor = false;
            this.jeanModernButtonDelete.Click += new System.EventHandler(this.buttonDelete_Click);
            // 
            // jeanFormStyle
            // 
            this.jeanFormStyle.AllowUserResize = false;
            this.jeanFormStyle.BackColor = System.Drawing.Color.White;
            this.jeanFormStyle.ContextMenuForm = null;
            this.jeanFormStyle.ControlBoxButtonsWidth = 20;
            this.jeanFormStyle.EnableControlBoxIconsLight = false;
            this.jeanFormStyle.EnableControlBoxMouseLight = false;
            this.jeanFormStyle.Form = this;
            this.jeanFormStyle.FormStyle = GymApplicationV2._0.Components.JeanFormStyle.fStyle.None;
            this.jeanFormStyle.HeaderColor = System.Drawing.Color.Black;
            this.jeanFormStyle.HeaderColorAdditional = System.Drawing.Color.DarkOrange;
            this.jeanFormStyle.HeaderColorGradientEnable = true;
            this.jeanFormStyle.HeaderColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.jeanFormStyle.HeaderHeight = 30;
            this.jeanFormStyle.HeaderImage = null;
            this.jeanFormStyle.HeaderTextColor = System.Drawing.Color.White;
            this.jeanFormStyle.HeaderTextFont = new System.Drawing.Font("Segoe UI", 9.75F);
            // 
            // jeanPanel
            // 
            this.jeanPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.jeanPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            this.jeanPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.jeanPanel.BorderRadius = 30;
            this.jeanPanel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.jeanPanel.GradientAngle = 90F;
            this.jeanPanel.GradientBottomColor = System.Drawing.Color.DodgerBlue;
            this.jeanPanel.GradientTapColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            this.jeanPanel.Location = new System.Drawing.Point(12, 107);
            this.jeanPanel.Name = "jeanPanel";
            this.jeanPanel.Size = new System.Drawing.Size(1157, 377);
            this.jeanPanel.TabIndex = 54;
            // 
            // Services
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1181, 674);
            this.Controls.Add(this.dataGridViewServices);
            this.Controls.Add(this.jeanPanel);
            this.Controls.Add(this.jeanModernButtonChange);
            this.Controls.Add(this.jeanModernButtonSell);
            this.Controls.Add(this.jeanModernButtonAdd);
            this.Controls.Add(this.jeanTextBoxPurchase);
            this.Controls.Add(this.checkBoxVisited);
            this.Controls.Add(this.labelNumberCard);
            this.Controls.Add(this.labelName);
            this.Controls.Add(this.jeanModernButtonDelete);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Services";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Услуги";
            this.Load += new System.EventHandler(this.Services_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewServices)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        protected internal System.Windows.Forms.DataGridView dataGridViewServices;
        protected internal System.Windows.Forms.Label labelName;
        protected internal System.Windows.Forms.Label labelNumberCard;
        protected internal System.Windows.Forms.CheckBox checkBoxVisited;
        protected internal JeanTextBox jeanTextBoxPurchase;
        protected internal Controls.JeanModernButton jeanModernButtonAdd;
        protected internal Controls.JeanModernButton jeanModernButtonSell;
        protected internal Controls.JeanModernButton jeanModernButtonDelete;
        protected internal Controls.JeanModernButton jeanModernButtonChange;
        private Components.JeanFormStyle jeanFormStyle;
        private Controls.JeanPanel jeanPanel;
    }
}