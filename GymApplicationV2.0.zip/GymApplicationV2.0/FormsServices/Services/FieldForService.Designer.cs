﻿namespace GymApplicationV2._0
{
    partial class FieldForService
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FieldForService));
            this.jeanTextBoxVisited = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBoxTerm = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBoxPrice = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBoxName = new GymApplicationV2._0.JeanTextBox();
            this.jeanModernButtonAdd = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanModernButton1 = new GymApplicationV2._0.Controls.JeanModernButton();
            this.SuspendLayout();
            // 
            // jeanTextBoxVisited
            // 
            this.jeanTextBoxVisited.BackColor = System.Drawing.Color.White;
            this.jeanTextBoxVisited.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBoxVisited.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBoxVisited.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBoxVisited.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBoxVisited.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBoxVisited.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBoxVisited.Location = new System.Drawing.Point(29, 308);
            this.jeanTextBoxVisited.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.jeanTextBoxVisited.Name = "jeanTextBoxVisited";
            this.jeanTextBoxVisited.SelectionStart = 0;
            this.jeanTextBoxVisited.Size = new System.Drawing.Size(251, 39);
            this.jeanTextBoxVisited.TabIndex = 42;
            this.jeanTextBoxVisited.TextInput = "";
            this.jeanTextBoxVisited.TextPreview = "Количество посещений";
            this.jeanTextBoxVisited.UseSystemPasswordChar = false;
            // 
            // jeanTextBoxTerm
            // 
            this.jeanTextBoxTerm.BackColor = System.Drawing.Color.White;
            this.jeanTextBoxTerm.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBoxTerm.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBoxTerm.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBoxTerm.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBoxTerm.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBoxTerm.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBoxTerm.Location = new System.Drawing.Point(29, 228);
            this.jeanTextBoxTerm.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.jeanTextBoxTerm.Name = "jeanTextBoxTerm";
            this.jeanTextBoxTerm.SelectionStart = 0;
            this.jeanTextBoxTerm.Size = new System.Drawing.Size(220, 39);
            this.jeanTextBoxTerm.TabIndex = 41;
            this.jeanTextBoxTerm.TextInput = "";
            this.jeanTextBoxTerm.TextPreview = "Срок Действия (Мес)";
            this.jeanTextBoxTerm.UseSystemPasswordChar = false;
            // 
            // jeanTextBoxPrice
            // 
            this.jeanTextBoxPrice.BackColor = System.Drawing.Color.White;
            this.jeanTextBoxPrice.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBoxPrice.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBoxPrice.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBoxPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBoxPrice.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBoxPrice.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBoxPrice.Location = new System.Drawing.Point(29, 154);
            this.jeanTextBoxPrice.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.jeanTextBoxPrice.Name = "jeanTextBoxPrice";
            this.jeanTextBoxPrice.SelectionStart = 0;
            this.jeanTextBoxPrice.Size = new System.Drawing.Size(189, 39);
            this.jeanTextBoxPrice.TabIndex = 40;
            this.jeanTextBoxPrice.TextInput = "";
            this.jeanTextBoxPrice.TextPreview = "Цена";
            this.jeanTextBoxPrice.UseSystemPasswordChar = false;
            // 
            // jeanTextBoxName
            // 
            this.jeanTextBoxName.BackColor = System.Drawing.Color.White;
            this.jeanTextBoxName.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBoxName.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBoxName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBoxName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBoxName.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBoxName.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBoxName.Location = new System.Drawing.Point(29, 80);
            this.jeanTextBoxName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.jeanTextBoxName.Name = "jeanTextBoxName";
            this.jeanTextBoxName.SelectionStart = 0;
            this.jeanTextBoxName.Size = new System.Drawing.Size(352, 39);
            this.jeanTextBoxName.TabIndex = 39;
            this.jeanTextBoxName.TextInput = "";
            this.jeanTextBoxName.TextPreview = "Наименование";
            this.jeanTextBoxName.UseSystemPasswordChar = false;
            // 
            // jeanModernButtonAdd
            // 
            this.jeanModernButtonAdd.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonAdd.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonAdd.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButtonAdd.BorderRadius = 20;
            this.jeanModernButtonAdd.BorderSize = 2;
            this.jeanModernButtonAdd.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonAdd.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonAdd.Location = new System.Drawing.Point(118, 455);
            this.jeanModernButtonAdd.Name = "jeanModernButtonAdd";
            this.jeanModernButtonAdd.Size = new System.Drawing.Size(150, 55);
            this.jeanModernButtonAdd.TabIndex = 43;
            this.jeanModernButtonAdd.Text = "Добавить";
            this.jeanModernButtonAdd.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonAdd.UseVisualStyleBackColor = false;
            this.jeanModernButtonAdd.Click += new System.EventHandler(this.buttonSave_Click);
            // 
            // jeanModernButton1
            // 
            this.jeanModernButton1.BackColor = System.Drawing.Color.White;
            this.jeanModernButton1.BackgroundColor = System.Drawing.Color.White;
            this.jeanModernButton1.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButton1.BorderRadius = 20;
            this.jeanModernButton1.BorderSize = 2;
            this.jeanModernButton1.FlatAppearance.BorderSize = 0;
            this.jeanModernButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButton1.ForeColor = System.Drawing.Color.Black;
            this.jeanModernButton1.Location = new System.Drawing.Point(352, 12);
            this.jeanModernButton1.Name = "jeanModernButton1";
            this.jeanModernButton1.Size = new System.Drawing.Size(40, 35);
            this.jeanModernButton1.TabIndex = 44;
            this.jeanModernButton1.Text = " X";
            this.jeanModernButton1.TextColor = System.Drawing.Color.Black;
            this.jeanModernButton1.UseVisualStyleBackColor = false;
            this.jeanModernButton1.Click += new System.EventHandler(this.jeanModernButton1_Click);
            // 
            // FieldForService
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(404, 548);
            this.Controls.Add(this.jeanModernButton1);
            this.Controls.Add(this.jeanModernButtonAdd);
            this.Controls.Add(this.jeanTextBoxVisited);
            this.Controls.Add(this.jeanTextBoxTerm);
            this.Controls.Add(this.jeanTextBoxPrice);
            this.Controls.Add(this.jeanTextBoxName);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "FieldForService";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Добавление Услуги";
            this.Load += new System.EventHandler(this.FieldForService_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.FieldForService_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.FieldForService_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.FieldForService_MouseUp);
            this.ResumeLayout(false);

        }

        #endregion
        private JeanTextBox jeanTextBoxName;
        private JeanTextBox jeanTextBoxPrice;
        private JeanTextBox jeanTextBoxTerm;
        private JeanTextBox jeanTextBoxVisited;
        private Controls.JeanModernButton jeanModernButtonAdd;
        private Controls.JeanModernButton jeanModernButton1;
    }
}