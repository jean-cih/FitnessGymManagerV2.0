﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using GymApplicationV2._0.Components;

namespace GymApplicationV2._0
{
    public partial class HistoryPayment : Form
    {
        public HistoryPayment()
        {
            InitializeComponent();
        }

        private void HistoryPayment_Load(object sender, EventArgs e)
        {
            JeanFormStyle.fStyle style = JeanFormStyle.fStyle.None;
            if (DataClass.styleForm == "UserStyle")
            {
                style = JeanFormStyle.fStyle.UserStyle;
            }
            else if (DataClass.styleForm == "SimpleDark")
            {
                style = JeanFormStyle.fStyle.SimpleDark;
            }
            else if (DataClass.styleForm == "TelegramStyle")
            {
                style = JeanFormStyle.fStyle.TelegramStyle;
            }

            jeanFormStyle.FormStyle = style;

            dataGridViewHistory.DataSource = HistoryPaymentContext.GetDataFromDatabase("SELECT * FROM History");
            labelPayments.Text = "Платежей за период: " + HistoryPaymentContext.GetElementPayment("SELECT COUNT(*) FROM History").ToString();
        }

        private void jeanModernButtonShow_Click(object sender, EventArgs e)
        {
            object allPayments = null;
            DateTime now = DateTime.Now;

            if (radioForMonth.Checked)
            {
                var beginMonth = new DateTime(now.Year, now.Month, 1);
                //Нужно изменить Дата_начала на время платежа
                dataGridViewHistory.DataSource = HistoryPaymentContext.GetDataFromDatabase($"SELECT * FROM History WHERE Дата_начала BETWEEN '{beginMonth}' AND '{DateTime.Now}' ORDER BY Дата_начала");

                allPayments = HistoryPaymentContext.GetElementPayment($"SELECT COUNT(*) FROM History WHERE Дата_начала BETWEEN '{beginMonth}' AND '{DateTime.Now}'");
            }
            else if (radioForWeek.Checked)
            {
                var startLastWeek = new DateTime(now.Year, now.Month, now.Day - (int)now.DayOfWeek + 1);

                dataGridViewHistory.DataSource = HistoryPaymentContext.GetDataFromDatabase($"SELECT * FROM History WHERE Дата_начала BETWEEN '{startLastWeek}' AND '{DateTime.Now}' ORDER BY Дата_начала");

                allPayments = HistoryPaymentContext.GetElementPayment($"SELECT COUNT(*) FROM History WHERE Дата_начала BETWEEN '{startLastWeek}' AND '{DateTime.Now}'");
            }
            else if (radioForDay.Checked)
            {
                var startPreviousDay = new DateTime(now.Year, now.Month, now.Day);

                dataGridViewHistory.DataSource = HistoryPaymentContext.GetDataFromDatabase($"SELECT * FROM History WHERE Дата_начала BETWEEN '{startPreviousDay}' AND '{DateTime.Now}' ORDER BY Дата_начала");

                allPayments = HistoryPaymentContext.GetElementPayment($"SELECT COUNT(*) FROM History WHERE Дата_начала BETWEEN '{startPreviousDay}' AND '{DateTime.Now}'");
            }
            else
            {
                dataGridViewHistory.DataSource = HistoryPaymentContext.GetDataFromDatabase($"SELECT * FROM History WHERE Дата_начала BETWEEN '{dateTimePickerBegin.Value}' AND '{dateTimePickerEnd.Value}' ORDER BY Дата_начала");

                allPayments = HistoryPaymentContext.GetElementPayment($"SELECT COUNT(*) FROM History WHERE Дата_начала BETWEEN '{dateTimePickerBegin.Value}' AND '{dateTimePickerEnd.Value}'");
            }

            labelPayments.Text = "Платежей за период: " + allPayments.ToString();
        }

        private void jeanModernButtonRefresh_Click(object sender, EventArgs e)
        {
            dataGridViewHistory.DataSource = HistoryPaymentContext.GetDataFromDatabase("SELECT * FROM History");
            labelPayments.Text = "Платежей за период: " + HistoryPaymentContext.GetElementPayment("SELECT COUNT(*) FROM History").ToString();
        }
    }
}
