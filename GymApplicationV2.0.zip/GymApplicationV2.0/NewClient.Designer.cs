﻿namespace GymApplicationV2._0
{
    partial class NewClient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NewClient));
            this.textNumber = new System.Windows.Forms.TextBox();
            this.textName = new System.Windows.Forms.TextBox();
            this.textSurname = new System.Windows.Forms.TextBox();
            this.dateTimePickerClient = new System.Windows.Forms.DateTimePicker();
            this.labelNumber = new System.Windows.Forms.Label();
            this.labelName = new System.Windows.Forms.Label();
            this.labelSurname = new System.Windows.Forms.Label();
            this.buttonSave = new System.Windows.Forms.Button();
            this.labelNameCard = new System.Windows.Forms.Label();
            this.textNumberCard = new System.Windows.Forms.TextBox();
            this.buttonClients = new System.Windows.Forms.Button();
            this.dataGridViewServices = new System.Windows.Forms.DataGridView();
            this.labelPurchase = new System.Windows.Forms.Label();
            this.textPurchase = new System.Windows.Forms.TextBox();
            this.labelFather = new System.Windows.Forms.Label();
            this.textFather = new System.Windows.Forms.TextBox();
            this.radioButtonWoman = new System.Windows.Forms.RadioButton();
            this.radioButtonMan = new System.Windows.Forms.RadioButton();
            this.labelBirthday = new System.Windows.Forms.Label();
            this.labelDiscount = new System.Windows.Forms.Label();
            this.textDiscount = new System.Windows.Forms.TextBox();
            this.textBirthday = new System.Windows.Forms.TextBox();
            this.checkBoxVisited = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewServices)).BeginInit();
            this.SuspendLayout();
            // 
            // textNumber
            // 
            this.textNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textNumber.Location = new System.Drawing.Point(45, 63);
            this.textNumber.Name = "textNumber";
            this.textNumber.Size = new System.Drawing.Size(156, 27);
            this.textNumber.TabIndex = 0;
            // 
            // textName
            // 
            this.textName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textName.Location = new System.Drawing.Point(45, 127);
            this.textName.Name = "textName";
            this.textName.Size = new System.Drawing.Size(300, 30);
            this.textName.TabIndex = 1;
            // 
            // textSurname
            // 
            this.textSurname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textSurname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textSurname.Location = new System.Drawing.Point(45, 202);
            this.textSurname.Name = "textSurname";
            this.textSurname.Size = new System.Drawing.Size(300, 30);
            this.textSurname.TabIndex = 3;
            // 
            // dateTimePickerClient
            // 
            this.dateTimePickerClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dateTimePickerClient.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerClient.Location = new System.Drawing.Point(701, 414);
            this.dateTimePickerClient.Name = "dateTimePickerClient";
            this.dateTimePickerClient.Size = new System.Drawing.Size(125, 27);
            this.dateTimePickerClient.TabIndex = 4;
            // 
            // labelNumber
            // 
            this.labelNumber.AutoSize = true;
            this.labelNumber.Location = new System.Drawing.Point(48, 40);
            this.labelNumber.Name = "labelNumber";
            this.labelNumber.Size = new System.Drawing.Size(67, 16);
            this.labelNumber.TabIndex = 5;
            this.labelNumber.Text = "Телефон";
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Location = new System.Drawing.Point(48, 105);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(33, 16);
            this.labelName.TabIndex = 6;
            this.labelName.Text = "Имя";
            // 
            // labelSurname
            // 
            this.labelSurname.AutoSize = true;
            this.labelSurname.Location = new System.Drawing.Point(48, 181);
            this.labelSurname.Name = "labelSurname";
            this.labelSurname.Size = new System.Drawing.Size(66, 16);
            this.labelSurname.TabIndex = 8;
            this.labelSurname.Text = "Фамилия";
            // 
            // buttonSave
            // 
            this.buttonSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSave.Location = new System.Drawing.Point(414, 549);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new System.Drawing.Size(150, 55);
            this.buttonSave.TabIndex = 9;
            this.buttonSave.Text = "Сохранить";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
            // 
            // labelNameCard
            // 
            this.labelNameCard.AutoSize = true;
            this.labelNameCard.Location = new System.Drawing.Point(48, 385);
            this.labelNameCard.Name = "labelNameCard";
            this.labelNameCard.Size = new System.Drawing.Size(93, 16);
            this.labelNameCard.TabIndex = 11;
            this.labelNameCard.Text = "Номер Карты";
            // 
            // textNumberCard
            // 
            this.textNumberCard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textNumberCard.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textNumberCard.Location = new System.Drawing.Point(45, 407);
            this.textNumberCard.Name = "textNumberCard";
            this.textNumberCard.Size = new System.Drawing.Size(300, 30);
            this.textNumberCard.TabIndex = 10;
            // 
            // buttonClients
            // 
            this.buttonClients.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonClients.Location = new System.Drawing.Point(577, 549);
            this.buttonClients.Name = "buttonClients";
            this.buttonClients.Size = new System.Drawing.Size(150, 55);
            this.buttonClients.TabIndex = 15;
            this.buttonClients.Text = "Клиенты";
            this.buttonClients.UseVisualStyleBackColor = true;
            this.buttonClients.Click += new System.EventHandler(this.buttonClients_Click);
            // 
            // dataGridViewServices
            // 
            this.dataGridViewServices.AllowUserToAddRows = false;
            this.dataGridViewServices.AllowUserToDeleteRows = false;
            this.dataGridViewServices.AllowUserToResizeColumns = false;
            this.dataGridViewServices.AllowUserToResizeRows = false;
            this.dataGridViewServices.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewServices.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewServices.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewServices.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridViewServices.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewServices.Location = new System.Drawing.Point(430, 146);
            this.dataGridViewServices.Name = "dataGridViewServices";
            this.dataGridViewServices.RowHeadersWidth = 40;
            this.dataGridViewServices.RowTemplate.Height = 24;
            this.dataGridViewServices.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewServices.Size = new System.Drawing.Size(647, 262);
            this.dataGridViewServices.TabIndex = 23;
            this.dataGridViewServices.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewServices_CellContentClick);
            // 
            // labelPurchase
            // 
            this.labelPurchase.AutoSize = true;
            this.labelPurchase.Location = new System.Drawing.Point(560, 118);
            this.labelPurchase.Name = "labelPurchase";
            this.labelPurchase.Size = new System.Drawing.Size(56, 16);
            this.labelPurchase.TabIndex = 25;
            this.labelPurchase.Text = "Услуга:";
            // 
            // textPurchase
            // 
            this.textPurchase.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textPurchase.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textPurchase.Location = new System.Drawing.Point(622, 113);
            this.textPurchase.Name = "textPurchase";
            this.textPurchase.Size = new System.Drawing.Size(255, 27);
            this.textPurchase.TabIndex = 24;
            // 
            // labelFather
            // 
            this.labelFather.AutoSize = true;
            this.labelFather.Location = new System.Drawing.Point(48, 247);
            this.labelFather.Name = "labelFather";
            this.labelFather.Size = new System.Drawing.Size(70, 16);
            this.labelFather.TabIndex = 28;
            this.labelFather.Text = "Отчество";
            // 
            // textFather
            // 
            this.textFather.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textFather.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textFather.Location = new System.Drawing.Point(45, 268);
            this.textFather.Name = "textFather";
            this.textFather.Size = new System.Drawing.Size(300, 30);
            this.textFather.TabIndex = 27;
            // 
            // radioButtonWoman
            // 
            this.radioButtonWoman.AutoSize = true;
            this.radioButtonWoman.Location = new System.Drawing.Point(131, 337);
            this.radioButtonWoman.Name = "radioButtonWoman";
            this.radioButtonWoman.Size = new System.Drawing.Size(53, 20);
            this.radioButtonWoman.TabIndex = 30;
            this.radioButtonWoman.Text = "жен";
            this.radioButtonWoman.UseVisualStyleBackColor = true;
            // 
            // radioButtonMan
            // 
            this.radioButtonMan.AutoSize = true;
            this.radioButtonMan.Location = new System.Drawing.Point(69, 337);
            this.radioButtonMan.Name = "radioButtonMan";
            this.radioButtonMan.Size = new System.Drawing.Size(54, 20);
            this.radioButtonMan.TabIndex = 29;
            this.radioButtonMan.Text = "муж";
            this.radioButtonMan.UseVisualStyleBackColor = true;
            // 
            // labelBirthday
            // 
            this.labelBirthday.AutoSize = true;
            this.labelBirthday.Location = new System.Drawing.Point(221, 316);
            this.labelBirthday.Name = "labelBirthday";
            this.labelBirthday.Size = new System.Drawing.Size(106, 16);
            this.labelBirthday.TabIndex = 32;
            this.labelBirthday.Text = "Дата рождения";
            // 
            // labelDiscount
            // 
            this.labelDiscount.AutoSize = true;
            this.labelDiscount.Location = new System.Drawing.Point(835, 40);
            this.labelDiscount.Name = "labelDiscount";
            this.labelDiscount.Size = new System.Drawing.Size(173, 16);
            this.labelDiscount.TabIndex = 34;
            this.labelDiscount.Text = "Персональная скидка (%)";
            // 
            // textDiscount
            // 
            this.textDiscount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textDiscount.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textDiscount.Location = new System.Drawing.Point(1018, 35);
            this.textDiscount.Name = "textDiscount";
            this.textDiscount.Size = new System.Drawing.Size(59, 27);
            this.textDiscount.TabIndex = 33;
            // 
            // textBirthday
            // 
            this.textBirthday.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBirthday.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBirthday.Location = new System.Drawing.Point(224, 337);
            this.textBirthday.Name = "textBirthday";
            this.textBirthday.Size = new System.Drawing.Size(121, 27);
            this.textBirthday.TabIndex = 35;
            // 
            // checkBoxVisited
            // 
            this.checkBoxVisited.AutoSize = true;
            this.checkBoxVisited.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBoxVisited.Location = new System.Drawing.Point(93, 448);
            this.checkBoxVisited.Name = "checkBoxVisited";
            this.checkBoxVisited.Size = new System.Drawing.Size(209, 20);
            this.checkBoxVisited.TabIndex = 36;
            this.checkBoxVisited.Text = "Отметить посещение сразу";
            this.checkBoxVisited.UseVisualStyleBackColor = true;
            // 
            // NewClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1130, 648);
            this.Controls.Add(this.checkBoxVisited);
            this.Controls.Add(this.textBirthday);
            this.Controls.Add(this.labelDiscount);
            this.Controls.Add(this.textDiscount);
            this.Controls.Add(this.labelBirthday);
            this.Controls.Add(this.radioButtonWoman);
            this.Controls.Add(this.radioButtonMan);
            this.Controls.Add(this.labelFather);
            this.Controls.Add(this.textFather);
            this.Controls.Add(this.labelPurchase);
            this.Controls.Add(this.textPurchase);
            this.Controls.Add(this.dataGridViewServices);
            this.Controls.Add(this.buttonClients);
            this.Controls.Add(this.labelNameCard);
            this.Controls.Add(this.textNumberCard);
            this.Controls.Add(this.buttonSave);
            this.Controls.Add(this.labelSurname);
            this.Controls.Add(this.labelName);
            this.Controls.Add(this.labelNumber);
            this.Controls.Add(this.dateTimePickerClient);
            this.Controls.Add(this.textSurname);
            this.Controls.Add(this.textName);
            this.Controls.Add(this.textNumber);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "NewClient";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Новый Клиент";
            this.Load += new System.EventHandler(this.NewClient_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewServices)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DateTimePicker dateTimePickerClient;
        private System.Windows.Forms.Label labelNumber;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Label labelSurname;
        private System.Windows.Forms.Button buttonSave;
        private System.Windows.Forms.Label labelNameCard;
        protected internal System.Windows.Forms.TextBox textNumber;
        protected internal System.Windows.Forms.TextBox textName;
        protected internal System.Windows.Forms.TextBox textSurname;
        protected internal System.Windows.Forms.TextBox textNumberCard;
        private System.Windows.Forms.Button buttonClients;
        private System.Windows.Forms.DataGridView dataGridViewServices;
        private System.Windows.Forms.Label labelPurchase;
        protected internal System.Windows.Forms.TextBox textPurchase;
        private System.Windows.Forms.Label labelFather;
        protected internal System.Windows.Forms.TextBox textFather;
        private System.Windows.Forms.RadioButton radioButtonWoman;
        private System.Windows.Forms.RadioButton radioButtonMan;
        private System.Windows.Forms.Label labelBirthday;
        private System.Windows.Forms.Label labelDiscount;
        protected internal System.Windows.Forms.TextBox textDiscount;
        protected internal System.Windows.Forms.TextBox textBirthday;
        private System.Windows.Forms.CheckBox checkBoxVisited;
    }
}