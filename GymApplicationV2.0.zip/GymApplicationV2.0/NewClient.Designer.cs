﻿namespace GymApplicationV2._0
{
    partial class NewClient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textNumber = new System.Windows.Forms.TextBox();
            this.textName = new System.Windows.Forms.TextBox();
            this.textSurname = new System.Windows.Forms.TextBox();
            this.dateTimePickerClient = new System.Windows.Forms.DateTimePicker();
            this.labelNumber = new System.Windows.Forms.Label();
            this.labelName = new System.Windows.Forms.Label();
            this.labelSurname = new System.Windows.Forms.Label();
            this.buttonSave = new System.Windows.Forms.Button();
            this.labelNameCard = new System.Windows.Forms.Label();
            this.textNumberCard = new System.Windows.Forms.TextBox();
            this.comboGender = new System.Windows.Forms.ComboBox();
            this.buttonClients = new System.Windows.Forms.Button();
            this.labelSex = new System.Windows.Forms.Label();
            this.markVisitYes = new System.Windows.Forms.RadioButton();
            this.markVisitNo = new System.Windows.Forms.RadioButton();
            this.labelMarkVisitNow = new System.Windows.Forms.Label();
            this.dataGridViewServices = new System.Windows.Forms.DataGridView();
            this.labelPurchase = new System.Windows.Forms.Label();
            this.textPurchaseId = new System.Windows.Forms.TextBox();
            this.labelNameService = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewServices)).BeginInit();
            this.SuspendLayout();
            // 
            // textNumber
            // 
            this.textNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textNumber.Location = new System.Drawing.Point(45, 51);
            this.textNumber.Name = "textNumber";
            this.textNumber.Size = new System.Drawing.Size(156, 27);
            this.textNumber.TabIndex = 0;
            // 
            // textName
            // 
            this.textName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textName.Location = new System.Drawing.Point(45, 123);
            this.textName.Name = "textName";
            this.textName.Size = new System.Drawing.Size(300, 30);
            this.textName.TabIndex = 1;
            // 
            // textSurname
            // 
            this.textSurname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textSurname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textSurname.Location = new System.Drawing.Point(45, 198);
            this.textSurname.Name = "textSurname";
            this.textSurname.Size = new System.Drawing.Size(300, 30);
            this.textSurname.TabIndex = 3;
            // 
            // dateTimePickerClient
            // 
            this.dateTimePickerClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dateTimePickerClient.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerClient.Location = new System.Drawing.Point(220, 267);
            this.dateTimePickerClient.Name = "dateTimePickerClient";
            this.dateTimePickerClient.Size = new System.Drawing.Size(125, 27);
            this.dateTimePickerClient.TabIndex = 4;
            // 
            // labelNumber
            // 
            this.labelNumber.AutoSize = true;
            this.labelNumber.Location = new System.Drawing.Point(48, 28);
            this.labelNumber.Name = "labelNumber";
            this.labelNumber.Size = new System.Drawing.Size(67, 16);
            this.labelNumber.TabIndex = 5;
            this.labelNumber.Text = "Телефон";
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Location = new System.Drawing.Point(48, 101);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(33, 16);
            this.labelName.TabIndex = 6;
            this.labelName.Text = "Имя";
            // 
            // labelSurname
            // 
            this.labelSurname.AutoSize = true;
            this.labelSurname.Location = new System.Drawing.Point(48, 177);
            this.labelSurname.Name = "labelSurname";
            this.labelSurname.Size = new System.Drawing.Size(66, 16);
            this.labelSurname.TabIndex = 8;
            this.labelSurname.Text = "Фамилия";
            // 
            // buttonSave
            // 
            this.buttonSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSave.Location = new System.Drawing.Point(335, 467);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new System.Drawing.Size(150, 55);
            this.buttonSave.TabIndex = 9;
            this.buttonSave.Text = "Сохранить";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
            // 
            // labelNameCard
            // 
            this.labelNameCard.AutoSize = true;
            this.labelNameCard.Location = new System.Drawing.Point(48, 322);
            this.labelNameCard.Name = "labelNameCard";
            this.labelNameCard.Size = new System.Drawing.Size(93, 16);
            this.labelNameCard.TabIndex = 11;
            this.labelNameCard.Text = "Номер Карты";
            // 
            // textNumberCard
            // 
            this.textNumberCard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textNumberCard.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textNumberCard.Location = new System.Drawing.Point(45, 344);
            this.textNumberCard.Name = "textNumberCard";
            this.textNumberCard.Size = new System.Drawing.Size(300, 30);
            this.textNumberCard.TabIndex = 10;
            // 
            // comboGender
            // 
            this.comboGender.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboGender.FormattingEnabled = true;
            this.comboGender.Items.AddRange(new object[] {
            "Мужской",
            "Женский",
            " "});
            this.comboGender.Location = new System.Drawing.Point(45, 267);
            this.comboGender.Name = "comboGender";
            this.comboGender.Size = new System.Drawing.Size(169, 25);
            this.comboGender.TabIndex = 14;
            // 
            // buttonClients
            // 
            this.buttonClients.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonClients.Location = new System.Drawing.Point(498, 467);
            this.buttonClients.Name = "buttonClients";
            this.buttonClients.Size = new System.Drawing.Size(150, 55);
            this.buttonClients.TabIndex = 15;
            this.buttonClients.Text = "Клиенты";
            this.buttonClients.UseVisualStyleBackColor = true;
            this.buttonClients.Click += new System.EventHandler(this.buttonClients_Click);
            // 
            // labelSex
            // 
            this.labelSex.AutoSize = true;
            this.labelSex.Location = new System.Drawing.Point(49, 248);
            this.labelSex.Name = "labelSex";
            this.labelSex.Size = new System.Drawing.Size(33, 16);
            this.labelSex.TabIndex = 19;
            this.labelSex.Text = "Пол";
            // 
            // markVisitYes
            // 
            this.markVisitYes.AutoSize = true;
            this.markVisitYes.Location = new System.Drawing.Point(139, 419);
            this.markVisitYes.Name = "markVisitYes";
            this.markVisitYes.Size = new System.Drawing.Size(45, 20);
            this.markVisitYes.TabIndex = 20;
            this.markVisitYes.Text = "Да";
            this.markVisitYes.UseVisualStyleBackColor = true;
            // 
            // markVisitNo
            // 
            this.markVisitNo.AutoSize = true;
            this.markVisitNo.Checked = true;
            this.markVisitNo.Location = new System.Drawing.Point(201, 419);
            this.markVisitNo.Name = "markVisitNo";
            this.markVisitNo.Size = new System.Drawing.Size(53, 20);
            this.markVisitNo.TabIndex = 21;
            this.markVisitNo.TabStop = true;
            this.markVisitNo.Text = "Нет";
            this.markVisitNo.UseVisualStyleBackColor = true;
            // 
            // labelMarkVisitNow
            // 
            this.labelMarkVisitNow.AutoSize = true;
            this.labelMarkVisitNow.Location = new System.Drawing.Point(102, 398);
            this.labelMarkVisitNow.Name = "labelMarkVisitNow";
            this.labelMarkVisitNow.Size = new System.Drawing.Size(187, 16);
            this.labelMarkVisitNow.TabIndex = 22;
            this.labelMarkVisitNow.Text = "Отметить посещение сразу";
            // 
            // dataGridViewServices
            // 
            this.dataGridViewServices.AllowUserToAddRows = false;
            this.dataGridViewServices.AllowUserToDeleteRows = false;
            this.dataGridViewServices.AllowUserToResizeColumns = false;
            this.dataGridViewServices.AllowUserToResizeRows = false;
            this.dataGridViewServices.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewServices.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewServices.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridViewServices.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewServices.Location = new System.Drawing.Point(392, 123);
            this.dataGridViewServices.Name = "dataGridViewServices";
            this.dataGridViewServices.RowHeadersWidth = 51;
            this.dataGridViewServices.RowTemplate.Height = 24;
            this.dataGridViewServices.Size = new System.Drawing.Size(553, 251);
            this.dataGridViewServices.TabIndex = 23;
            // 
            // labelPurchase
            // 
            this.labelPurchase.AutoSize = true;
            this.labelPurchase.Location = new System.Drawing.Point(597, 56);
            this.labelPurchase.Name = "labelPurchase";
            this.labelPurchase.Size = new System.Drawing.Size(67, 16);
            this.labelPurchase.TabIndex = 25;
            this.labelPurchase.Text = "Услуга Id";
            // 
            // textPurchaseId
            // 
            this.textPurchaseId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textPurchaseId.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textPurchaseId.Location = new System.Drawing.Point(594, 79);
            this.textPurchaseId.Name = "textPurchaseId";
            this.textPurchaseId.Size = new System.Drawing.Size(156, 27);
            this.textPurchaseId.TabIndex = 24;
            // 
            // labelNameService
            // 
            this.labelNameService.AutoSize = true;
            this.labelNameService.Location = new System.Drawing.Point(618, 28);
            this.labelNameService.Name = "labelNameService";
            this.labelNameService.Size = new System.Drawing.Size(65, 16);
            this.labelNameService.TabIndex = 26;
            this.labelNameService.Text = "Разовый";
            this.labelNameService.Visible = false;
            // 
            // NewClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(982, 553);
            this.Controls.Add(this.labelNameService);
            this.Controls.Add(this.labelPurchase);
            this.Controls.Add(this.textPurchaseId);
            this.Controls.Add(this.dataGridViewServices);
            this.Controls.Add(this.labelMarkVisitNow);
            this.Controls.Add(this.markVisitNo);
            this.Controls.Add(this.markVisitYes);
            this.Controls.Add(this.labelSex);
            this.Controls.Add(this.buttonClients);
            this.Controls.Add(this.comboGender);
            this.Controls.Add(this.labelNameCard);
            this.Controls.Add(this.textNumberCard);
            this.Controls.Add(this.buttonSave);
            this.Controls.Add(this.labelSurname);
            this.Controls.Add(this.labelName);
            this.Controls.Add(this.labelNumber);
            this.Controls.Add(this.dateTimePickerClient);
            this.Controls.Add(this.textSurname);
            this.Controls.Add(this.textName);
            this.Controls.Add(this.textNumber);
            this.Name = "NewClient";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Новый Клиент";
            this.Load += new System.EventHandler(this.NewClient_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewServices)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DateTimePicker dateTimePickerClient;
        private System.Windows.Forms.Label labelNumber;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Label labelSurname;
        private System.Windows.Forms.Button buttonSave;
        private System.Windows.Forms.Label labelNameCard;
        protected internal System.Windows.Forms.TextBox textNumber;
        protected internal System.Windows.Forms.TextBox textName;
        protected internal System.Windows.Forms.TextBox textSurname;
        protected internal System.Windows.Forms.TextBox textNumberCard;
        private System.Windows.Forms.ComboBox comboGender;
        private System.Windows.Forms.Button buttonClients;
        private System.Windows.Forms.Label labelSex;
        private System.Windows.Forms.RadioButton markVisitYes;
        private System.Windows.Forms.RadioButton markVisitNo;
        private System.Windows.Forms.Label labelMarkVisitNow;
        private System.Windows.Forms.DataGridView dataGridViewServices;
        private System.Windows.Forms.Label labelPurchase;
        protected internal System.Windows.Forms.TextBox textPurchaseId;
        private System.Windows.Forms.Label labelNameService;
    }
}