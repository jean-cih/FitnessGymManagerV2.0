﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Office.Interop.Excel;
using System.IO;

namespace GymApplicationV2._0
{
    public partial class Settings : Form
    {
        string filePath = "";
        SplashScreen splashScreen = new SplashScreen();
        public Settings()
        {
            InitializeComponent();
        }

        private void Settings_Load(object sender, EventArgs e)
        {
            comboBoxFontButtons.Text = DataClass.sizeFontButtons.ToString();
            jeanModernButtonChooseFile.Font = new System.Drawing.Font("Выбрать файл", DataClass.sizeFontButtons);
            jeanModernButtonImport.Font = new System.Drawing.Font("Загрузить", DataClass.sizeFontButtons);

            comboBoxFontTables.Text = DataClass.sizeFontTables.ToString();

            comboBoxFontCaptions.Text = DataClass.sizeFontCaptions.ToString();
            labelImport.Font = new System.Drawing.Font("Импортировать данные", DataClass.sizeFontCaptions);
            labelFontCaptions.Font = new System.Drawing.Font("Размер шрифта надписей", DataClass.sizeFontCaptions);
            labelFontButtons.Font = new System.Drawing.Font("Размер шрифта кнопок", DataClass.sizeFontCaptions);
            labelFontTables.Font = new System.Drawing.Font("Размер шрифта  таблицы", DataClass.sizeFontCaptions);
        }

        private void ImportData(IProgress<string> progress)
        {
            progress.Report("    Подготовление    ");
            Microsoft.Office.Interop.Excel.Application excelApp = new Microsoft.Office.Interop.Excel.Application();
            Workbook workbook = excelApp.Workbooks.Open(filePath);
            Worksheet worksheet = (Worksheet)workbook.Worksheets[1];

            System.Data.DataTable dataTable = new System.Data.DataTable();
            for (int i = 1; i <= worksheet.UsedRange.Columns.Count; i++)
            {
                dataTable.Columns.Add(worksheet.Cells[1, i].Value2.ToString());
            }

            for (int i = 2; i <= worksheet.UsedRange.Rows.Count; i++)
            {

                progress.Report($"Компонентов: {i}/{worksheet.UsedRange.Rows.Count}");
                DataRow row = dataTable.NewRow();
                for (int j = 1; j <= worksheet.UsedRange.Columns.Count; j++)
                {
                    row[j - 1] = worksheet.Cells[i, j].Value2;
                }
                dataTable.Rows.Add(row);
            }

            SQLiteConnection connection = new SQLiteConnection(ClientsContext.ConnectionStringClients());
            connection.Open();
            string createTableQuery = $"CREATE TABLE Contacts (";

            for (int i = 0; i < dataTable.Columns.Count; i++)
            {
                createTableQuery += $"{dataTable.Columns[i].ColumnName} TEXT";
                if (i < dataTable.Columns.Count - 1)
                {
                    createTableQuery += ", ";
                }
            }
            createTableQuery += ")";
            SQLiteCommand createTableCommand = new SQLiteCommand(createTableQuery, connection);
            createTableCommand.ExecuteNonQuery();

            using (SQLiteTransaction transaction = connection.BeginTransaction())
            {
                int i = 0;
                foreach (DataRow row in dataTable.Rows)
                {
                    string insertQuery = $"INSERT INTO Contacts VALUES (";
                    for (int j = 0; j < dataTable.Columns.Count; j++)
                    {
                        insertQuery += $"'{row[j]}'";
                        if (j < dataTable.Columns.Count - 1)
                        {
                            insertQuery += ", ";
                        }
                    }
                    insertQuery += ")";
                    SQLiteCommand insertCommand = new SQLiteCommand(insertQuery, connection);
                    insertCommand.ExecuteNonQuery();
                    i++;
                }
                transaction.Commit();
            }

            connection.Close();
            workbook.Close();
            excelApp.Quit();
        }

        private void UpdateLoadingScreen(string message)
        {
            splashScreen.labelCountImport.Text = message;
        }

        private void comboBoxFont_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataClass.sizeFontButtons = Convert.ToInt32(comboBoxFontButtons.Text);
            jeanModernButtonChooseFile.Font = new System.Drawing.Font("Выбрать файл", DataClass.sizeFontButtons);
            jeanModernButtonImport.Font = new System.Drawing.Font("Загрузить", DataClass.sizeFontButtons);
        }

        private void comboBoxFontTables_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataClass.sizeFontTables = Convert.ToInt32(comboBoxFontTables.Text);
        }

        private void comboBoxFontCaptions_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataClass.sizeFontCaptions = Convert.ToInt32(comboBoxFontCaptions.Text);
        }

        private void jeanModernButtonChooseFile_Click(object sender, EventArgs e)
        {
            var openFileDialog = new OpenFileDialog()
            {
                Filter = "Database | *.xls; *.xlsx;"
            };

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                filePath = openFileDialog.FileName;
            }
        }

        private async void jeanModernButtonImport_Click(object sender, EventArgs e)
        {
            if (filePath == "")
            {
                Message.MessageWindowOk("Файл не выбран");
                return;
            }

            if (File.Exists("Databases\\Clients.db"))
            {
                Message.MessageWindowOk("Таблица уже существует");
                return;
            }

            splashScreen.Show();

            var progress = new Progress<string>(UpdateLoadingScreen);

            await Task.Run(() => ImportData(progress));

            splashScreen.Close();

            Message.MessageWindowOk("Готово");
        }
    }
}
