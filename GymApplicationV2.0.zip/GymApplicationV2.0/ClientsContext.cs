﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace GymApplicationV2._0
{
    public class ClientsContext
    {
        public static string ConnectionStringClients()
        {
            return "Data Source=Databases\\Clients.db;Version=3";
        }

        public static DataTable GetDataFromDatabase(string commandString)
        {
            DataTable dtContacts = new DataTable();
            using (SQLiteConnection conn = new SQLiteConnection(ConnectionStringClients()))
            {
                using (SQLiteCommand cmd = new SQLiteCommand(commandString, conn))
                {
                    conn.Open();

                    SQLiteDataReader reader = cmd.ExecuteReader();

                    dtContacts.Load(reader);
                }
            }

            return dtContacts;
        }

        public static void CreatingDatabase()
        {
            SQLiteConnection.CreateFile("Databases\\Clients.db");

            using (SQLiteConnection conn = new SQLiteConnection(ConnectionStringClients()))
            {
                string commandString = "CREATE TABLE Contacts(Id NVARINT(100000), Фамилия NVARCHAR(20), Имя NVARCHAR(20)," +
                    " Пол NVARCHAR(20), Телефон NVARCHAR(20), №Карты NVARCHAR(20)," +
                    " Покупки NVARCHAR(20), Посетил NVARCHAR(20), Абонемент NVARCHAR(100)," +
                    " Срок_абонемента NVARCHAR(20), Посещений_осталось NVARCHAR(20), Отчество NVARCHAR(20)," +
                    " Email NVARCHAR(100), Дата_рождения NVARCHAR(20), Скидка NVARCHAR(10), Сохранено NVARCHAR(20))";
                using (SQLiteCommand cmd = new SQLiteCommand(commandString, conn))
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public static object GetElementClient(string requireLine)
        {
            using (SQLiteConnection conn = new SQLiteConnection(ConnectionStringClients()))
            {
                string commandString = requireLine;
                using (SQLiteCommand cmd = new SQLiteCommand(commandString, conn))
                {
                    conn.Open();

                    return cmd.ExecuteScalar();
                }
            }
        }

        public static void CommandDataClient(string command)
        {
            using (SQLiteConnection conn = new SQLiteConnection(ConnectionStringClients()))
            {
                string commandString = command;

                using (SQLiteCommand cmd = new SQLiteCommand(commandString, conn))
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }
        }
    }
}
