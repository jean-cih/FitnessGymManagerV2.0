﻿namespace GymApplicationV2._0
{
    partial class ChooseClient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.labelSearch = new System.Windows.Forms.Label();
            this.textSearch = new System.Windows.Forms.TextBox();
            this.dataGridViewClients = new System.Windows.Forms.DataGridView();
            this.jeanModernButtonRefresh = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanModernButtonChoose = new GymApplicationV2._0.Controls.JeanModernButton();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewClients)).BeginInit();
            this.SuspendLayout();
            // 
            // labelSearch
            // 
            this.labelSearch.AutoSize = true;
            this.labelSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelSearch.Location = new System.Drawing.Point(464, 50);
            this.labelSearch.Name = "labelSearch";
            this.labelSearch.Size = new System.Drawing.Size(60, 20);
            this.labelSearch.TabIndex = 39;
            this.labelSearch.Text = "Поиск";
            // 
            // textSearch
            // 
            this.textSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textSearch.Location = new System.Drawing.Point(537, 46);
            this.textSearch.Name = "textSearch";
            this.textSearch.Size = new System.Drawing.Size(266, 27);
            this.textSearch.TabIndex = 38;
            this.textSearch.TextChanged += new System.EventHandler(this.textSearch_TextChanged);
            // 
            // dataGridViewClients
            // 
            this.dataGridViewClients.AllowUserToAddRows = false;
            this.dataGridViewClients.AllowUserToDeleteRows = false;
            this.dataGridViewClients.AllowUserToResizeColumns = false;
            this.dataGridViewClients.AllowUserToResizeRows = false;
            this.dataGridViewClients.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewClients.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewClients.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewClients.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewClients.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewClients.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewClients.DefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridViewClients.GridColor = System.Drawing.Color.Black;
            this.dataGridViewClients.Location = new System.Drawing.Point(26, 90);
            this.dataGridViewClients.Name = "dataGridViewClients";
            this.dataGridViewClients.ReadOnly = true;
            this.dataGridViewClients.RowHeadersWidth = 40;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            this.dataGridViewClients.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridViewClients.RowTemplate.Height = 24;
            this.dataGridViewClients.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewClients.Size = new System.Drawing.Size(1353, 569);
            this.dataGridViewClients.TabIndex = 37;
            this.dataGridViewClients.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewClients_CellContentClick);
            // 
            // jeanModernButtonRefresh
            // 
            this.jeanModernButtonRefresh.BackColor = System.Drawing.Color.White;
            this.jeanModernButtonRefresh.BackgroundColor = System.Drawing.Color.White;
            this.jeanModernButtonRefresh.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButtonRefresh.BorderRadius = 20;
            this.jeanModernButtonRefresh.BorderSize = 2;
            this.jeanModernButtonRefresh.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonRefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonRefresh.ForeColor = System.Drawing.Color.Black;
            this.jeanModernButtonRefresh.Location = new System.Drawing.Point(820, 36);
            this.jeanModernButtonRefresh.Name = "jeanModernButtonRefresh";
            this.jeanModernButtonRefresh.Size = new System.Drawing.Size(142, 45);
            this.jeanModernButtonRefresh.TabIndex = 42;
            this.jeanModernButtonRefresh.Text = "Обновить";
            this.jeanModernButtonRefresh.TextColor = System.Drawing.Color.Black;
            this.jeanModernButtonRefresh.UseVisualStyleBackColor = false;
            this.jeanModernButtonRefresh.Click += new System.EventHandler(this.jeanModernButtonRefresh_Click);
            // 
            // jeanModernButtonChoose
            // 
            this.jeanModernButtonChoose.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonChoose.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonChoose.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButtonChoose.BorderRadius = 20;
            this.jeanModernButtonChoose.BorderSize = 2;
            this.jeanModernButtonChoose.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonChoose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonChoose.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonChoose.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonChoose.Location = new System.Drawing.Point(637, 677);
            this.jeanModernButtonChoose.Name = "jeanModernButtonChoose";
            this.jeanModernButtonChoose.Size = new System.Drawing.Size(166, 55);
            this.jeanModernButtonChoose.TabIndex = 44;
            this.jeanModernButtonChoose.Text = "Выбрать";
            this.jeanModernButtonChoose.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonChoose.UseVisualStyleBackColor = false;
            this.jeanModernButtonChoose.Click += new System.EventHandler(this.buttonChoose_Click);
            // 
            // ChooseClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1404, 748);
            this.Controls.Add(this.jeanModernButtonChoose);
            this.Controls.Add(this.jeanModernButtonRefresh);
            this.Controls.Add(this.labelSearch);
            this.Controls.Add(this.textSearch);
            this.Controls.Add(this.dataGridViewClients);
            this.Name = "ChooseClient";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ChooseClient";
            this.Load += new System.EventHandler(this.ChooseClient_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewClients)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label labelSearch;
        protected internal System.Windows.Forms.TextBox textSearch;
        protected internal System.Windows.Forms.DataGridView dataGridViewClients;
        private Controls.JeanModernButton jeanModernButtonRefresh;
        private Controls.JeanModernButton jeanModernButtonChoose;
    }
}