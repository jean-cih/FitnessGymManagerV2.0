﻿using GymApplicationV2._0.Components;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymApplicationV2._0
{
    static class DataClass
    {
        public static bool AllClients;
        public static bool ClientsForPeriod;
        public static bool SellServices;

        public static DateTime Begin;
        public static DateTime End;

        public static bool PeriodForMonth;
        public static bool PeriodForWeek;
        public static bool PeriodForDay;
        public static bool OtherPeriod;

        public static int importString = 0;

        public static int sizeFontButtons = 10;
        public static int sizeFontTables = 10;
        public static int sizeFontCaptions = 10;

        public static string nameMembership;

        public static string styleForm = "None";

        public static string themeMode = "LightMode";
    }
}
