﻿using GymApplicationV2._0.Components;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymApplicationV2._0
{
    static class DataClass
    {
        public static bool AllClients;
        public static bool ClientsForPeriod;
        public static bool SellServices;

        public static DateTime Begin;
        public static DateTime End;

        public static bool PeriodForMonth;
        public static bool PeriodForWeek;
        public static bool PeriodForDay;
        public static bool OtherPeriod;

        public static int importString = 0;

        public static int sizeFontButtons;
        public static int sizeFontTables;
        public static int sizeFontCaptions;

        public static string nameMembership;

        public static string styleForm;

        public static string themeMode = "LightMode";
    }
}
