﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace GymApplicationV2._0.Connections
{
    public class IssuedMembershipContext
    {
        public static string ConnectionStringIssued()
        {
            return "Data Source=Databases\\IssuedMembership.db;Version=3";
        }

        public static DataTable GetDataFromDatabase(string commandString)
        {
            DataTable dtContacts = new DataTable();
            using (SQLiteConnection conn = new SQLiteConnection(ConnectionStringIssued()))
            {
                using (SQLiteCommand cmd = new SQLiteCommand(commandString, conn))
                {
                    conn.Open();

                    SQLiteDataReader reader = cmd.ExecuteReader();

                    dtContacts.Load(reader);
                }
            }

            return dtContacts;
        }

        public static void CreatingDatabase()
        {
            SQLiteConnection.CreateFile("Databases\\IssuedMembership.db");

            using (SQLiteConnection conn = new SQLiteConnection(ConnectionStringIssued()))
            {
                string commandString = "CREATE TABLE Issued(Id NVARCHAR(100000), Клиент NVARCHAR(20)," +
                    " №Карты NVARCHAR(20), Дата_окончания NVARCHAR(30), Дата_оформления NVARCHAR(30), Абонемент NVARCHAR(100)," +
                    " Оплата NVARCHAR(20), Статус NVARCHAR(20), Посещений_осталось NVARCHAR(20)," +
                    " Окончание_заморозки NVARCHAR(30))";
                using (SQLiteCommand cmd = new SQLiteCommand(commandString, conn))
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public static object GetElementIssued(string requireLine)
        {
            using (SQLiteConnection conn = new SQLiteConnection(ConnectionStringIssued()))
            {
                string commandString = requireLine;
                using (SQLiteCommand cmd = new SQLiteCommand(commandString, conn))
                {
                    conn.Open();

                    return cmd.ExecuteScalar();
                }
            }
        }

        public static void CommandDataIssued(string command)
        {
            using (SQLiteConnection conn = new SQLiteConnection(ConnectionStringIssued()))
            {
                string commandString = command;

                using (SQLiteCommand cmd = new SQLiteCommand(commandString, conn))
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }
        }
    }
}
