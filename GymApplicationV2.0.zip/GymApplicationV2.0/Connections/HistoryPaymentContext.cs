﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace GymApplicationV2._0
{
    public class HistoryPaymentContext
    {
        public static string ConnectionStringPayment()
        {
            return "Data Source=Databases\\Payments.db;Version=3";
        }

        public static DataTable GetDataFromDatabase(string commandString)
        {
            DataTable dtContacts = new DataTable();
            using (SQLiteConnection conn = new SQLiteConnection(ConnectionStringPayment()))
            {
                using (SQLiteCommand cmd = new SQLiteCommand(commandString, conn))
                {
                    conn.Open();

                    SQLiteDataReader reader = cmd.ExecuteReader();

                    dtContacts.Load(reader);
                }
            }

            return dtContacts;
        }

        public static void CreatingDatabase()
        {
            SQLiteConnection.CreateFile("Databases\\Payments.db");

            using (SQLiteConnection conn = new SQLiteConnection(ConnectionStringPayment()))
            {
                //Нужно написать Сане по поводу того какие данные нужны в истории платежей
                string commandString = "CREATE TABLE History(Id NVARCHAR(100000), ФИО NVARCHAR(50), Абонемент NVARCHAR(50)," +
                    " Дата_начала NVARCHAR(20), Дата_окончания NVARCHAR(20), Цена NVARCHAR(20))";
                using (SQLiteCommand cmd = new SQLiteCommand(commandString, conn))
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public static object GetElementPayment(string requireLine)
        {
            using (SQLiteConnection conn = new SQLiteConnection(ConnectionStringPayment()))
            {
                string commandString = requireLine;
                using (SQLiteCommand cmd = new SQLiteCommand(commandString, conn))
                {
                    conn.Open();

                    return cmd.ExecuteScalar();
                }
            }
        }
    }
}
