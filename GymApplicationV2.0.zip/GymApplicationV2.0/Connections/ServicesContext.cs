﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymApplicationV2._0
{
    public class ServicesContext
    {
        public static string ConnectionStringServices()
        {
            return "Data Source=Databases\\Services.db;Version=3";
        }

        public static DataTable GetDataFromDatabase(string commandString)
        {
            DataTable dtContacts = new DataTable();
            using (SQLiteConnection conn = new SQLiteConnection(ConnectionStringServices()))
            {
                using (SQLiteCommand cmd = new SQLiteCommand(commandString, conn))
                {
                    conn.Open();

                    SQLiteDataReader reader = cmd.ExecuteReader();

                    dtContacts.Load(reader);
                }
            }

            return dtContacts;
        }

        public static void CreatingDatabase()
        {
            SQLiteConnection.CreateFile("Databases\\Services.db");

            using (SQLiteConnection conn = new SQLiteConnection(ConnectionStringServices()))
            {
                string commandString = "CREATE TABLE Descriptions(Id NVARINT(10000), Наименование NVARCHAR(100), Цена NVARCHAR(20), СрокДействия NVARCHAR(20), Количество NVARCHAR(20), ПроданныхЗаМесяц NVARCHAR(20))";
                using (SQLiteCommand cmd = new SQLiteCommand(commandString, conn))
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public static object GetElementService(string requireLine)
        {
            using (SQLiteConnection conn = new SQLiteConnection(ConnectionStringServices()))
            {
                string commandString = requireLine;
                using (SQLiteCommand cmd = new SQLiteCommand(commandString, conn))
                {
                    conn.Open();

                    return cmd.ExecuteScalar();
                }
            }
        }

        public static void CommandDataServices(string command)
        {
            using (SQLiteConnection conn = new SQLiteConnection(ConnectionStringServices()))
            {
                string commandString = command;

                using (SQLiteCommand cmd = new SQLiteCommand(commandString, conn))
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }
        }
    }
}
