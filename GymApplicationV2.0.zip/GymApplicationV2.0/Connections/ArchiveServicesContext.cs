﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace GymApplicationV2._0
{
    public class ArchiveServicesContext
    {
        public static string ConnectionStringArchive()
        {
            return "Data Source=Databases\\Archive.db;Version=3";
        }

        public static DataTable GetDataFromDatabase(string commandString)
        {
            DataTable dtContacts = new DataTable();
            using (SQLiteConnection conn = new SQLiteConnection(ConnectionStringArchive()))
            {
                using (SQLiteCommand cmd = new SQLiteCommand(commandString, conn))
                {
                    conn.Open();

                    SQLiteDataReader reader = cmd.ExecuteReader();

                    dtContacts.Load(reader);
                }
            }

            return dtContacts;
        }

        public static void CreatingDatabase()
        {
            SQLiteConnection.CreateFile("Databases\\Archive.db");

            using (SQLiteConnection conn = new SQLiteConnection(ConnectionStringArchive()))
            {
                string commandString = "CREATE TABLE Archive(Клиент NVARCHAR(40)," +
                    " №Карты NVARCHAR(20)," +
                    " Дата_окончания NVARCHAR(100)," +
                    " Абонемент NVARCHAR(20), Оплата NVARCHAR(20), Посещений_осталось NVARCHAR(20)," +
                    " Пол NVARCHAR(20), Телефон NVARCHAR(20), Email NVARCHAR(100), Дата_рождения NVARCHAR(20), Скидка NVARCHAR(10))";
                using (SQLiteCommand cmd = new SQLiteCommand(commandString, conn))
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public static object GetElementArchive(string requireLine)
        {
            using (SQLiteConnection conn = new SQLiteConnection(ConnectionStringArchive()))
            {
                string commandString = requireLine;
                using (SQLiteCommand cmd = new SQLiteCommand(commandString, conn))
                {
                    conn.Open();

                    return cmd.ExecuteScalar();
                }
            }
        }

        public static void CommandDataArchive(string command)
        {
            using (SQLiteConnection conn = new SQLiteConnection(ConnectionStringArchive()))
            {
                string commandString = command;

                using (SQLiteCommand cmd = new SQLiteCommand(commandString, conn))
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }
        }
    }
}
