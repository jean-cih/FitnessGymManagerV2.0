﻿namespace GymApplicationV2._0
{
    partial class Services
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Services));
            this.dataGridViewServices = new System.Windows.Forms.DataGridView();
            this.labelName = new System.Windows.Forms.Label();
            this.labelNumberCard = new System.Windows.Forms.Label();
            this.checkBoxVisited = new System.Windows.Forms.CheckBox();
            this.jeanTextBoxPurchase = new GymApplicationV2._0.JeanTextBox();
            this.jeanModernButtonAdd = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanModernButton1 = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanModernButtonDelete = new GymApplicationV2._0.Controls.JeanModernButton();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewServices)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewServices
            // 
            this.dataGridViewServices.AllowUserToAddRows = false;
            this.dataGridViewServices.AllowUserToDeleteRows = false;
            this.dataGridViewServices.AllowUserToResizeColumns = false;
            this.dataGridViewServices.AllowUserToResizeRows = false;
            this.dataGridViewServices.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewServices.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewServices.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridViewServices.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewServices.GridColor = System.Drawing.Color.Black;
            this.dataGridViewServices.Location = new System.Drawing.Point(29, 114);
            this.dataGridViewServices.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridViewServices.Name = "dataGridViewServices";
            this.dataGridViewServices.ReadOnly = true;
            this.dataGridViewServices.RowHeadersWidth = 51;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            this.dataGridViewServices.RowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewServices.RowTemplate.Height = 24;
            this.dataGridViewServices.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewServices.Size = new System.Drawing.Size(1123, 432);
            this.dataGridViewServices.TabIndex = 0;
            this.dataGridViewServices.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewServices_CellContentClick);
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelName.Location = new System.Drawing.Point(37, 60);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(0, 20);
            this.labelName.TabIndex = 20;
            this.labelName.Visible = false;
            // 
            // labelNumberCard
            // 
            this.labelNumberCard.AutoSize = true;
            this.labelNumberCard.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelNumberCard.Location = new System.Drawing.Point(72, 87);
            this.labelNumberCard.Name = "labelNumberCard";
            this.labelNumberCard.Size = new System.Drawing.Size(0, 20);
            this.labelNumberCard.TabIndex = 22;
            this.labelNumberCard.Visible = false;
            // 
            // checkBoxVisited
            // 
            this.checkBoxVisited.AutoSize = true;
            this.checkBoxVisited.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBoxVisited.Location = new System.Drawing.Point(859, 591);
            this.checkBoxVisited.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkBoxVisited.Name = "checkBoxVisited";
            this.checkBoxVisited.Size = new System.Drawing.Size(209, 20);
            this.checkBoxVisited.TabIndex = 37;
            this.checkBoxVisited.Text = "Отметить посещение сразу";
            this.checkBoxVisited.UseVisualStyleBackColor = true;
            this.checkBoxVisited.Visible = false;
            // 
            // jeanTextBoxPurchase
            // 
            this.jeanTextBoxPurchase.BackColor = System.Drawing.Color.White;
            this.jeanTextBoxPurchase.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBoxPurchase.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBoxPurchase.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBoxPurchase.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBoxPurchase.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBoxPurchase.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBoxPurchase.Location = new System.Drawing.Point(460, 68);
            this.jeanTextBoxPurchase.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.jeanTextBoxPurchase.Name = "jeanTextBoxPurchase";
            this.jeanTextBoxPurchase.SelectionStart = 0;
            this.jeanTextBoxPurchase.Size = new System.Drawing.Size(255, 39);
            this.jeanTextBoxPurchase.TabIndex = 44;
            this.jeanTextBoxPurchase.TextInput = "";
            this.jeanTextBoxPurchase.TextPreview = "Услуга";
            this.jeanTextBoxPurchase.UseSystemPasswordChar = false;
            // 
            // jeanModernButtonAdd
            // 
            this.jeanModernButtonAdd.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonAdd.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonAdd.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButtonAdd.BorderRadius = 20;
            this.jeanModernButtonAdd.BorderSize = 2;
            this.jeanModernButtonAdd.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonAdd.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonAdd.Location = new System.Drawing.Point(436, 572);
            this.jeanModernButtonAdd.Name = "jeanModernButtonAdd";
            this.jeanModernButtonAdd.Size = new System.Drawing.Size(150, 55);
            this.jeanModernButtonAdd.TabIndex = 50;
            this.jeanModernButtonAdd.Text = "Добавить";
            this.jeanModernButtonAdd.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonAdd.UseVisualStyleBackColor = false;
            this.jeanModernButtonAdd.Click += new System.EventHandler(this.buttonAddService_Click);
            // 
            // jeanModernButton1
            // 
            this.jeanModernButton1.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButton1.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButton1.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButton1.BorderRadius = 20;
            this.jeanModernButton1.BorderSize = 2;
            this.jeanModernButton1.FlatAppearance.BorderSize = 0;
            this.jeanModernButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButton1.ForeColor = System.Drawing.Color.White;
            this.jeanModernButton1.Location = new System.Drawing.Point(516, 572);
            this.jeanModernButton1.Name = "jeanModernButton1";
            this.jeanModernButton1.Size = new System.Drawing.Size(150, 55);
            this.jeanModernButton1.TabIndex = 51;
            this.jeanModernButton1.Text = "Продать";
            this.jeanModernButton1.TextColor = System.Drawing.Color.White;
            this.jeanModernButton1.UseVisualStyleBackColor = false;
            this.jeanModernButton1.Visible = false;
            this.jeanModernButton1.Click += new System.EventHandler(this.buttonSell_Click);
            // 
            // jeanModernButtonDelete
            // 
            this.jeanModernButtonDelete.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonDelete.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonDelete.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButtonDelete.BorderRadius = 20;
            this.jeanModernButtonDelete.BorderSize = 2;
            this.jeanModernButtonDelete.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonDelete.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonDelete.Location = new System.Drawing.Point(592, 572);
            this.jeanModernButtonDelete.Name = "jeanModernButtonDelete";
            this.jeanModernButtonDelete.Size = new System.Drawing.Size(150, 55);
            this.jeanModernButtonDelete.TabIndex = 52;
            this.jeanModernButtonDelete.Text = "Удалить";
            this.jeanModernButtonDelete.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonDelete.UseVisualStyleBackColor = false;
            this.jeanModernButtonDelete.Click += new System.EventHandler(this.buttonDelete_Click);
            // 
            // Services
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1181, 654);
            this.Controls.Add(this.jeanModernButton1);
            this.Controls.Add(this.jeanModernButtonAdd);
            this.Controls.Add(this.jeanTextBoxPurchase);
            this.Controls.Add(this.checkBoxVisited);
            this.Controls.Add(this.labelNumberCard);
            this.Controls.Add(this.labelName);
            this.Controls.Add(this.dataGridViewServices);
            this.Controls.Add(this.jeanModernButtonDelete);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Services";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Услуги";
            this.Load += new System.EventHandler(this.Services_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewServices)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        protected internal System.Windows.Forms.DataGridView dataGridViewServices;
        protected internal System.Windows.Forms.Label labelName;
        protected internal System.Windows.Forms.Label labelNumberCard;
        protected internal System.Windows.Forms.CheckBox checkBoxVisited;
        protected internal JeanTextBox jeanTextBoxPurchase;
        protected internal Controls.JeanModernButton jeanModernButtonAdd;
        protected internal Controls.JeanModernButton jeanModernButton1;
        protected internal Controls.JeanModernButton jeanModernButtonDelete;
    }
}