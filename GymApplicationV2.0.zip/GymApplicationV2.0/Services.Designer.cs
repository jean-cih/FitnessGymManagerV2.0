﻿namespace GymApplicationV2._0
{
    partial class Services
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataGridViewServices = new System.Windows.Forms.DataGridView();
            this.buttonAddService = new System.Windows.Forms.Button();
            this.buttonDeleteService = new System.Windows.Forms.Button();
            this.buttonSell = new System.Windows.Forms.Button();
            this.labelName = new System.Windows.Forms.Label();
            this.textMembershipId = new System.Windows.Forms.TextBox();
            this.labelNumberCard = new System.Windows.Forms.Label();
            this.labelDeleteId = new System.Windows.Forms.Label();
            this.labelMarkVisitNow = new System.Windows.Forms.Label();
            this.markVisitNo = new System.Windows.Forms.RadioButton();
            this.markVisitYes = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewServices)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewServices
            // 
            this.dataGridViewServices.AllowUserToAddRows = false;
            this.dataGridViewServices.AllowUserToDeleteRows = false;
            this.dataGridViewServices.AllowUserToResizeColumns = false;
            this.dataGridViewServices.AllowUserToResizeRows = false;
            this.dataGridViewServices.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewServices.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewServices.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridViewServices.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewServices.GridColor = System.Drawing.Color.Black;
            this.dataGridViewServices.Location = new System.Drawing.Point(29, 115);
            this.dataGridViewServices.Name = "dataGridViewServices";
            this.dataGridViewServices.RowHeadersWidth = 51;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            this.dataGridViewServices.RowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewServices.RowTemplate.Height = 24;
            this.dataGridViewServices.Size = new System.Drawing.Size(1122, 432);
            this.dataGridViewServices.TabIndex = 0;
            // 
            // buttonAddService
            // 
            this.buttonAddService.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddService.Location = new System.Drawing.Point(430, 573);
            this.buttonAddService.Name = "buttonAddService";
            this.buttonAddService.Size = new System.Drawing.Size(150, 55);
            this.buttonAddService.TabIndex = 17;
            this.buttonAddService.Text = "Добавить";
            this.buttonAddService.UseVisualStyleBackColor = true;
            this.buttonAddService.Click += new System.EventHandler(this.buttonAddService_Click);
            // 
            // buttonDeleteService
            // 
            this.buttonDeleteService.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDeleteService.Location = new System.Drawing.Point(595, 573);
            this.buttonDeleteService.Name = "buttonDeleteService";
            this.buttonDeleteService.Size = new System.Drawing.Size(150, 55);
            this.buttonDeleteService.TabIndex = 18;
            this.buttonDeleteService.Text = "Удалить";
            this.buttonDeleteService.UseVisualStyleBackColor = true;
            this.buttonDeleteService.Click += new System.EventHandler(this.buttonDelete_Click);
            // 
            // buttonSell
            // 
            this.buttonSell.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSell.Location = new System.Drawing.Point(513, 573);
            this.buttonSell.Name = "buttonSell";
            this.buttonSell.Size = new System.Drawing.Size(150, 55);
            this.buttonSell.TabIndex = 19;
            this.buttonSell.Text = "Продать";
            this.buttonSell.UseVisualStyleBackColor = true;
            this.buttonSell.Visible = false;
            this.buttonSell.Click += new System.EventHandler(this.buttonSell_Click);
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelName.Location = new System.Drawing.Point(332, 60);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(197, 20);
            this.labelName.TabIndex = 20;
            this.labelName.Text = "Почекутов Евгений: Id";
            this.labelName.Visible = false;
            // 
            // textMembershipId
            // 
            this.textMembershipId.Location = new System.Drawing.Point(571, 72);
            this.textMembershipId.Name = "textMembershipId";
            this.textMembershipId.Size = new System.Drawing.Size(158, 22);
            this.textMembershipId.TabIndex = 21;
            // 
            // labelNumberCard
            // 
            this.labelNumberCard.AutoSize = true;
            this.labelNumberCard.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelNumberCard.Location = new System.Drawing.Point(366, 87);
            this.labelNumberCard.Name = "labelNumberCard";
            this.labelNumberCard.Size = new System.Drawing.Size(126, 20);
            this.labelNumberCard.TabIndex = 22;
            this.labelNumberCard.Text = "2000000023451";
            this.labelNumberCard.Visible = false;
            // 
            // labelDeleteId
            // 
            this.labelDeleteId.AutoSize = true;
            this.labelDeleteId.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelDeleteId.Location = new System.Drawing.Point(581, 49);
            this.labelDeleteId.Name = "labelDeleteId";
            this.labelDeleteId.Size = new System.Drawing.Size(135, 20);
            this.labelDeleteId.TabIndex = 23;
            this.labelDeleteId.Text = "Удаление по Id";
            // 
            // labelMarkVisitNow
            // 
            this.labelMarkVisitNow.AutoSize = true;
            this.labelMarkVisitNow.Location = new System.Drawing.Point(134, 573);
            this.labelMarkVisitNow.Name = "labelMarkVisitNow";
            this.labelMarkVisitNow.Size = new System.Drawing.Size(187, 16);
            this.labelMarkVisitNow.TabIndex = 26;
            this.labelMarkVisitNow.Text = "Отметить посещение сразу";
            this.labelMarkVisitNow.Visible = false;
            // 
            // markVisitNo
            // 
            this.markVisitNo.AutoSize = true;
            this.markVisitNo.Checked = true;
            this.markVisitNo.Location = new System.Drawing.Point(233, 594);
            this.markVisitNo.Name = "markVisitNo";
            this.markVisitNo.Size = new System.Drawing.Size(53, 20);
            this.markVisitNo.TabIndex = 25;
            this.markVisitNo.TabStop = true;
            this.markVisitNo.Text = "Нет";
            this.markVisitNo.UseVisualStyleBackColor = true;
            this.markVisitNo.Visible = false;
            // 
            // markVisitYes
            // 
            this.markVisitYes.AutoSize = true;
            this.markVisitYes.Location = new System.Drawing.Point(171, 594);
            this.markVisitYes.Name = "markVisitYes";
            this.markVisitYes.Size = new System.Drawing.Size(45, 20);
            this.markVisitYes.TabIndex = 24;
            this.markVisitYes.Text = "Да";
            this.markVisitYes.UseVisualStyleBackColor = true;
            this.markVisitYes.Visible = false;
            // 
            // Services
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1182, 653);
            this.Controls.Add(this.labelMarkVisitNow);
            this.Controls.Add(this.markVisitNo);
            this.Controls.Add(this.markVisitYes);
            this.Controls.Add(this.labelDeleteId);
            this.Controls.Add(this.labelNumberCard);
            this.Controls.Add(this.textMembershipId);
            this.Controls.Add(this.labelName);
            this.Controls.Add(this.buttonSell);
            this.Controls.Add(this.buttonDeleteService);
            this.Controls.Add(this.buttonAddService);
            this.Controls.Add(this.dataGridViewServices);
            this.Name = "Services";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Услуги";
            this.Load += new System.EventHandler(this.Services_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewServices)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        protected internal System.Windows.Forms.Button buttonAddService;
        protected internal System.Windows.Forms.DataGridView dataGridViewServices;
        protected internal System.Windows.Forms.Button buttonDeleteService;
        protected internal System.Windows.Forms.Button buttonSell;
        protected internal System.Windows.Forms.Label labelName;
        protected internal System.Windows.Forms.TextBox textMembershipId;
        protected internal System.Windows.Forms.Label labelNumberCard;
        protected internal System.Windows.Forms.Label labelDeleteId;
        protected internal System.Windows.Forms.Label labelMarkVisitNow;
        protected internal System.Windows.Forms.RadioButton markVisitNo;
        protected internal System.Windows.Forms.RadioButton markVisitYes;
    }
}