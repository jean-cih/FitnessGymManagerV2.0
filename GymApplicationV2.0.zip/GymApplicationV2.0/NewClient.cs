﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Entity;
using System.Data.SQLite;
using System.IO;
using System.Drawing.Text;
using System.Text.RegularExpressions;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Globalization;

namespace GymApplicationV2._0
{
    public partial class NewClient : Form
    {
        public NewClient()
        {
            InitializeComponent();
        }

        private void NewClient_Load(object sender, EventArgs e)
        {
            CheckIfDataExists();
            CheckIfDataServicesExists();
        }

        private void CheckIfDataExists()
        {
            if (!File.Exists("Databases\\Clients.db"))
            {
                ClientsContext.CreatingDatabase();
            }
        }

        private void CheckIfDataServicesExists()
        {
            if (!File.Exists("Databases\\Services.db"))
            {
                ServicesContext.CreatingDatabase();
            }
            else
            {
                dataGridViewServices.DataSource = ServicesContext.GetDataFromDatabase("SELECT Наименование, Цена, СрокДействия, Количество FROM Descriptions");
            }
        }

        string lefts = "", price = "", termMembership = "";
        private void dataGridViewServices_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            textPurchase.Text = dataGridViewServices.SelectedRows[0].Cells[0].Value.ToString();
            lefts = dataGridViewServices.SelectedRows[0].Cells[3].Value.ToString();
            price = dataGridViewServices.SelectedRows[0].Cells[1].Value.ToString();
            termMembership = dataGridViewServices.SelectedRows[0].Cells[2].Value.ToString();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            if (textSurname.Text == "" || textName.Text == "" || (textNumberCard.Text != "" && textPurchase.Text == ""))
            {
                Message.MessageWindowOk("Незаполненные поля");

                return;
            }

            if (textSurname.Text.Length > 20 || textName.Text.Length > 20 || textNumberCard.Text.Length > 20)
            {
                Message.MessageWindowOk("Превышен лимит количества символов");

                return;
            }

            Regex regex = new Regex(@"^\d{11}$");
            if (!regex.IsMatch(textNumber.Text))
            {
                Message.MessageWindowOk("Не правильный формат номера");
 
                return;
            }
            
            //Получение максимального id клиента
            object maxId = ClientsContext.GetElementClient("SELECT MAX(Id) FROM Contacts");

            int number;

            if (maxId.ToString() != "")
                number = Convert.ToInt32(maxId) + 1;
            else
                number = 1;

            //пол не заносится в таблицу
            string gender;
            if (radioButtonMan.Checked)
            {
                gender = "Мужской";
            }
            else if (radioButtonWoman.Checked)
            {
                gender = "Женский";
            }
            else
            {
                gender = "";
            }

            //Добавляем нового клиента
            using (SQLiteConnection conn = new SQLiteConnection(ClientsContext.ConnectionStringClients()))
            {
                string commandStringNew = "INSERT INTO Contacts (" +
                    "[Id],[Фамилия],[Имя],[Пол],[Телефон],[№Карты],[Покупки],[Посетил],[Абонемент],[Срок_абонемента],[Посещений_осталось],[Отчество],[Email],[Дата_рождения],[Скидка],[Сохранено])" +
                    " VALUES (@Id,@Фамилия,@Имя,@Пол,@Телефон,@№Карты,@Покупки,@Посетил,@Абонемент,@Срок_абонемента,@Посещений_осталось,@Отчество,@Email,@Дата_рождения,@Скидка,@Сохранено)";
                using (SQLiteCommand cmd = new SQLiteCommand(commandStringNew, conn))
                {
                    int markRightNow = 0;

                    conn.Open();

                    cmd.Parameters.AddWithValue("@Id", number.ToString());
                    cmd.Parameters.AddWithValue("@Фамилия", textSurname.Text);
                    cmd.Parameters.AddWithValue("@Имя", textName.Text);
                    cmd.Parameters.AddWithValue("@Пол", gender);
                    cmd.Parameters.AddWithValue("@Телефон", textNumber.Text);
                    cmd.Parameters.AddWithValue("@№Карты", textNumberCard.Text);
                    if (decimal.TryParse(textDiscount.Text, NumberStyles.Number, CultureInfo.InvariantCulture, out decimal discount) && price != "")
                    {
                        cmd.Parameters.AddWithValue("@Покупки", Convert.ToInt32(Convert.ToDecimal(price) * (1 - discount / 100)).ToString());
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("@Покупки", price);
                    }
                    if (checkBoxVisited.Checked)
                    {
                        markRightNow = 1;
                        cmd.Parameters.AddWithValue("@Посетил", DateTime.Now.ToString());
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("@Посетил", "");
                    }
                    cmd.Parameters.AddWithValue("@Абонемент", textPurchase.Text);
                    //Прибавить срок абонемента
                    if (textPurchase.Text != "")
                    {
                        DateTime now = DateTime.Now;
                        cmd.Parameters.AddWithValue("@Срок_абонемента", new DateTime(now.Year, now.Month + Convert.ToInt32(termMembership), now.Day));
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("@Срок абонемента", "");
                    }
                    string leftVisit = "";
                    if (lefts != "")
                    {
                        leftVisit = (Convert.ToInt32(lefts) - markRightNow).ToString();
                    }
                    cmd.Parameters.AddWithValue("@Посещений_осталось", leftVisit);
                     
                    cmd.Parameters.AddWithValue("@Отчество", textFather.Text);
                    cmd.Parameters.AddWithValue("@Email", "");
                    cmd.Parameters.AddWithValue("@Дата_рождения", textBirthday.Text);
                    cmd.Parameters.AddWithValue("@Скидка", textDiscount.Text);
                    cmd.Parameters.AddWithValue("@Сохранено", DateTime.Now.ToString());

                    cmd.ExecuteNonQuery();
                }

            }
            object quantity = ServicesContext.GetElementService("SELECT ПроданныхЗаМесяц FROM Descriptions WHERE Наименование = '" + textPurchase.Text + "';"); ;
            if (textPurchase.Text != "")
            {
                ServicesContext.CommandDataServices("UPDATE Descriptions SET " +
                    "ПроданныхЗаМесяц = '" + (Convert.ToInt32(quantity) + 1).ToString() + "' " +
                    "WHERE Наименование = '" + textPurchase.Text + "';");
            }

            textSurname.Text = "";
            textName.Text = "";
            textNumber.Text = "";
            textNumberCard.Text = "";
            textPurchase.Text = "";

            Message.MessageWindowOk("Клиент добавлен");
        }

        private void buttonClients_Click(object sender, EventArgs e)
        {
            Clients clients = new Clients();
            clients.Show();
        }

        private void buttonChoose_Click(object sender, EventArgs e)
        {
            Services services = new Services();
            services.Show();
            services.buttonAddService.Visible = false;
            services.buttonDeleteService.Visible = false;
        }
    }
}
