﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Entity;
using System.Data.SQLite;
using System.IO;
using System.Drawing.Text;
using System.Text.RegularExpressions;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace GymApplicationV2._0
{
    public partial class NewClient : Form
    {
        public NewClient()
        {
            InitializeComponent();
        }

        private void NewClient_Load(object sender, EventArgs e)
        {
            CheckIfDataExists();
            CheckIfDataServicesExists();
        }

        private void CheckIfDataExists()
        {
            if (!File.Exists("Databases\\Clients.db"))
            {
                ClientsContext.CreatingDatabase();
            }
        }

        private void CheckIfDataServicesExists()
        {
            if (!File.Exists("Databases\\Services.db"))
            {
                ServicesContext.CreatingDatabase();
            }
            else
            {
                dataGridViewServices.DataSource = ServicesContext.GetDataFromDatabase("SELECT * FROM Descriptions");
            }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            
            if(textSurname.Text == "" || textName.Text == "" || (textNumberCard.Text != "" && textPurchaseId.Text == ""))
            {
                Message.MessageWindowOk("Незаполненные поля");

                return;
            }

            if (textSurname.Text.Length > 20 || textName.Text.Length > 20 || textNumberCard.Text.Length > 20)
            {
                Message.MessageWindowOk("Превышен лимит количества символов");

                return;
            }

            Regex regex = new Regex(@"^\d{11}$");
            if (!regex.IsMatch(textNumber.Text))
            {
                Message.MessageWindowOk("Не правильный формат номера");
 
                return;
            }
            
            //Получение максимального id клиента
            object maxId = ClientsContext.GetElementClient("SELECT MAX(Id) FROM Contacts");

            int number;

            if (maxId.ToString() != "")
                number = Convert.ToInt32(maxId) + 1;
            else
                number = 1;

            object naming, lefts;
            if (textPurchaseId.Text != "")
            {
                naming = ServicesContext.GetElementService("SELECT Наименование FROM Descriptions WHERE Id = '" + textPurchaseId.Text + "';");
                lefts = ServicesContext.GetElementService("SELECT Количество FROM Descriptions WHERE Id = '" + textPurchaseId.Text + "';");
            }
            else
            {
                naming = "";
                lefts = "";
            }
                
            //Добавляем нового клиента
            using (SQLiteConnection conn = new SQLiteConnection(ClientsContext.ConnectionStringClients()))
            {
                string commandStringNew = "INSERT INTO Contacts ([Id],[Фамилия],[Имя],[Пол],[Телефон],[№Карты],[Покупка],[Посетил],[Абонемент],[Осталось]) VALUES (@Id,@Фамилия,@Имя,@Пол,@Телефон,@№Карты,@Покупка,@Посетил,@Абонемент,@Осталось)";
                using (SQLiteCommand cmd = new SQLiteCommand(commandStringNew, conn))
                {
                    int markRightNow = 0;

                    conn.Open();

                    cmd.Parameters.AddWithValue("@Id", number.ToString());
                    cmd.Parameters.AddWithValue("@Фамилия", textSurname.Text);
                    cmd.Parameters.AddWithValue("@Имя", textName.Text);
                    cmd.Parameters.AddWithValue("@Пол", comboGender.Text);
                    cmd.Parameters.AddWithValue("@Телефон", textNumber.Text);
                    cmd.Parameters.AddWithValue("@№Карты", textNumberCard.Text);
                    cmd.Parameters.AddWithValue("@Покупка", dateTimePickerClient.Value.ToString());

                    if (markVisitYes.Checked)
                    {
                        markRightNow = 1;
                        cmd.Parameters.AddWithValue("@Посетил", DateTime.Now.ToString());
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("@Посетил", "");
                    }
                    cmd.Parameters.AddWithValue("@Абонемент", naming.ToString());

                    string leftVisit = "";
                    if (lefts.ToString() != "")
                        leftVisit = (Convert.ToInt32(lefts) - markRightNow).ToString();

                    cmd.Parameters.AddWithValue("@Осталось", leftVisit);

                    cmd.ExecuteNonQuery();
                }

            }
            object quantity = ServicesContext.GetElementService("SELECT ПроданныхЗаМесяц FROM Descriptions WHERE Id = '" + textPurchaseId.Text + "';"); ;
            if (naming.ToString() != "")
            {
                ServicesContext.CommandDataServices("UPDATE Descriptions SET " +
                    "ПроданныхЗаМесяц = '" + (Convert.ToInt32(quantity) + 1).ToString() + "' " +
                    "WHERE Id = '" + textPurchaseId.Text + "';");
            }

            textSurname.Text = "";
            textName.Text = "";
            textNumber.Text = "";
            textNumberCard.Text = "";
            textPurchaseId.Text = "";

            Message.MessageWindowOk("Клиент добавлен");
        }

        private void buttonClients_Click(object sender, EventArgs e)
        {
            Clients clients = new Clients();
            clients.Show();
        }

        private void buttonChoose_Click(object sender, EventArgs e)
        {
            Services services = new Services();
            services.Show();
            services.buttonAddService.Visible = false;
            services.buttonDeleteService.Visible = false;
        }
    }
}
