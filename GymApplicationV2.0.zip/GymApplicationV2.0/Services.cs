﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace GymApplicationV2._0
{
    public partial class Services : Form
    {
        public Services()
        {
            InitializeComponent();
        }

        private void Services_Load(object sender, EventArgs e)
        {
            CheckIfDataExists();
        }

        private void CheckIfDataExists()
        {
            if (!File.Exists("Databases\\Services.db"))
            {
                ServicesContext.CreatingDatabase();
            }
            else
            {
                dataGridViewServices.DataSource = ServicesContext.GetDataFromDatabase("SELECT Наименование, Цена, СрокДействия, Количество FROM Descriptions");
            }
        }

        private void dataGridViewServices_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            textMembership.Text = dataGridViewServices.SelectedRows[0].Cells[0].Value.ToString();
        }

        private void buttonAddService_Click(object sender, EventArgs e)
        {
            FieldForService service = new FieldForService();
            service.Show();
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (textMembership.Text == "")
                return;

            DialogResult result = Message.MessageWindowYesNo("Вы действительно хотите удалить услугу?");

            if (result == DialogResult.No)
                return;

            ServicesContext.CommandDataServices("DELETE FROM Descriptions Where Наименование = '" + textMembership.Text + "' ");

            Message.MessageWindowOk("Услуга удалена");

            dataGridViewServices.DataSource = ServicesContext.GetDataFromDatabase("SELECT Наименование, Цена, СрокДействия, Количество FROM Descriptions");
        }

        private void buttonSell_Click(object sender, EventArgs e)
        {
            if (textMembership.Text == "")
            {
                Message.MessageWindowOk("Нужно сначала выбрать услугу");
                return;
            }
   
            object left = ServicesContext.GetElementService("SELECT Количество FROM Descriptions WHERE Наименование = '" + textMembership.Text + "';");

            int? number = null;
            if(left.ToString() != "")
                number = Convert.ToInt32(left);

            if (checkBoxVisited.Checked && number != null)
                number -= 1;

            object purchase = ServicesContext.GetElementService("SELECT Покупки FROM Contacts WHERE №Карты = '" + labelNumberCard.Text + "';");

            int costs = 0;
            if (purchase != null)
                costs = Convert.ToInt32(purchase);


            ClientsContext.CommandDataClient("UPDATE Contacts SET " +
                    "Покупки = '" + costs + DataClass.dateSellForm.ToString() + "'," +
                    "Абонемент = '" + textMembership.Text + "'," +
                    "Посещений_осталось = '" + number.ToString() + "' " +
                    "WHERE №Карты = '" + labelNumberCard.Text + "';");

            object quantity = ServicesContext.GetElementService("SELECT ПроданныхЗаМесяц FROM Descriptions WHERE Наименование = '" + textMembership.Text + "';"); ;
            if (textMembership.Text != "")
            {
                ServicesContext.CommandDataServices("UPDATE Descriptions SET " +
                    "ПроданныхЗаМесяц = '" + (Convert.ToInt32(quantity) + 1).ToString() + "' " +
                    "WHERE Id = '" + textMembership.Text + "';");
            }

            Message.MessageWindowOk("Данные клиента обновлены");
        }
    }
}
