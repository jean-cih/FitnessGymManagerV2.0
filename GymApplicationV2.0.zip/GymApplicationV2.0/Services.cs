﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace GymApplicationV2._0
{
    public partial class Services : Form
    {
        public Services()
        {
            InitializeComponent();
        }

        private void Services_Load(object sender, EventArgs e)
        {
            CheckIfDataExists();
        }

        private void CheckIfDataExists()
        {
            if (!File.Exists("Databases\\Services.db"))
            {
                ServicesContext.CreatingDatabase();
            }
            else
            {
                LoadDataGridViewServices();
            }
        }

        private void LoadDataGridViewServices()
        {
            dataGridViewServices.DataSource = ServicesContext.GetDataFromDatabase("SELECT * FROM Descriptions");
        }

        private void buttonAddService_Click(object sender, EventArgs e)
        {
            FieldForService service = new FieldForService();
            service.Show();
            this.Close();
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (textMembershipId.Text == "")
                return;

            DialogResult result = Message.MessageWindowYesNo("Вы действительно хотите удалить услугу?");

            if (result == DialogResult.No)
                return;

            using (SQLiteConnection conn = new SQLiteConnection(ServicesContext.ConnectionStringServices()))
            {
                string commandString = "DELETE FROM Descriptions Where Id = '" + textMembershipId.Text + "' ";

                using (SQLiteCommand cmd = new SQLiteCommand(commandString, conn))
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();

                    Message.MessageWindowOk("Услуга удалена");
                }
            }

            LoadDataGridViewServices();
        }

        private void buttonSell_Click(object sender, EventArgs e)
        {
            if (textMembershipId.Text == "")
                return;

            object naming = ServicesContext.GetElementService("SELECT Наименование FROM Descriptions WHERE Id = '" + textMembershipId.Text + "';");
   
            object left = ServicesContext.GetElementService("SELECT Количество FROM Descriptions WHERE Id = '" + textMembershipId.Text + "';");

            int? number = null;
            if(left.ToString() != "")
                number = Convert.ToInt32(left);

            if (markVisitYes.Checked && number != null)
                number -= 1;


            using (SQLiteConnection conn = new SQLiteConnection(ClientsContext.ConnectionStringClients()))
            {
                string commandString = "UPDATE Contacts SET " +
                    "Абонемент = '" + naming.ToString() + "'," +
                    "Осталось = '" + number.ToString() + "' " +
                    "WHERE №Карты = '" + labelNumberCard.Text + "';";

                using (SQLiteCommand cmd = new SQLiteCommand(commandString, conn))
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();

                    Message.MessageWindowOk("Данные клиента обновлены");
                }
            }
            
        }
    }
}
