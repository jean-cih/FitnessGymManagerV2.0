﻿namespace GymApplicationV2._0
{
    partial class InformationReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InformationReport));
            this.dataGridViewShowReport = new System.Windows.Forms.DataGridView();
            this.labelAllClients = new System.Windows.Forms.Label();
            this.labelQuantity = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewShowReport)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewShowReport
            // 
            this.dataGridViewShowReport.AllowUserToAddRows = false;
            this.dataGridViewShowReport.AllowUserToDeleteRows = false;
            this.dataGridViewShowReport.AllowUserToResizeColumns = false;
            this.dataGridViewShowReport.AllowUserToResizeRows = false;
            this.dataGridViewShowReport.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewShowReport.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewShowReport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewShowReport.Location = new System.Drawing.Point(5, 3);
            this.dataGridViewShowReport.Name = "dataGridViewShowReport";
            this.dataGridViewShowReport.RowHeadersWidth = 51;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            this.dataGridViewShowReport.RowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewShowReport.RowTemplate.Height = 24;
            this.dataGridViewShowReport.Size = new System.Drawing.Size(1115, 606);
            this.dataGridViewShowReport.TabIndex = 0;
            this.dataGridViewShowReport.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewAttendance_CellContentClick);
            // 
            // labelAllClients
            // 
            this.labelAllClients.AutoSize = true;
            this.labelAllClients.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelAllClients.Location = new System.Drawing.Point(12, 628);
            this.labelAllClients.Name = "labelAllClients";
            this.labelAllClients.Size = new System.Drawing.Size(152, 20);
            this.labelAllClients.TabIndex = 16;
            this.labelAllClients.Text = "Всего клиентов: ";
            // 
            // labelQuantity
            // 
            this.labelQuantity.AutoSize = true;
            this.labelQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelQuantity.Location = new System.Drawing.Point(165, 629);
            this.labelQuantity.Name = "labelQuantity";
            this.labelQuantity.Size = new System.Drawing.Size(18, 20);
            this.labelQuantity.TabIndex = 17;
            this.labelQuantity.Text = "0";
            // 
            // InformationReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1123, 666);
            this.Controls.Add(this.labelQuantity);
            this.Controls.Add(this.labelAllClients);
            this.Controls.Add(this.dataGridViewShowReport);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "InformationReport";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Посещаемость";
            this.Load += new System.EventHandler(this.Attendance_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewShowReport)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewShowReport;
        private System.Windows.Forms.Label labelAllClients;
        private System.Windows.Forms.Label labelQuantity;
    }
}