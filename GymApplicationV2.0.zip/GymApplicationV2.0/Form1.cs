﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace GymApplicationV2._0
{
    public partial class Form1 : Form
    {
        string nameClient = "Почекутов";
        string surnameClient = "Евгений";
        string numberCard;
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonSettings_Click(object sender, EventArgs e)
        {
            Settings settings = new Settings();
            settings.Show();
        }

        private void buttonServices_Click(object sender, EventArgs e)
        {
            Services services = new Services();
            services.Show();
        }

        private void buttonProducts_Click(object sender, EventArgs e)
        {
            Products products = new Products();
            products.Show();
        }

        private void buttonClients_Click(object sender, EventArgs e)
        {
            Clients clients = new Clients();
            clients.Show();
        }

        private void buttonReport_Click(object sender, EventArgs e)
        {
            Report report = new Report();
            report.Show();
        }
        private void buttonNewMembership_Click(object sender, EventArgs e)
        {
            NewClient newClient = new NewClient();
            newClient.Show();
        }

        private void textNumberClient_TextChanged(object sender, EventArgs e)
        {
            if (textNumberClient.Text.Length != 13)
                return;
         
            numberCard = textNumberClient.Text;

            //Проверка на время
            object timeLeft = ClientsContext.GetElementClient("SELECT Покупка FROM Contacts WHERE №Карты = '" + textNumberClient.Text + "';");

                        //Нужно будет 2 менять на количество месяцев из dataGridViewServices
                        //Нужно добавить в таблицу clients idшник services для того чтобы мы могли доставить срок
                        //или просто добавить срок в таблицу clients
            if (Convert.ToInt32(DateTime.Now.Subtract(Convert.ToDateTime(timeLeft)).Days) > 2 * 31)
            {
                Message.MessageWindowOk("Абонемент закончился по времени");

                dataGridViewClient.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts WHERE №Карты = '" + textNumberClient.Text + "';");
                return;
            }

            //Находим количество оставшихся посещений
            object left = ClientsContext.GetElementClient("SELECT Осталось FROM Contacts WHERE №Карты = '" + textNumberClient.Text + "';");
    
            //Обработка краевых случаев
            if (left == null)
            {
                Message.MessageWindowOk("Такого клиента не существует");
                textNumberClient.Text = "";
                return;
            }
            
            //Безлимитный
            if (left.ToString() == "")
            {
                ClientsContext.CommandDataClient("UPDATE Contacts SET " +
                        "Посетил = '" + DateTime.Now + "' " +
                        "WHERE №Карты = '" + textNumberClient.Text + "';");

                Message.MessageWindowOk("Клиент отмечен");

                dataGridViewClient.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts WHERE №Карты = '" + textNumberClient.Text + "';");
                textNumberClient.Text = "";
                return;
            }

            int numberLeft = Convert.ToInt32(left);

            if(numberLeft <= 0)
            {
                Message.MessageWindowOk("Абонемент закончился. Посещений осталось 0");

                dataGridViewClient.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts WHERE №Карты = '" + textNumberClient.Text + "';");
                textNumberClient.Text = "";
                return;
            }

            //Вытаскиваем из таблицы имя и фамилию для кнопки
            object surname, name;
            surname = ClientsContext.GetElementClient("SELECT Имя FROM Contacts WHERE №Карты = '" + textNumberClient.Text + "';");
            name = ClientsContext.GetElementClient("SELECT Фамилия FROM Contacts WHERE №Карты = '" + textNumberClient.Text + "';");

            nameClient = name.ToString();
            surnameClient = surname.ToString();
            buttonSellClient.Text = "Продать\n" + nameClient + " " + surnameClient;

            //Отнимаем 1 от оставшихся посещений
            ClientsContext.CommandDataClient("UPDATE Contacts SET " +
                    "Осталось = '" + (numberLeft - 1).ToString() + "' " +
                    "WHERE №Карты = '" + textNumberClient.Text + "';");

            ClientsContext.CommandDataClient("UPDATE Contacts SET " +
                    "Посетил = '" + DateTime.Now + "' " +
                    "WHERE №Карты = '" + textNumberClient.Text + "';");


            Message.MessageWindowOk("Клиент отмечен");

            dataGridViewClient.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts WHERE №Карты = '" + textNumberClient.Text + "';");

            textNumberClient.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void buttonSellClient_Click(object sender, EventArgs e)
        {
            Services services = new Services();
            services.Show();
            services.buttonSell.Visible = true;
            services.buttonAddService.Visible = false;
            services.buttonDeleteService.Visible = false;
            services.labelName.Visible = true;
            services.textMembershipId.Visible = true;
            services.labelName.Text = nameClient + " " + surnameClient + ": Id";
            services.labelNumberCard.Visible = true;
            services.labelNumberCard.Text = numberCard;
            services.labelDeleteId.Visible = false;
            services.labelMarkVisitNow.Visible = true;
            services.markVisitYes.Visible = true;
            services.markVisitNo.Visible = true;
        }

        private void buttonSingleVisiting_Click(object sender, EventArgs e)
        {
            SingleTicket singleTicket = new SingleTicket();
            singleTicket.Show();
        }
    }
}
