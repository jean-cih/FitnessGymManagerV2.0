﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity.Core.Common.CommandTrees.ExpressionBuilder;
using System.Data.SQLite;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Media;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;


namespace GymApplicationV2._0
{
    public partial class Form1 : Form
    {
        string nameClient = "";
        string surnameClient = "";
        string numberCard;
        string filePath = "AppFiles/Font.txt";
        bool clickFlag = false;

        public Form1()
        {
            InitializeComponent();

            foreach (Control control in this.Controls)
            {
                control.MouseEnter += Control_MouseEnter;
                //control.MouseLeave += Control_MouseLeave;
            }

            panelChooseAction.Visible = false;
        }

        private void Control_MouseEnter(object sender, EventArgs e)
        {
            panelChooseAction.Visible = false;
        }

        /*
        private void Control_MouseLeave(object sender, EventArgs e)
        {
            panelChooseAction.Visible = false;
        }
        */
        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);

            bool isInsideAnyControl = false;
            foreach (Control control in this.Controls)
            {
                if (jeanModernButtonServices.Bounds.Contains(e.Location) || (clickFlag && panelChooseAction.Bounds.Contains(e.Location)))
                {
                    isInsideAnyControl = true;
                }
                else
                {
                    clickFlag = false;
                }
                panelChooseAction.Visible = isInsideAnyControl ? true : false;
            }

        }

        /*
        private void MainForm_Load(object sender, EventArgs e)
        {
            panelChooseAction.Visible = false;
        }
        */
        private void Form1_Load(object sender, EventArgs e)
        {
            CheckIfDataExistsFont();

            jeanModernButtonSettings.Font = new System.Drawing.Font("Настройки", DataClass.sizeFontButtons);
            jeanModernButtonServices.Font = new System.Drawing.Font("Услуги", DataClass.sizeFontButtons);
            jeanModernButtonPurchase.Font = new System.Drawing.Font("Товары", DataClass.sizeFontButtons);
            jeanModernButtonClients.Font = new System.Drawing.Font("Клиенты", DataClass.sizeFontButtons);
            jeanModernButtonReport.Font = new System.Drawing.Font("Отчет", DataClass.sizeFontButtons);
            jeanModernButtonNewMember.Font = new System.Drawing.Font("Новый", DataClass.sizeFontButtons);
            jeanModernButtonSingleTicket.Font = new System.Drawing.Font("Разовый", DataClass.sizeFontButtons);
            jeanModernButtonChooseClient.Font = new System.Drawing.Font("Выбрать клиента", DataClass.sizeFontButtons);
            jeanModernButtonSell.Font = new System.Drawing.Font("Продать", DataClass.sizeFontButtons);

            dataGridViewClient.DefaultCellStyle.Font = new System.Drawing.Font("Contacts", DataClass.sizeFontTables);
            dataGridViewClient.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Contacts", DataClass.sizeFontTables);

            labelDateSell.Font = new System.Drawing.Font("Дата\r\nПродажи", DataClass.sizeFontCaptions - 2);

            CheckIfDataExistsClients();
            CheckIfDataExistsServices();
            CheckIfDataExistsPayment();
            CheckIfDataExistsArchive();
        }

        private void CheckIfDataExistsFont()
        {
            if (!File.Exists(filePath))
            {
                CreateFile();
            }
            else
            {
                List<string> lines = new List<string>();
                using (StreamReader sr = new StreamReader(filePath))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        lines.Add(line);
                    }
                }
                try
                {
                    DataClass.sizeFontCaptions = Convert.ToInt32(lines[3]);
                    DataClass.sizeFontButtons = Convert.ToInt32(lines[5]);
                    DataClass.sizeFontTables = Convert.ToInt32(lines[7]);
                }
                catch (Exception ex)
                {
                    File.Delete(filePath);

                    CreateFile();
                }
            }
        }

        private void CheckIfDataExistsClients()
        {
            if (!File.Exists("Databases\\Clients.db"))
            {
                ClientsContext.CreatingDatabase();
            }
        }

        private void CheckIfDataExistsServices()
        {
            if (!File.Exists("Databases\\Services.db"))
            {
                ServicesContext.CreatingDatabase();
            }
        }

        private void CheckIfDataExistsPayment()
        {
            if (!File.Exists("Databases\\Payments.db"))
            {
                HistoryPaymentContext.CreatingDatabase();
            }
        }

        private void CheckIfDataExistsArchive()
        {
            if (!File.Exists("Databases\\Archive.db"))
            {
                ArchiveServicesContext.CreatingDatabase();
            }
        }

        private void CreateFile()
        {
            using (FileStream fs = File.Create(filePath))
            {
                byte[] info = new UTF8Encoding(true).GetBytes("НИ В КОЕМ СЛУЧАЕ НЕ ИЗМЕНЯТЬ ЭТОТ ФАЙЛ\n\nРазмер шрифта заголовков:\n10\nРазмер шрифта названий кнопок:\n10\nРазмер шрифта в таблице:\n10\n");
                fs.Write(info, 0, info.Length);
            }
        }   

        private void buttonNewMembership_Click(object sender, EventArgs e)
        {
            NewClient newClient = new NewClient();
            newClient.Show();
        }

        private void textNumberClient_TextChanged(object sender, EventArgs e)
        {
            if (jeanTextBoxNumberCard.Text.Length != 13)
                return; 

            //Проверка на время
            object timeLeft = ClientsContext.GetElementClient("SELECT Срок_абонемента FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");

            if(timeLeft.ToString() == "")
            {
                SystemSounds.Hand.Play();

                Message.MessageWindowOk("Клиент без абонемента");

                dataGridViewClient.DataSource = ClientsContext.GetDataFromDatabase("SELECT Фамилия, Имя, №Карты, Абонемент, Срок_абонемента, Посещений_осталось FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");
                object surname, name;
                surname = ClientsContext.GetElementClient("SELECT Имя FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");
                name = ClientsContext.GetElementClient("SELECT Фамилия FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");

                nameClient = name.ToString();
                surnameClient = surname.ToString();
                jeanModernButtonSell.Text = "Продать\n" + nameClient + " " + surnameClient;
                numberCard = jeanTextBoxNumberCard.Text;

                jeanTextBoxNumberCard.Text = "";

                return;
            }
         
            if (Convert.ToDateTime(timeLeft).Subtract(DateTime.Now).Days < 0)
            {
                SystemSounds.Exclamation.Play();

                //Вытаскиваем из таблицы имя и фамилию для кнопки
                object surname, name, gender, numberPhone, dateBirthday, discount, email;
                surname = ClientsContext.GetElementClient("SELECT Имя FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");
                name = ClientsContext.GetElementClient("SELECT Фамилия FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");
                gender = ClientsContext.GetElementClient("SELECT Пол FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");
                numberPhone = ClientsContext.GetElementClient("SELECT Телефон FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");
                dateBirthday = ClientsContext.GetElementClient("SELECT Дата_рождения FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");
                discount = ClientsContext.GetElementClient("SELECT Скидка FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");
                email = ClientsContext.GetElementClient("SELECT Email FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");

                nameClient = name.ToString();
                surnameClient = surname.ToString();
                jeanModernButtonSell.Text = "Продать\n" + nameClient + " " + surnameClient;
                numberCard = jeanTextBoxNumberCard.Text;
                
                dataGridViewClient.DataSource = ClientsContext.GetDataFromDatabase("SELECT №Карты, Фамилия, Имя, Отчество, Абонемент, Срок_абонемента, Посещений_осталось FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");  

                //Получение максимального id клиента
                SQLiteConnection conn2 = new SQLiteConnection(ArchiveServicesContext.ConnectionStringArchive());
                conn2.Open();

                SQLiteCommand cmd2 = new SQLiteCommand("SELECT Id FROM Archive", conn2);
                SQLiteDataReader reader = cmd2.ExecuteReader();

                object id = null;
                while (reader.Read())
                {
                    id = reader[0];
                }

                reader.Close();
                cmd2.Dispose();
                conn2.Close();

                int number;

                if (id != null)
                    number = Convert.ToInt32(id) + 1;
                else
                    number = 1;

                //Занос закончившегося абонемента в архив
                // Этот процесс нужно вынести в отдельную функцию и сделать асинхронной 
                using (SQLiteConnection conn = new SQLiteConnection(ArchiveServicesContext.ConnectionStringArchive()))
                {
                    string commandStringNew = "INSERT INTO Archive (" +
                        "[Id],[Фамилия],[Имя],[Пол],[Телефон],[№Карты],[Абонемент],[Срок_абонемента],[Посещений_осталось],[Отчество],[Email],[Дата_рождения],[Скидка])" +
                        " VALUES (@Id,@Фамилия,@Имя,@Пол,@Телефон,@№Карты,@Абонемент,@Срок_абонемента,@Посещений_осталось,@Отчество,@Email,@Дата_рождения,@Скидка)";
                    using (SQLiteCommand cmd = new SQLiteCommand(commandStringNew, conn))
                    {
                        conn.Open();

                        cmd.Parameters.AddWithValue("@Id", number.ToString());
                        cmd.Parameters.AddWithValue("@Фамилия", surname);
                        cmd.Parameters.AddWithValue("@Имя", name);
                        cmd.Parameters.AddWithValue("@Пол", gender);
                        cmd.Parameters.AddWithValue("@Телефон", numberPhone);
                        cmd.Parameters.AddWithValue("@№Карты", jeanTextBoxNumberCard.Text);
                        cmd.Parameters.AddWithValue("@Абонемент", dataGridViewClient.SelectedRows[0].Cells[4].Value.ToString());
                        cmd.Parameters.AddWithValue("@Срок_абонемента", dataGridViewClient.SelectedRows[0].Cells[5].Value.ToString());
                        cmd.Parameters.AddWithValue("@Посещений_осталось", dataGridViewClient.SelectedRows[0].Cells[6].Value.ToString());
                        cmd.Parameters.AddWithValue("@Отчество", dataGridViewClient.SelectedRows[0].Cells[3].Value.ToString());
                        cmd.Parameters.AddWithValue("@Email", email);
                        cmd.Parameters.AddWithValue("@Дата_рождения", dateBirthday);
                        cmd.Parameters.AddWithValue("@Скидка", discount);

                        cmd.ExecuteNonQuery();
                    }
                }

                jeanTextBoxNumberCard.Text = "";

                Message.MessageWindowOk("Абонемент закончился по времени");

                ClientsContext.CommandDataClient("UPDATE Contacts SET " +
                "Посетил = '" + "" + "'," +
                "Абонемент = '" + "" + "'," +
                "Срок_абонемента = '" + "" + "'," +
                "Посещений_осталось = '" + "" + "' " +
                "WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");

                return;
            }

            //Находим количество оставшихся посещений
            object left = ClientsContext.GetElementClient("SELECT Посещений_осталось FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");
    
            //Обработка краевых случаев
            if (left == null)
            {
                SystemSounds.Exclamation.Play();

                Message.MessageWindowOk("Такого клиента не существует");
                jeanTextBoxNumberCard.Text = "";
                return;
            }
            
            //Безлимитный
            if (left.ToString() == "")
            {
                SystemSounds.Asterisk.Play();

                ClientsContext.CommandDataClient("UPDATE Contacts SET " +
                        "Посетил = '" + DateTime.Now + "' " +
                        "WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");

                Message.MessageWindowOk("Клиент отмечен");

                dataGridViewClient.DataSource = ClientsContext.GetDataFromDatabase("SELECT Фамилия, Имя, №Карты, Абонемент, Срок_абонемента, Посещений_осталось FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");
                jeanTextBoxNumberCard.Text = "";
                return;
            }

            int numberLeft = Convert.ToInt32(left);

            if(numberLeft <= 0)
            {
                SystemSounds.Exclamation.Play();

                //Вытаскиваем из таблицы имя и фамилию для кнопки
                object surname, name, gender, numberPhone, dateBirthday, discount, email;
                surname = ClientsContext.GetElementClient("SELECT Имя FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");
                name = ClientsContext.GetElementClient("SELECT Фамилия FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");
                gender = ClientsContext.GetElementClient("SELECT Пол FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");
                numberPhone = ClientsContext.GetElementClient("SELECT Телефон FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");
                dateBirthday = ClientsContext.GetElementClient("SELECT Дата_рождения FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");
                discount = ClientsContext.GetElementClient("SELECT Скидка FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");
                email = ClientsContext.GetElementClient("SELECT Email FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");

                nameClient = name.ToString();
                surnameClient = surname.ToString();
                jeanModernButtonSell.Text = "Продать\n" + nameClient + " " + surnameClient;
                numberCard = jeanTextBoxNumberCard.Text;

                dataGridViewClient.DataSource = ClientsContext.GetDataFromDatabase("SELECT №Карты, Фамилия, Имя, Отчество, Абонемент, Срок_абонемента, Посещений_осталось FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");
                //Получение максимального id клиента
                SQLiteConnection conn2 = new SQLiteConnection(ArchiveServicesContext.ConnectionStringArchive());
                conn2.Open();

                SQLiteCommand cmd2 = new SQLiteCommand("SELECT Id FROM Archive", conn2);
                SQLiteDataReader reader = cmd2.ExecuteReader();

                object id = null;
                while (reader.Read())
                {
                    id = reader[0];
                }

                reader.Close();
                cmd2.Dispose();
                conn2.Close();

                int number;

                if (id != null)
                    number = Convert.ToInt32(id) + 1;
                else
                    number = 1;

                //Занос закончившегося абонемента в архив
                // Этот процесс нужно вынести в отдельную функцию и сделать асинхронной 
                using (SQLiteConnection conn = new SQLiteConnection(ArchiveServicesContext.ConnectionStringArchive()))
                {
                    string commandStringNew = "INSERT INTO Archive (" +
                        "[Id],[Фамилия],[Имя],[Пол],[Телефон],[№Карты],[Абонемент],[Срок_абонемента],[Посещений_осталось],[Отчество],[Email],[Дата_рождения],[Скидка])" +
                        " VALUES (@Id,@Фамилия,@Имя,@Пол,@Телефон,@№Карты,@Абонемент,@Срок_абонемента,@Посещений_осталось,@Отчество,@Email,@Дата_рождения,@Скидка)";
                    using (SQLiteCommand cmd = new SQLiteCommand(commandStringNew, conn))
                    {
                        conn.Open();

                        cmd.Parameters.AddWithValue("@Id", number.ToString());
                        cmd.Parameters.AddWithValue("@Фамилия", surname);
                        cmd.Parameters.AddWithValue("@Имя", name);
                        cmd.Parameters.AddWithValue("@Пол", gender);
                        cmd.Parameters.AddWithValue("@Телефон", numberPhone);
                        cmd.Parameters.AddWithValue("@№Карты", jeanTextBoxNumberCard.Text);
                        cmd.Parameters.AddWithValue("@Абонемент", dataGridViewClient.SelectedRows[0].Cells[4].Value.ToString());
                        cmd.Parameters.AddWithValue("@Срок_абонемента", dataGridViewClient.SelectedRows[0].Cells[5].Value.ToString());
                        cmd.Parameters.AddWithValue("@Посещений_осталось", dataGridViewClient.SelectedRows[0].Cells[6].Value.ToString());
                        cmd.Parameters.AddWithValue("@Отчество", dataGridViewClient.SelectedRows[0].Cells[3].Value.ToString());
                        cmd.Parameters.AddWithValue("@Email", email);
                        cmd.Parameters.AddWithValue("@Дата_рождения", dateBirthday);
                        cmd.Parameters.AddWithValue("@Скидка", discount);

                        cmd.ExecuteNonQuery();
                    }
                }

                Message.MessageWindowOk("Абонемент закончился. Посещений осталось 0");

                jeanTextBoxNumberCard.Text = "";
                return;
            }

            //Отнимаем 1 от оставшихся посещений
            ClientsContext.CommandDataClient("UPDATE Contacts SET " +
                    "Посещений_осталось = '" + (numberLeft - 1).ToString() + "' " +
                    "WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");

            ClientsContext.CommandDataClient("UPDATE Contacts SET " +
                    "Посетил = '" + DateTime.Now + "' " +
                    "WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");

            SystemSounds.Asterisk.Play();

            Message.MessageWindowOk("Клиент отмечен");

            dataGridViewClient.DataSource = ClientsContext.GetDataFromDatabase("SELECT Фамилия, Имя, №Карты, Абонемент, Срок_абонемента, Посещений_осталось FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");

            jeanTextBoxNumberCard.Text = "";
        }

        private void jeanModernButtonSettings_Click(object sender, EventArgs e)
        {
            Settings settings = new Settings();
            settings.ShowDialog();

            jeanModernButtonSettings.Font = new System.Drawing.Font("Настройки", DataClass.sizeFontButtons);
            jeanModernButtonServices.Font = new System.Drawing.Font("Услуги", DataClass.sizeFontButtons);
            jeanModernButtonPurchase.Font = new System.Drawing.Font("Товары", DataClass.sizeFontButtons);
            jeanModernButtonClients.Font = new System.Drawing.Font("Клиенты", DataClass.sizeFontButtons);
            jeanModernButtonReport.Font = new System.Drawing.Font("Отчет", DataClass.sizeFontButtons);
            jeanModernButtonNewMember.Font = new System.Drawing.Font("Новый", DataClass.sizeFontButtons);
            jeanModernButtonSingleTicket.Font = new System.Drawing.Font("Разовый", DataClass.sizeFontButtons);
            jeanModernButtonChooseClient.Font = new System.Drawing.Font("Выбрать клиента", DataClass.sizeFontButtons);
            jeanModernButtonSell.Font = new System.Drawing.Font("Продать", DataClass.sizeFontButtons);

            dataGridViewClient.DefaultCellStyle.Font = new System.Drawing.Font("Contacts", DataClass.sizeFontTables);
            dataGridViewClient.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Contacts", DataClass.sizeFontTables);

            labelDateSell.Font = new System.Drawing.Font("Дата\r\nПродажи", DataClass.sizeFontCaptions - 2);
        }

        private void jeanModernButtonServices_Click(object sender, EventArgs e)
        {
            panelChooseAction.Visible = true;
            clickFlag = true;
        }

        private void jeanModernButtonPurchase_Click(object sender, EventArgs e)
        {
            Products products = new Products();
            products.Show();
        }

        private void jeanModernButtonClients_Click(object sender, EventArgs e)
        {
            Clients clients = new Clients();
            clients.Show();
        }

        private void jeanModernButtonReport_Click(object sender, EventArgs e)
        {
            Report report = new Report();
            report.Show();
        }

        private void jeanModernButtonNewMember_Click(object sender, EventArgs e)
        {
            NewClient newClient = new NewClient();
            newClient.Show();
        }

        private void jeanModernButtonSingleTicket_Click(object sender, EventArgs e)
        {
            SingleTicket singleTicket = new SingleTicket();
            singleTicket.Show();
        }

        private void jeanModernButtonChooseClient_Click(object sender, EventArgs e)
        {
            ChooseClient chooseClient = new ChooseClient();
            chooseClient.Show();
        }

        private void jeanModernButton1_Click(object sender, EventArgs e)
        {
            if (nameClient == "" || surnameClient == "")
            {
                Message.MessageWindowOk("Клиент не выбран");
                return;
            }

            DataClass.dateSellForm = dateTimePickerSell.Value;

            Services services = new Services();
            services.Show();
            services.jeanModernButtonAdd.Visible = true;
            services.jeanModernButtonAdd.Visible = false;
            services.jeanModernButtonDelete.Visible = false;
            services.jeanModernButtonChange.Visible = false;
            services.jeanModernButtonSell.Visible = true;
            services.labelName.Visible = true;
            services.jeanTextBoxPurchase.Visible = true;
            services.labelName.Text = nameClient + " " + surnameClient;
            services.labelNumberCard.Text = numberCard;
            services.labelNumberCard.Visible = true;
            services.checkBoxVisited.Visible = true;
        }

        private void jeanModernButtonService_Click(object sender, EventArgs e)
        {
            Services services = new Services();
            services.Show();
        }

        private void jeanModernButtonHistoryPayment_Click(object sender, EventArgs e)
        {
            HistoryPayment historyPayment = new HistoryPayment();
            historyPayment.Show();
        }

        private void jeanModernButtonArchive_Click(object sender, EventArgs e)
        {
            ArchiveServices archiveServices = new ArchiveServices();
            archiveServices.Show();
        }
    }
}
