﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity.Core.Common.CommandTrees.ExpressionBuilder;
using System.Data.SQLite;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
using GymApplicationV2._0.Components;
using Shadow;
using GymApplicationV2._0.Connections;
using GymApplicationV2._0.FormsServices.IssuedMemberships;
using System.Text.RegularExpressions;
using System.Reflection;
using GymApplicationV2._0.Controls;


namespace GymApplicationV2._0
{
    public partial class Form1 : ShadowedForm
    {
        string nameClient = "";
        string surnameClient = "";
        string numberCard;
        string filePath = "\\AppFiles\\Font.txt";

        private ToolStripDropDownMenu _menu;

        public Form1()
        {
            InitializeComponent();

            int screenWidth = Screen.PrimaryScreen.Bounds.Width;
            int screenHeight = Screen.PrimaryScreen.Bounds.Height;

            jeanModernButtonSettings.Location = new System.Drawing.Point(this.Width / 2 - 75 - 117 - 117, 12);
            jeanModernButtonServices.Location = new System.Drawing.Point(this.Width / 2 - 75 - 117, 12);
            jeanModernButtonPurchase.Location = new System.Drawing.Point(this.Width / 2 - 75, 12);
            jeanModernButtonClients.Location = new System.Drawing.Point(this.Width / 2 - 75 + 117, 12);
            jeanModernButtonReport.Location = new System.Drawing.Point(this.Width / 2 - 75 + 117 + 117, 12);
            panel1.Location = new System.Drawing.Point(this.Width / 2, 154);
            jeanPanel.Size = new Size(this.Width / 2 + 40, 79);

            DataClass.width = screenWidth;
            DataClass.height = screenHeight;

            jeanModernButtonServices.Click += Button_Click;
            Controls.Add(jeanModernButtonServices);

            _menu = new ToolStripDropDownMenu();
            
            _menu.Font = new System.Drawing.Font("Arial", 12, FontStyle.Regular);
            ToolStripMenuItem item1 = new ToolStripMenuItem("Абонементы", Properties.Resources.membership);
            ToolStripMenuItem item2 = new ToolStripMenuItem("Выданные абонементы", Properties.Resources.issuedMembership);
            ToolStripMenuItem item3 = new ToolStripMenuItem("Абонементы в архиве", Properties.Resources.archive);
            ToolStripMenuItem item4 = new ToolStripMenuItem("История платежей", Properties.Resources.payments);
            _menu.Items.Add(item1);
            _menu.Items.Add(item2);
            _menu.Items.Add(item3);
            _menu.Items.Add(item4);

            _menu.Items[0].Click += jeanModernButtonService_Click;
            _menu.Items[1].Click += jeanModernButtonChange_Click;
            _menu.Items[2].Click += jeanModernButtonArchive_Click;
            _menu.Items[3].Click += jeanModernButtonHistoryPayment_Click;

            
        }

        private void Button_Click(object sender, EventArgs e)
        {
            _menu.Show(jeanModernButtonServices, new System.Drawing.Point(0, jeanModernButtonServices.Height));
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            string pathToAppFiles = Environment.CurrentDirectory;

            CheckIfDataExistsFont(pathToAppFiles);

            JeanFormStyle.fStyle style;
            if (DataClass.styleForm == "UserStyle")
            {
                style = JeanFormStyle.fStyle.UserStyle;
            }
            else if (DataClass.styleForm == "SimpleDark")
            {
                style = JeanFormStyle.fStyle.SimpleDark;
            }
            else if (DataClass.styleForm == "TelegramStyle")
            {
                style = JeanFormStyle.fStyle.TelegramStyle;
            }
            else
            {
                style = JeanFormStyle.fStyle.None;
            }

            jeanFormStyle.FormStyle = style;

            
            jeanModernButtonSettings.Font = new System.Drawing.Font("Настройки", DataClass.sizeFontButtons);
            jeanModernButtonServices.Font = new System.Drawing.Font("Услуги", DataClass.sizeFontButtons);
            jeanModernButtonPurchase.Font = new System.Drawing.Font("Товары", DataClass.sizeFontButtons);
            jeanModernButtonClients.Font = new System.Drawing.Font("Клиенты", DataClass.sizeFontButtons);
            jeanModernButtonReport.Font = new System.Drawing.Font("Отчет", DataClass.sizeFontButtons);
            jeanModernButtonNewMember.Font = new System.Drawing.Font("Новый", DataClass.sizeFontButtons);
            jeanModernButtonSingleTicket.Font = new System.Drawing.Font("Разовый", DataClass.sizeFontButtons);
            jeanModernButtonChooseClient.Font = new System.Drawing.Font("Выбрать клиента", DataClass.sizeFontButtons);
            jeanModernButtonSell.Font = new System.Drawing.Font("Продать", DataClass.sizeFontButtons);
            

            dataGridViewClient.DefaultCellStyle.Font = new System.Drawing.Font("Contacts", DataClass.sizeFontTables);
            dataGridViewClient.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Contacts", DataClass.sizeFontTables);
            
            CheckIfDataExistsClients();
            CheckIfDataExistsServices();
            CheckIfDataExistsPayment();
            CheckIfDataExistsArchive();
            CheckIfDataExistsIssued();
        }

        private void CheckIfDataExistsFont(string path)
        {
            if (!File.Exists(path + filePath))
            {
                CreateFile();
            }
            else
            {
                List<string> lines = new List<string>();
                using (StreamReader sr = new StreamReader(path + filePath))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        lines.Add(line);
                    }
                }
                try
                {
                    DataClass.sizeFontCaptions = Convert.ToInt32(lines[3]);
                    DataClass.sizeFontButtons = Convert.ToInt32(lines[5]);
                    DataClass.sizeFontTables = Convert.ToInt32(lines[7]);
                    DataClass.styleForm = lines[9];
                }
                catch (Exception ex)
                {
                    File.Delete(path + filePath);

                    CreateFile();
                }
            }
        }

        
        private void CheckIfDataExistsClients()
        {
            if (!File.Exists("Databases\\Clients.db"))
            {
                ClientsContext.CreatingDatabase();
            }
        }
        

        private void CheckIfDataExistsServices()
        {
            if (!File.Exists("Databases\\Services.db"))
            {
                ServicesContext.CreatingDatabase();
            }
        }

        private void CheckIfDataExistsPayment()
        {
            if (!File.Exists("Databases\\Payments.db"))
            {
                HistoryPaymentContext.CreatingDatabase();
            }
        }

        private void CheckIfDataExistsArchive()
        {
            if (!File.Exists("Databases\\Archive.db"))
            {
                ArchiveServicesContext.CreatingDatabase();
            }
        }

        private void CheckIfDataExistsIssued()
        {
            if (!File.Exists("Databases\\IssuedMembership.db"))
            {
                IssuedMembershipContext.CreatingDatabase();
            }
        }

        private void CreateFile()
        {
            using (FileStream fs = File.Create(filePath))
            {
                byte[] info = new UTF8Encoding(true).GetBytes("НИ В КОЕМ СЛУЧАЕ НЕ ИЗМЕНЯТЬ ЭТОТ ФАЙЛ\n\nРазмер шрифта заголовков:\n10\nРазмер шрифта названий кнопок:\n10\nРазмер шрифта в таблице:\n10\nДизайн оформления:\nNone");
                fs.Write(info, 0, info.Length);
            }
        }   

        private void textNumberClient_TextChanged(object sender, EventArgs e)
        {
            if (Regex.IsMatch(jeanTextBoxNumberCard.Text, @"^-?\d+(\d+)?$") || jeanTextBoxNumberCard.Text.Length == 0)
            {
                jeanTextBoxNumberCard.BackColor = Color.White;
            }
            else
            {
                jeanTextBoxNumberCard.BackColor = Color.FromArgb(255, 150, 150);
            }

            if (jeanTextBoxNumberCard.Text.Length != 13)
                return;

            SoundPlayer soundPlayerError = new SoundPlayer(Properties.Resources.error);

            object existClient = ClientsContext.GetElementClient("SELECT Id FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");
            if(existClient == null)
            {
                soundPlayerError.Play();
                Message.MessageWindowOk("Этот номер не существует");
                return;
            }


            object canFreeze = IssuedMembershipContext.GetElementIssued("SELECT Статус FROM Issued WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");
            if(canFreeze != null && canFreeze.ToString() == "заморожен")
            {
                object dateFreeze = IssuedMembershipContext.GetElementIssued("SELECT Дата_окончания FROM Issued WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");
                object visitsFreeze = IssuedMembershipContext.GetElementIssued("SELECT Посещений_осталось FROM Issued WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");

                if (DateTime.Compare(Convert.ToDateTime(dateFreeze), DateTime.Now) < 0)
                {
                    Message.MessageWindowOk("Заморозка закончилась");
                    jeanTextBoxNumberCard.Text = "";
                    return;
                }

                ClientsContext.CommandDataClient("UPDATE Contacts SET " +
                    "Посетил = '" + DateTime.Now.ToShortDateString() + "'," +
                    "Срок_абонемента = '" + dateFreeze + "'," +
                    "Посещений_осталось = '" + visitsFreeze + "' " +
                    "WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");

                IssuedMembershipContext.CommandDataIssued("UPDATE Issued SET " +
                    "Статус = '" + "активирован" + "' " +
                    "WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");

                Message.MessageWindowOk("Заморозка снята");
            }


            //Проверка на время
            object timeLeft = ClientsContext.GetElementClient("SELECT Срок_абонемента FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");

            if(timeLeft.ToString() == "")
            {
                soundPlayerError.Play();

                Message.MessageWindowOk("Клиент без абонемента");

                dataGridViewClient.DataSource = ClientsContext.GetDataFromDatabase("SELECT Фамилия, Имя, №Карты, Абонемент, Срок_абонемента, Посещений_осталось FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");
                jeanPanel.Visible = true;
                object surname, name;
                surname = ClientsContext.GetElementClient("SELECT Имя FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");
                name = ClientsContext.GetElementClient("SELECT Фамилия FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");

                nameClient = name.ToString();
                surnameClient = surname.ToString();
                jeanModernButtonSell.Text = "Продать\n" + nameClient + " " + surnameClient;
                numberCard = jeanTextBoxNumberCard.Text;

                jeanTextBoxNumberCard.Text = "";

                return;
            }
         
            if (Convert.ToDateTime(timeLeft).Subtract(DateTime.Now).Days < 0)
            {
                //Вытаскиваем из таблицы имя и фамилию для кнопки
                object surname, name, membership, price;
                surname = ClientsContext.GetElementClient("SELECT Фамилия FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");
                name = ClientsContext.GetElementClient("SELECT Имя FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");
                membership = ClientsContext.GetElementClient("SELECT Абонемент FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");
                price = ServicesContext.GetElementService("SELECT Цена FROM Descriptions WHERE Наименование = '" + membership.ToString() + "';");

                nameClient = name.ToString();
                surnameClient = surname.ToString();
                jeanModernButtonSell.Text = "Продать\n" + nameClient + " " + surnameClient;
                numberCard = jeanTextBoxNumberCard.Text;
                
                dataGridViewClient.DataSource = ClientsContext.GetDataFromDatabase("SELECT №Карты, Фамилия, Имя, Отчество, Абонемент, Срок_абонемента, Посещений_осталось FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");
                jeanPanel.Visible = true;
                //Получение максимального id клиента
                SQLiteConnection conn2 = new SQLiteConnection(ArchiveServicesContext.ConnectionStringArchive());
                conn2.Open();

                SQLiteCommand cmd2 = new SQLiteCommand("SELECT Id FROM Archive", conn2);
                SQLiteDataReader reader = cmd2.ExecuteReader();

                object id = null;
                while (reader.Read())
                {
                    id = reader[0];
                }

                reader.Close();
                cmd2.Dispose();
                conn2.Close();

                int number;

                if (id != null)
                    number = Convert.ToInt32(id) + 1;
                else
                    number = 1;

                //Занос закончившегося абонемента в архив
                // Этот процесс нужно вынести в отдельную функцию и сделать асинхронной 
                using (SQLiteConnection conn = new SQLiteConnection(ArchiveServicesContext.ConnectionStringArchive()))
                {
                    string commandStringNew = "INSERT INTO Archive (" +
                        "[Id],[Клиент],[№Карты],[Дата_окончания],[Абонемент],[Оплата],[Посещений_осталось])" +
                        " VALUES (@Id,@Клиент,@№Карты,@Дата_окончания,@Абонемент,@Оплата,@Посещений_осталось)";
                    using (SQLiteCommand cmd = new SQLiteCommand(commandStringNew, conn))
                    {
                        conn.Open();

                        cmd.Parameters.AddWithValue("@Id", number.ToString());
                        cmd.Parameters.AddWithValue("@Клиент", surname + " " + name + " " + dataGridViewClient.SelectedRows[0].Cells[3].Value.ToString());
                        cmd.Parameters.AddWithValue("@№Карты", jeanTextBoxNumberCard.Text);
                        cmd.Parameters.AddWithValue("@Дата_окончания", dataGridViewClient.SelectedRows[0].Cells[5].Value.ToString());
                        cmd.Parameters.AddWithValue("@Абонемент", dataGridViewClient.SelectedRows[0].Cells[4].Value.ToString());
                        cmd.Parameters.AddWithValue("@Оплата", price.ToString());
                        cmd.Parameters.AddWithValue("@Посещений_осталось", dataGridViewClient.SelectedRows[0].Cells[6].Value.ToString());

                        cmd.ExecuteNonQuery();
                    }
                }

                jeanTextBoxNumberCard.Text = "";

                soundPlayerError.Play();

                Message.MessageWindowOk("Абонемент закончился по времени");

                ClientsContext.CommandDataClient("UPDATE Contacts SET " +
                    "Посетил = '" + "" + "'," +
                    "Абонемент = '" + "" + "'," +
                    "Срок_абонемента = '" + "" + "'," +
                    "Посещений_осталось = '" + "" + "' " +
                    "WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");

                return;
            }

            //Находим количество оставшихся посещений
            object left = ClientsContext.GetElementClient("SELECT Посещений_осталось FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");
    
            //Обработка краевых случаев
            if (left == null)
            {
                soundPlayerError.Play();

                Message.MessageWindowOk("Такого клиента не существует");
                jeanTextBoxNumberCard.Text = "";
                return;
            }
            
            //Безлимитный
            if (left.ToString() == "")
            {
                ClientsContext.CommandDataClient("UPDATE Contacts SET " +
                        "Посетил = '" + DateTime.Now + "' " +
                        "WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");

                Message.MessageWindowOk("Клиент отмечен");

                dataGridViewClient.DataSource = ClientsContext.GetDataFromDatabase("SELECT Фамилия, Имя, №Карты, Абонемент, Срок_абонемента, Посещений_осталось FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");
                jeanPanel.Visible = true;

                jeanTextBoxNumberCard.Text = "";
                return;
            }

            int numberLeft = Convert.ToInt32(left);

            if(numberLeft <= 0)
            {
                //Вытаскиваем из таблицы имя и фамилию для кнопки
                object surname, name, membership, price;
                surname = ClientsContext.GetElementClient("SELECT Фамилия FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");
                name = ClientsContext.GetElementClient("SELECT Имя FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");
                membership = ClientsContext.GetElementClient("SELECT Абонемент FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");
                price = ServicesContext.GetElementService("SELECT Цена FROM Descriptions WHERE Наименование = '" + membership.ToString() + "';");

                nameClient = name.ToString();
                surnameClient = surname.ToString();
                jeanModernButtonSell.Text = "Продать\n" + nameClient + " " + surnameClient;
                numberCard = jeanTextBoxNumberCard.Text;

                dataGridViewClient.DataSource = ClientsContext.GetDataFromDatabase("SELECT №Карты, Фамилия, Имя, Отчество, Абонемент, Срок_абонемента, Посещений_осталось FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");
                jeanPanel.Visible = true;
                //Получение максимального id клиента
                SQLiteConnection conn2 = new SQLiteConnection(ArchiveServicesContext.ConnectionStringArchive());
                conn2.Open();

                SQLiteCommand cmd2 = new SQLiteCommand("SELECT Id FROM Archive", conn2);
                SQLiteDataReader reader = cmd2.ExecuteReader();

                object id = null;
                while (reader.Read())
                {
                    id = reader[0];
                }

                reader.Close();
                cmd2.Dispose();
                conn2.Close();

                int number;

                if (id != null)
                    number = Convert.ToInt32(id) + 1;
                else
                    number = 1;

                //Занос закончившегося абонемента в архив
                // Этот процесс нужно вынести в отдельную функцию и сделать асинхронной    
                using (SQLiteConnection conn = new SQLiteConnection(ArchiveServicesContext.ConnectionStringArchive()))
                {
                    string commandStringNew = "INSERT INTO Archive (" +
                        "[Id],[Клиент],[№Карты],[Дата_окончания],[Абонемент],[Оплата],[Посещений_осталось])" +
                        " VALUES (@Id,@Клиент,@№Карты,@Дата_окончания,@Абонемент,@Оплата,@Посещений_осталось)";
                    using (SQLiteCommand cmd = new SQLiteCommand(commandStringNew, conn))
                    {
                        conn.Open();

                        cmd.Parameters.AddWithValue("@Id", number.ToString());
                        cmd.Parameters.AddWithValue("@Клиент", surname + " " + name + " " + dataGridViewClient.SelectedRows[0].Cells[3].Value.ToString());
                        cmd.Parameters.AddWithValue("@№Карты", jeanTextBoxNumberCard.Text);
                        cmd.Parameters.AddWithValue("@Дата_окончания", dataGridViewClient.SelectedRows[0].Cells[5].Value.ToString());
                        cmd.Parameters.AddWithValue("@Абонемент", dataGridViewClient.SelectedRows[0].Cells[4].Value.ToString());
                        cmd.Parameters.AddWithValue("@Оплата", price.ToString());
                        cmd.Parameters.AddWithValue("@Посещений_осталось", dataGridViewClient.SelectedRows[0].Cells[6].Value.ToString());

                        cmd.ExecuteNonQuery();
                    }
                }

                soundPlayerError.Play();

                Message.MessageWindowOk("Абонемент закончился. Посещений осталось 0");

                jeanTextBoxNumberCard.Text = "";
                return;
            }

            //Отнимаем 1 от оставшихся посещений
            ClientsContext.CommandDataClient("UPDATE Contacts SET " +
                    "Посещений_осталось = '" + (numberLeft - 1).ToString() + "' " +
                    "WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");

            ClientsContext.CommandDataClient("UPDATE Contacts SET " +
                    "Посетил = '" + DateTime.Now + "' " +
                    "WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");

            IssuedMembershipContext.CommandDataIssued("UPDATE Issued SET " +
                    "Посещений_осталось = '" + (numberLeft - 1).ToString() + "' " +
                    "WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");

            Message.MessageWindowOk("Клиент отмечен");

            dataGridViewClient.DataSource = ClientsContext.GetDataFromDatabase("SELECT Фамилия, Имя, №Карты, Абонемент, Срок_абонемента, Посещений_осталось FROM Contacts WHERE №Карты = '" + jeanTextBoxNumberCard.Text + "';");
            jeanPanel.Visible = true;
            jeanTextBoxNumberCard.Text = "";
        }

        private void jeanModernButtonSettings_Click(object sender, EventArgs e)
        {
            Settings settings = new Settings();
            settings.ShowDialog();

            jeanModernButtonSettings.Font = new System.Drawing.Font("Настройки", DataClass.sizeFontButtons);
            jeanModernButtonServices.Font = new System.Drawing.Font("Услуги", DataClass.sizeFontButtons);
            jeanModernButtonPurchase.Font = new System.Drawing.Font("Товары", DataClass.sizeFontButtons);
            jeanModernButtonClients.Font = new System.Drawing.Font("Клиенты", DataClass.sizeFontButtons);
            jeanModernButtonReport.Font = new System.Drawing.Font("Отчет", DataClass.sizeFontButtons);
            jeanModernButtonNewMember.Font = new System.Drawing.Font("Новый", DataClass.sizeFontButtons);
            jeanModernButtonSingleTicket.Font = new System.Drawing.Font("Разовый", DataClass.sizeFontButtons);
            jeanModernButtonChooseClient.Font = new System.Drawing.Font("Выбрать клиента", DataClass.sizeFontButtons);
            jeanModernButtonSell.Font = new System.Drawing.Font("Продать", DataClass.sizeFontButtons);

            dataGridViewClient.DefaultCellStyle.Font = new System.Drawing.Font("Contacts", DataClass.sizeFontTables);
            dataGridViewClient.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Contacts", DataClass.sizeFontTables);

            JeanFormStyle.fStyle style = JeanFormStyle.fStyle.None;
            if (DataClass.styleForm == "UserStyle")
            {
                style = JeanFormStyle.fStyle.UserStyle;
            }
            else if (DataClass.styleForm == "SimpleDark")
            {
                style = JeanFormStyle.fStyle.SimpleDark;
            }
            else if (DataClass.styleForm == "TelegramStyle")
            {
                style = JeanFormStyle.fStyle.TelegramStyle;
            }

            jeanFormStyle.FormStyle = style;
        }

        private void jeanModernButtonPurchase_Click(object sender, EventArgs e)
        {
            Products products = new Products();
            products.Show();
        }

        private void jeanModernButtonClients_Click(object sender, EventArgs e)
        {
            Clients clients = new Clients();
            clients.Show();
        }

        private void jeanModernButtonReport_Click(object sender, EventArgs e)
        {
            Report report = new Report();
            report.Show();
        }

        private void jeanModernButtonNewMember_Click(object sender, EventArgs e)
        {
            NewClient newClient = new NewClient();
            newClient.Show();
        }

        private void jeanModernButtonSingleTicket_Click(object sender, EventArgs e)
        {
            SingleTicket singleTicket = new SingleTicket();
            singleTicket.Show();
        }

        private void jeanModernButtonChooseClient_Click(object sender, EventArgs e)
        {
            ChooseClient chooseClient = new ChooseClient();
            chooseClient.Show();
        }

        private void jeanModernButton1_Click(object sender, EventArgs e)
        {
            if (nameClient == "" || surnameClient == "")
            {
                Message.MessageWindowOk("Клиент не выбран");
                return;
            }

            Services services = new Services();
            services.Show();
            services.jeanModernButtonAdd.Visible = true;
            services.jeanModernButtonAdd.Visible = false;
            services.jeanModernButtonDelete.Visible = false;
            services.jeanModernButtonChange.Visible = false;
            services.jeanModernButtonSell.Visible = true;
            services.labelName.Visible = true;
            services.jeanTextBoxPurchase.Visible = true;
            services.labelName.Text = nameClient + " " + surnameClient;
            services.labelNumberCard.Text = numberCard;
            services.labelNumberCard.Visible = true;
            services.checkBoxVisited.Visible = true;
        }

        private void jeanModernButtonService_Click(object sender, EventArgs e)
        {
            Services services = new Services();
            services.Show();
        }

        private void jeanModernButtonChange_Click(object sender, EventArgs e)
        {
            IssuedMembership issued = new IssuedMembership();
            issued.Show();
        }

        private void jeanModernButtonArchive_Click(object sender, EventArgs e)
        {
            ArchiveServices archiveServices = new ArchiveServices();
            archiveServices.Show();
        }

        private void jeanModernButtonHistoryPayment_Click(object sender, EventArgs e)
        {
            HistoryPayment historyPayment = new HistoryPayment();
            historyPayment.Show();
        }

    }
}
