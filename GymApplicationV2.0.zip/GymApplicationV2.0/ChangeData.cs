﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace GymApplicationV2._0
{
    public partial class ChangeData : Form
    {
        public ChangeData()
        {
            InitializeComponent();
        }

        private void ChangeData_Load(object sender, EventArgs e)
        {
            CheckIfDataExists();
        }

        private void CheckIfDataExists()
        {
            if (!File.Exists("Databases\\Clients.db"))
            {
                ClientsContext.CreatingDatabase();
            }
            else
            {
                dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts");
            }
        }

        int key = 0;
        private void dataGridViewClients_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            key = Convert.ToInt32(dataGridViewClients.SelectedRows[0].Cells[0].Value.ToString());
            textSurname.Text = dataGridViewClients.SelectedRows[0].Cells[1].Value.ToString();
            textName.Text = dataGridViewClients.SelectedRows[0].Cells[2].Value.ToString();
            textFather.Text = dataGridViewClients.SelectedRows[0].Cells[11].Value.ToString();
            textNumber.Text = dataGridViewClients.SelectedRows[0].Cells[4].Value.ToString();
            textNumberCard.Text = dataGridViewClients.SelectedRows[0].Cells[5].Value.ToString();
            textSex.Text = dataGridViewClients.SelectedRows[0].Cells[3].Value.ToString();
            textEmail.Text = dataGridViewClients.SelectedRows[0].Cells[12].Value.ToString();
            textBirthday.Text = dataGridViewClients.SelectedRows[0].Cells[13].Value.ToString();
            textDiscount.Text = dataGridViewClients.SelectedRows[0].Cells[14].Value.ToString();
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            ClientsContext.CommandDataClient("UPDATE Contacts SET " +
                    "Фамилия = '" + textSurname.Text.Trim() + "'," +
                    "Имя = '" + textName.Text.Trim() + "'," +
                    "Пол = '" + textSex.Text.Trim() + "'," +
                    "Телефон = '" + textNumber.Text.Trim() + "'," +
                    "№Карты = '" + textNumberCard.Text.Trim() + "'," +
                    "Отчество = '" + textFather.Text.Trim() + "' " +
                    "Email = '" + textEmail.Text.Trim() + "' " +
                    "ДатаРождения = '" + textBirthday.Text.Trim() + "' " +
                    "Скидка = '" + textDiscount.Text.Trim() + "' " +
                    "WHERE Id = '" + key + "';");

            Message.MessageWindowOk("Данные клиента обновлены");

            dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts");

            textSurname.Text = "";
            textName.Text = "";
            textSex.Text = "";
            textNumber.Text = "";
            textNumberCard.Text = "";
            textFather.Text = "";
            textEmail.Text = "";
            textBirthday.Text = "";
            textDiscount.Text = "";
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (textSurname.Text == "" || textName.Text == "")
            {
                Message.MessageWindowOk("Клиент не выбран");

                return;
            }

            DialogResult result = Message.MessageWindowYesNo("Вы действительно хотите удалить клиента?");

            if (result == DialogResult.No)
                return;

            ClientsContext.CommandDataClient("DELETE FROM Contacts Where Id = '" + key + "' ");

            Message.MessageWindowOk("Клиент удален");

            dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts");

            textSurname.Text = "";
            textName.Text = "";
            textSex.Text = "";
            textNumber.Text = "";
            textNumberCard.Text = "";
            textFather.Text = "";
            textEmail.Text = "";
            textBirthday.Text = "";
            textDiscount.Text = "";
        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            textSearch.Text = "";
            dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts");
        }

        private void textSearch_TextChanged(object sender, EventArgs e)
        {
            if (textSearch.Text == "")
            {
                dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts");
                return;
            }

            dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase($"" +
                $"SELECT * " +
                $"FROM Contacts " +
                $"WHERE №Карты LIKE '%{textSearch.Text}%' " +
                $"OR Фамилия LIKE '%{textSearch.Text}%' " +
                $"OR Имя LIKE '%{textSearch.Text}%'");
        }
    }
}
