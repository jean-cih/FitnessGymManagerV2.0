﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlTypes;

namespace GymApplicationV2._0
{
    public partial class Clients : Form
    {
        public Clients()
        {
            InitializeComponent();
        }

        private void Clients_Load(object sender, EventArgs e)
        {
            CheckIfDataExists();
        }

        private void CheckIfDataExists()
        {
            if (!File.Exists("Databases\\Clients.db"))
            {
                ClientsContext.CreatingDatabase();
            }
            else
            {
                dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase("SELECT Фамилия, Имя, Пол, Телефон, №Карты, Покупка, Посетил, Абонемент, Осталось FROM Contacts");
            }
        }

        int key = 0;
        private void dataGridViewClients_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            key = Convert.ToInt32(dataGridViewClients.SelectedRows[0].Cells[0].Value.ToString());
            textSurname.Text = dataGridViewClients.SelectedRows[0].Cells[1].Value.ToString();
            textName.Text = dataGridViewClients.SelectedRows[0].Cells[2].Value.ToString();
            textSex.Text = dataGridViewClients.SelectedRows[0].Cells[3].Value.ToString();
            textNumber.Text = dataGridViewClients.SelectedRows[0].Cells[4].Value.ToString();
            textNumberCard.Text = dataGridViewClients.SelectedRows[0].Cells[5].Value.ToString();
            textPurchase.Text = dataGridViewClients.SelectedRows[0].Cells[8].Value.ToString();         
            textLeft.Text = dataGridViewClients.SelectedRows[0].Cells[9].Value.ToString();         
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            ClientsContext.CommandDataClient("UPDATE Contacts SET " +
                    "Фамилия = '" + textSurname.Text.Trim() + "'," +
                    "Имя = '" + textName.Text.Trim() + "'," +
                    "Пол = '" + textSex.Text.Trim() + "'," +
                    "Телефон = '" + textNumber.Text.Trim() + "'," +
                    "№Карты = '" + textNumberCard.Text.Trim() + "'," +
                    "Абонемент = '" + textPurchase.Text.Trim() + "'," +
                    "Осталось = '" + textLeft.Text.Trim() + "' " +
                    "WHERE Id = '" + key + "';");

            Message.MessageWindowOk("Данные клиента обновлены");

            dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase("SELECT Фамилия, Имя, Пол, Телефон, №Карты, Покупка, Посетил, Абонемент, Осталось FROM Contacts");
        }
   
        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (textSurname.Text == "" && textName.Text == "" && textSex.Text == "" && textNumber.Text == "" && textNumberCard.Text == "" && textPurchase.Text == "")
            {
                Message.MessageWindowOk("Клиент не выбран");

                return;
            }

            DialogResult result = Message.MessageWindowYesNo("Вы действительно хотите удалить клиента?");

            if (result == DialogResult.No)
                return;

            ClientsContext.CommandDataClient("DELETE FROM Contacts Where Id = '" + key + "' ");
  
            Message.MessageWindowOk("Клиент удален");

            dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase("SELECT Фамилия, Имя, Пол, Телефон, №Карты, Покупка, Посетил, Абонемент, Осталось FROM Contacts");
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            if (textSearch.Text == "")
                return;

            dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase($"SELECT Фамилия, Имя, Пол, Телефон, №Карты, Покупка, Посетил, Абонемент, Осталось FROM Contacts WHERE {comboSearch.Text} = '" + textSearch.Text + "';");

            textSearch.Text = "";
        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase("SELECT Фамилия, Имя, Пол, Телефон, №Карты, Покупка, Посетил, Абонемент, Осталось FROM Contacts");
        }
    }
}
