﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlTypes;
using System.Text.RegularExpressions;

namespace GymApplicationV2._0
{
    public partial class Clients : Form
    {
        public Clients()
        {
            InitializeComponent();
        }

        private void Clients_Load(object sender, EventArgs e)
        {
            CheckIfDataExists();
            jeanModernButtonRefresh.Font = new Font("Обновить", DataClass.sizeFontButtons);
            jeanModernButtonChangeData.Font = new Font("Изменить данные клиента", DataClass.sizeFontButtons);

            dataGridViewClients.DefaultCellStyle.Font = new Font("Contacts", DataClass.sizeFontTables);
            dataGridViewClients.ColumnHeadersDefaultCellStyle.Font = new Font("Contacts", DataClass.sizeFontTables);
        }

        private void CheckIfDataExists()
        {
            if (!File.Exists("Databases\\Clients.db"))
            {
                ClientsContext.CreatingDatabase();
            }
            else
            {
                dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts");
            }
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            ChangeData changeData = new ChangeData();
            changeData.Show();
            this.Close();
        }

        private void buttonRefresh_Click_1(object sender, EventArgs e)
        {
            jeanSoftTextBoxSearch.Texts = "";
            dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts");
        }

        private void dataGridViewClients_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void jeanModernButtonRefresh_Click(object sender, EventArgs e)
        {
            jeanSoftTextBoxSearch.Texts = "";
            dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts");
        }

        private void jeanModernButtonChangeData_Click(object sender, EventArgs e)
        {
            ChangeData changeData = new ChangeData();
            changeData.Show();
            this.Close();
        }

        private void jeanSoftTextBoxSearch__TextChanged(object sender, EventArgs e)
        {
            if(jeanSoftTextBoxSearch.Texts.Length > 0)
            {
                jeanModernButtonErase.Visible = true;
            }
            else
            {
                jeanModernButtonErase.Visible = false;
            }

            dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase($"" +
                $"SELECT * " +
                $"FROM Contacts " +
                $"WHERE №Карты LIKE '%{jeanSoftTextBoxSearch.Texts}%' " +
                $"OR Фамилия LIKE '%{jeanSoftTextBoxSearch.Texts}%' " +
                $"OR Имя LIKE '%{jeanSoftTextBoxSearch.Texts}%'");
        }

        private void jeanModernButtonErase_Click(object sender, EventArgs e)
        {
            jeanSoftTextBoxSearch.Texts = "";
        }
    }
}
