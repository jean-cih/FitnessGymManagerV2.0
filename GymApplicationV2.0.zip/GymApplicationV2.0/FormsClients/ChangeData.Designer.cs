﻿namespace GymApplicationV2._0
{
    partial class ChangeData
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ChangeData));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pictureBoxSearch = new System.Windows.Forms.PictureBox();
            this.jeanModernButtonErase = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanSoftTextBoxSearch = new GymApplicationV2._0.Controls.jeanSoftTextBox();
            this.jeanFormStyle = new GymApplicationV2._0.Components.JeanFormStyle(this.components);
            this.jeanTextBoxClient = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBoxGender = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBoxPhone = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBoxPurchase = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBoxNumberCard = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBoxVisitsLeft = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBoxTerm = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBoxMembership = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBoxVisit = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBoxDiscount = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBoxBirthday = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBoxEmail = new GymApplicationV2._0.JeanTextBox();
            this.jeanModernButtonChange = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanModernButtonDelete = new GymApplicationV2._0.Controls.JeanModernButton();
            this.dataGridViewClients = new System.Windows.Forms.DataGridView();
            this.jeanPanel1 = new GymApplicationV2._0.Controls.JeanPanel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSearch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewClients)).BeginInit();
            this.jeanPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBoxSearch
            // 
            this.pictureBoxSearch.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pictureBoxSearch.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxSearch.Image")));
            this.pictureBoxSearch.Location = new System.Drawing.Point(555, 57);
            this.pictureBoxSearch.Name = "pictureBoxSearch";
            this.pictureBoxSearch.Size = new System.Drawing.Size(35, 30);
            this.pictureBoxSearch.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxSearch.TabIndex = 83;
            this.pictureBoxSearch.TabStop = false;
            // 
            // jeanModernButtonErase
            // 
            this.jeanModernButtonErase.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.jeanModernButtonErase.BackColor = System.Drawing.Color.White;
            this.jeanModernButtonErase.BackgroundColor = System.Drawing.Color.White;
            this.jeanModernButtonErase.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("jeanModernButtonErase.BackgroundImage")));
            this.jeanModernButtonErase.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.jeanModernButtonErase.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.jeanModernButtonErase.BorderRadius = 30;
            this.jeanModernButtonErase.BorderSize = 0;
            this.jeanModernButtonErase.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonErase.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonErase.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonErase.Location = new System.Drawing.Point(894, 57);
            this.jeanModernButtonErase.Name = "jeanModernButtonErase";
            this.jeanModernButtonErase.Size = new System.Drawing.Size(35, 30);
            this.jeanModernButtonErase.TabIndex = 82;
            this.jeanModernButtonErase.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonErase.UseVisualStyleBackColor = false;
            this.jeanModernButtonErase.Visible = false;
            this.jeanModernButtonErase.Click += new System.EventHandler(this.buttonRefresh_Click);
            // 
            // jeanSoftTextBoxSearch
            // 
            this.jeanSoftTextBoxSearch.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.jeanSoftTextBoxSearch.BorderColor = System.Drawing.Color.Black;
            this.jeanSoftTextBoxSearch.BorderFocusColor = System.Drawing.Color.HotPink;
            this.jeanSoftTextBoxSearch.BorderRadius = 15;
            this.jeanSoftTextBoxSearch.BorderSize = 2;
            this.jeanSoftTextBoxSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanSoftTextBoxSearch.Location = new System.Drawing.Point(541, 51);
            this.jeanSoftTextBoxSearch.Margin = new System.Windows.Forms.Padding(4);
            this.jeanSoftTextBoxSearch.Multiline = false;
            this.jeanSoftTextBoxSearch.Name = "jeanSoftTextBoxSearch";
            this.jeanSoftTextBoxSearch.Padding = new System.Windows.Forms.Padding(50, 10, 50, 10);
            this.jeanSoftTextBoxSearch.PasswordChar = false;
            this.jeanSoftTextBoxSearch.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.jeanSoftTextBoxSearch.PlaceholderText = "  Фамилия, Имя или №Карты";
            this.jeanSoftTextBoxSearch.Size = new System.Drawing.Size(393, 41);
            this.jeanSoftTextBoxSearch.TabIndex = 81;
            this.jeanSoftTextBoxSearch.Texts = "";
            this.jeanSoftTextBoxSearch.UnderlinedStyle = false;
            this.jeanSoftTextBoxSearch._TextChanged += new System.EventHandler(this.textSearch_TextChanged);
            // 
            // jeanFormStyle
            // 
            this.jeanFormStyle.AllowUserResize = false;
            this.jeanFormStyle.BackColor = System.Drawing.Color.White;
            this.jeanFormStyle.ContextMenuForm = null;
            this.jeanFormStyle.ControlBoxButtonsWidth = 20;
            this.jeanFormStyle.EnableControlBoxIconsLight = false;
            this.jeanFormStyle.EnableControlBoxMouseLight = false;
            this.jeanFormStyle.Form = this;
            this.jeanFormStyle.FormStyle = GymApplicationV2._0.Components.JeanFormStyle.fStyle.None;
            this.jeanFormStyle.HeaderColor = System.Drawing.Color.Black;
            this.jeanFormStyle.HeaderColorAdditional = System.Drawing.Color.DarkOrange;
            this.jeanFormStyle.HeaderColorGradientEnable = true;
            this.jeanFormStyle.HeaderColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.jeanFormStyle.HeaderHeight = 30;
            this.jeanFormStyle.HeaderImage = null;
            this.jeanFormStyle.HeaderTextColor = System.Drawing.Color.White;
            this.jeanFormStyle.HeaderTextFont = new System.Drawing.Font("Segoe UI", 9.75F);
            // 
            // jeanTextBoxClient
            // 
            this.jeanTextBoxClient.BackColor = System.Drawing.Color.White;
            this.jeanTextBoxClient.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBoxClient.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBoxClient.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBoxClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBoxClient.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBoxClient.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBoxClient.Location = new System.Drawing.Point(26, 52);
            this.jeanTextBoxClient.Name = "jeanTextBoxClient";
            this.jeanTextBoxClient.SelectionStart = 0;
            this.jeanTextBoxClient.Size = new System.Drawing.Size(310, 40);
            this.jeanTextBoxClient.TabIndex = 96;
            this.jeanTextBoxClient.TextInput = "";
            this.jeanTextBoxClient.TextPreview = "Клиент";
            this.jeanTextBoxClient.UseSystemPasswordChar = false;
            // 
            // jeanTextBoxGender
            // 
            this.jeanTextBoxGender.BackColor = System.Drawing.Color.White;
            this.jeanTextBoxGender.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBoxGender.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBoxGender.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBoxGender.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBoxGender.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBoxGender.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBoxGender.Location = new System.Drawing.Point(26, 100);
            this.jeanTextBoxGender.Name = "jeanTextBoxGender";
            this.jeanTextBoxGender.SelectionStart = 0;
            this.jeanTextBoxGender.Size = new System.Drawing.Size(223, 40);
            this.jeanTextBoxGender.TabIndex = 97;
            this.jeanTextBoxGender.TextInput = "";
            this.jeanTextBoxGender.TextPreview = "Пол";
            this.jeanTextBoxGender.UseSystemPasswordChar = false;
            // 
            // jeanTextBoxPhone
            // 
            this.jeanTextBoxPhone.BackColor = System.Drawing.Color.White;
            this.jeanTextBoxPhone.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBoxPhone.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBoxPhone.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBoxPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBoxPhone.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBoxPhone.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBoxPhone.Location = new System.Drawing.Point(26, 148);
            this.jeanTextBoxPhone.Name = "jeanTextBoxPhone";
            this.jeanTextBoxPhone.SelectionStart = 0;
            this.jeanTextBoxPhone.Size = new System.Drawing.Size(223, 40);
            this.jeanTextBoxPhone.TabIndex = 98;
            this.jeanTextBoxPhone.TextInput = "";
            this.jeanTextBoxPhone.TextPreview = "Телефон";
            this.jeanTextBoxPhone.UseSystemPasswordChar = false;
            // 
            // jeanTextBoxPurchase
            // 
            this.jeanTextBoxPurchase.BackColor = System.Drawing.Color.White;
            this.jeanTextBoxPurchase.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBoxPurchase.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBoxPurchase.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBoxPurchase.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBoxPurchase.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBoxPurchase.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBoxPurchase.Location = new System.Drawing.Point(26, 244);
            this.jeanTextBoxPurchase.Name = "jeanTextBoxPurchase";
            this.jeanTextBoxPurchase.SelectionStart = 0;
            this.jeanTextBoxPurchase.Size = new System.Drawing.Size(223, 40);
            this.jeanTextBoxPurchase.TabIndex = 100;
            this.jeanTextBoxPurchase.TextInput = "";
            this.jeanTextBoxPurchase.TextPreview = "Покупки";
            this.jeanTextBoxPurchase.UseSystemPasswordChar = false;
            // 
            // jeanTextBoxNumberCard
            // 
            this.jeanTextBoxNumberCard.BackColor = System.Drawing.Color.White;
            this.jeanTextBoxNumberCard.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBoxNumberCard.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBoxNumberCard.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBoxNumberCard.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBoxNumberCard.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBoxNumberCard.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBoxNumberCard.Location = new System.Drawing.Point(26, 196);
            this.jeanTextBoxNumberCard.Name = "jeanTextBoxNumberCard";
            this.jeanTextBoxNumberCard.SelectionStart = 0;
            this.jeanTextBoxNumberCard.Size = new System.Drawing.Size(223, 40);
            this.jeanTextBoxNumberCard.TabIndex = 99;
            this.jeanTextBoxNumberCard.TextInput = "";
            this.jeanTextBoxNumberCard.TextPreview = "Номер карты";
            this.jeanTextBoxNumberCard.UseSystemPasswordChar = false;
            // 
            // jeanTextBoxVisitsLeft
            // 
            this.jeanTextBoxVisitsLeft.BackColor = System.Drawing.Color.White;
            this.jeanTextBoxVisitsLeft.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBoxVisitsLeft.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBoxVisitsLeft.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBoxVisitsLeft.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBoxVisitsLeft.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBoxVisitsLeft.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBoxVisitsLeft.Location = new System.Drawing.Point(26, 436);
            this.jeanTextBoxVisitsLeft.Name = "jeanTextBoxVisitsLeft";
            this.jeanTextBoxVisitsLeft.SelectionStart = 0;
            this.jeanTextBoxVisitsLeft.Size = new System.Drawing.Size(223, 40);
            this.jeanTextBoxVisitsLeft.TabIndex = 104;
            this.jeanTextBoxVisitsLeft.TextInput = "";
            this.jeanTextBoxVisitsLeft.TextPreview = "Посещений осталось";
            this.jeanTextBoxVisitsLeft.UseSystemPasswordChar = false;
            // 
            // jeanTextBoxTerm
            // 
            this.jeanTextBoxTerm.BackColor = System.Drawing.Color.White;
            this.jeanTextBoxTerm.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBoxTerm.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBoxTerm.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBoxTerm.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBoxTerm.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBoxTerm.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBoxTerm.Location = new System.Drawing.Point(26, 388);
            this.jeanTextBoxTerm.Name = "jeanTextBoxTerm";
            this.jeanTextBoxTerm.SelectionStart = 0;
            this.jeanTextBoxTerm.Size = new System.Drawing.Size(223, 40);
            this.jeanTextBoxTerm.TabIndex = 103;
            this.jeanTextBoxTerm.TextInput = "";
            this.jeanTextBoxTerm.TextPreview = "Срок абонемента";
            this.jeanTextBoxTerm.UseSystemPasswordChar = false;
            // 
            // jeanTextBoxMembership
            // 
            this.jeanTextBoxMembership.BackColor = System.Drawing.Color.White;
            this.jeanTextBoxMembership.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBoxMembership.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBoxMembership.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBoxMembership.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBoxMembership.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBoxMembership.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBoxMembership.Location = new System.Drawing.Point(26, 340);
            this.jeanTextBoxMembership.Name = "jeanTextBoxMembership";
            this.jeanTextBoxMembership.SelectionStart = 0;
            this.jeanTextBoxMembership.Size = new System.Drawing.Size(223, 40);
            this.jeanTextBoxMembership.TabIndex = 102;
            this.jeanTextBoxMembership.TextInput = "";
            this.jeanTextBoxMembership.TextPreview = "Абонемент";
            this.jeanTextBoxMembership.UseSystemPasswordChar = false;
            // 
            // jeanTextBoxVisit
            // 
            this.jeanTextBoxVisit.BackColor = System.Drawing.Color.White;
            this.jeanTextBoxVisit.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBoxVisit.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBoxVisit.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBoxVisit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBoxVisit.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBoxVisit.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBoxVisit.Location = new System.Drawing.Point(26, 292);
            this.jeanTextBoxVisit.Name = "jeanTextBoxVisit";
            this.jeanTextBoxVisit.SelectionStart = 0;
            this.jeanTextBoxVisit.Size = new System.Drawing.Size(223, 40);
            this.jeanTextBoxVisit.TabIndex = 101;
            this.jeanTextBoxVisit.TextInput = "";
            this.jeanTextBoxVisit.TextPreview = "Посетил";
            this.jeanTextBoxVisit.UseSystemPasswordChar = false;
            // 
            // jeanTextBoxDiscount
            // 
            this.jeanTextBoxDiscount.BackColor = System.Drawing.Color.White;
            this.jeanTextBoxDiscount.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBoxDiscount.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBoxDiscount.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBoxDiscount.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBoxDiscount.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBoxDiscount.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBoxDiscount.Location = new System.Drawing.Point(26, 580);
            this.jeanTextBoxDiscount.Name = "jeanTextBoxDiscount";
            this.jeanTextBoxDiscount.SelectionStart = 0;
            this.jeanTextBoxDiscount.Size = new System.Drawing.Size(223, 40);
            this.jeanTextBoxDiscount.TabIndex = 107;
            this.jeanTextBoxDiscount.TextInput = "";
            this.jeanTextBoxDiscount.TextPreview = "Скидка";
            this.jeanTextBoxDiscount.UseSystemPasswordChar = false;
            // 
            // jeanTextBoxBirthday
            // 
            this.jeanTextBoxBirthday.BackColor = System.Drawing.Color.White;
            this.jeanTextBoxBirthday.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBoxBirthday.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBoxBirthday.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBoxBirthday.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBoxBirthday.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBoxBirthday.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBoxBirthday.Location = new System.Drawing.Point(26, 532);
            this.jeanTextBoxBirthday.Name = "jeanTextBoxBirthday";
            this.jeanTextBoxBirthday.SelectionStart = 0;
            this.jeanTextBoxBirthday.Size = new System.Drawing.Size(223, 40);
            this.jeanTextBoxBirthday.TabIndex = 106;
            this.jeanTextBoxBirthday.TextInput = "";
            this.jeanTextBoxBirthday.TextPreview = "Дата рождения";
            this.jeanTextBoxBirthday.UseSystemPasswordChar = false;
            // 
            // jeanTextBoxEmail
            // 
            this.jeanTextBoxEmail.BackColor = System.Drawing.Color.White;
            this.jeanTextBoxEmail.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBoxEmail.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBoxEmail.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBoxEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBoxEmail.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBoxEmail.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBoxEmail.Location = new System.Drawing.Point(26, 484);
            this.jeanTextBoxEmail.Name = "jeanTextBoxEmail";
            this.jeanTextBoxEmail.SelectionStart = 0;
            this.jeanTextBoxEmail.Size = new System.Drawing.Size(223, 40);
            this.jeanTextBoxEmail.TabIndex = 105;
            this.jeanTextBoxEmail.TextInput = "";
            this.jeanTextBoxEmail.TextPreview = "Email";
            this.jeanTextBoxEmail.UseSystemPasswordChar = false;
            // 
            // jeanModernButtonChange
            // 
            this.jeanModernButtonChange.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.jeanModernButtonChange.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonChange.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonChange.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButtonChange.BorderRadius = 20;
            this.jeanModernButtonChange.BorderSize = 2;
            this.jeanModernButtonChange.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonChange.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonChange.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonChange.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonChange.Location = new System.Drawing.Point(627, 634);
            this.jeanModernButtonChange.Name = "jeanModernButtonChange";
            this.jeanModernButtonChange.Size = new System.Drawing.Size(166, 55);
            this.jeanModernButtonChange.TabIndex = 108;
            this.jeanModernButtonChange.Text = "Изменить";
            this.jeanModernButtonChange.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonChange.UseVisualStyleBackColor = false;
            this.jeanModernButtonChange.Click += new System.EventHandler(this.buttonUpdate_Click);
            // 
            // jeanModernButtonDelete
            // 
            this.jeanModernButtonDelete.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.jeanModernButtonDelete.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonDelete.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonDelete.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButtonDelete.BorderRadius = 20;
            this.jeanModernButtonDelete.BorderSize = 2;
            this.jeanModernButtonDelete.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonDelete.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonDelete.Location = new System.Drawing.Point(799, 634);
            this.jeanModernButtonDelete.Name = "jeanModernButtonDelete";
            this.jeanModernButtonDelete.Size = new System.Drawing.Size(166, 55);
            this.jeanModernButtonDelete.TabIndex = 109;
            this.jeanModernButtonDelete.Text = "Удалить";
            this.jeanModernButtonDelete.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonDelete.UseVisualStyleBackColor = false;
            this.jeanModernButtonDelete.Click += new System.EventHandler(this.buttonDelete_Click);
            // 
            // dataGridViewClients
            // 
            this.dataGridViewClients.AllowUserToAddRows = false;
            this.dataGridViewClients.AllowUserToDeleteRows = false;
            this.dataGridViewClients.AllowUserToResizeColumns = false;
            this.dataGridViewClients.AllowUserToResizeRows = false;
            this.dataGridViewClients.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewClients.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewClients.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewClients.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridViewClients.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(230)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(230)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewClients.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewClients.ColumnHeadersHeight = 35;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewClients.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewClients.EnableHeadersVisualStyles = false;
            this.dataGridViewClients.GridColor = System.Drawing.Color.Black;
            this.dataGridViewClients.Location = new System.Drawing.Point(16, 9);
            this.dataGridViewClients.Name = "dataGridViewClients";
            this.dataGridViewClients.ReadOnly = true;
            this.dataGridViewClients.RowHeadersVisible = false;
            this.dataGridViewClients.RowHeadersWidth = 40;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            this.dataGridViewClients.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewClients.RowTemplate.Height = 24;
            this.dataGridViewClients.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewClients.Size = new System.Drawing.Size(931, 493);
            this.dataGridViewClients.TabIndex = 110;
            this.dataGridViewClients.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewClients_CellContentClick);
            // 
            // jeanPanel1
            // 
            this.jeanPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.jeanPanel1.BackColor = System.Drawing.Color.White;
            this.jeanPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.jeanPanel1.BorderRadius = 30;
            this.jeanPanel1.Controls.Add(this.dataGridViewClients);
            this.jeanPanel1.ForeColor = System.Drawing.Color.Black;
            this.jeanPanel1.GradientAngle = 90F;
            this.jeanPanel1.GradientBottomColor = System.Drawing.Color.DodgerBlue;
            this.jeanPanel1.GradientTapColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            this.jeanPanel1.Location = new System.Drawing.Point(301, 107);
            this.jeanPanel1.Name = "jeanPanel1";
            this.jeanPanel1.Size = new System.Drawing.Size(961, 513);
            this.jeanPanel1.TabIndex = 111;
            this.jeanPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.jeanPanel1_Paint);
            // 
            // ChangeData
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1284, 780);
            this.Controls.Add(this.jeanPanel1);
            this.Controls.Add(this.jeanModernButtonDelete);
            this.Controls.Add(this.jeanModernButtonChange);
            this.Controls.Add(this.jeanTextBoxDiscount);
            this.Controls.Add(this.jeanTextBoxBirthday);
            this.Controls.Add(this.jeanTextBoxEmail);
            this.Controls.Add(this.jeanTextBoxVisitsLeft);
            this.Controls.Add(this.jeanTextBoxTerm);
            this.Controls.Add(this.jeanTextBoxMembership);
            this.Controls.Add(this.jeanTextBoxVisit);
            this.Controls.Add(this.jeanTextBoxPurchase);
            this.Controls.Add(this.jeanTextBoxNumberCard);
            this.Controls.Add(this.jeanTextBoxPhone);
            this.Controls.Add(this.jeanTextBoxGender);
            this.Controls.Add(this.jeanTextBoxClient);
            this.Controls.Add(this.pictureBoxSearch);
            this.Controls.Add(this.jeanModernButtonErase);
            this.Controls.Add(this.jeanSoftTextBoxSearch);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ChangeData";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ChangeData";
            this.Load += new System.EventHandler(this.ChangeData_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSearch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewClients)).EndInit();
            this.jeanPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private Components.JeanFormStyle jeanFormStyle;
        private System.Windows.Forms.PictureBox pictureBoxSearch;
        private Controls.JeanModernButton jeanModernButtonErase;
        protected internal Controls.jeanSoftTextBox jeanSoftTextBoxSearch;
        private JeanTextBox jeanTextBoxVisitsLeft;
        private JeanTextBox jeanTextBoxTerm;
        private JeanTextBox jeanTextBoxMembership;
        private JeanTextBox jeanTextBoxVisit;
        private JeanTextBox jeanTextBoxPurchase;
        private JeanTextBox jeanTextBoxNumberCard;
        private JeanTextBox jeanTextBoxPhone;
        private JeanTextBox jeanTextBoxGender;
        private JeanTextBox jeanTextBoxClient;
        private JeanTextBox jeanTextBoxDiscount;
        private JeanTextBox jeanTextBoxBirthday;
        private JeanTextBox jeanTextBoxEmail;
        private Controls.JeanModernButton jeanModernButtonDelete;
        private Controls.JeanModernButton jeanModernButtonChange;
        protected internal System.Windows.Forms.DataGridView dataGridViewClients;
        private Controls.JeanPanel jeanPanel1;
    }
}