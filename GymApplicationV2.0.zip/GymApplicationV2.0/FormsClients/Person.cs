﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Shadow;

namespace GymApplicationV2._0.FormsClients
{
    public partial class Person : ShadowedForm
    {
        string path = "\\Photos\\";
        public Person()
        {
            InitializeComponent();

        }

        private void Person_Load(object sender, EventArgs e)
        {
            string pathToPhotos = Environment.CurrentDirectory;
            pictureBox.Image = Image.FromFile(FindPhoto(namePerson.Text, pathToPhotos + path));
        }

        private string FindPhoto(string clientName, string folderPath)
        {
            foreach (string filePath in Directory.EnumerateFiles(folderPath))
            {
                string fileName = Path.GetFileNameWithoutExtension(filePath);

                if (fileName.Equals(clientName, StringComparison.OrdinalIgnoreCase))
                {
                    return filePath;
                }
            }

            return Environment.CurrentDirectory + path + "Person.jpg";
        }

    }
}
