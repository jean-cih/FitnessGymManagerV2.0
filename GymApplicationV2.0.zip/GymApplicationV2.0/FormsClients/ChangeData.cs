﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using GymApplicationV2._0.Components;

namespace GymApplicationV2._0
{
    public partial class ChangeData : Form
    {
        public ChangeData()
        {
            InitializeComponent();
        }

        private void ChangeData_Load(object sender, EventArgs e)
        {
            JeanFormStyle.fStyle style = JeanFormStyle.fStyle.None;
            if (DataClass.styleForm == "UserStyle")
            {
                style = JeanFormStyle.fStyle.UserStyle;
            }
            else if (DataClass.styleForm == "SimpleDark")
            {
                style = JeanFormStyle.fStyle.SimpleDark;
            }
            else if (DataClass.styleForm == "TelegramStyle")
            {
                style = JeanFormStyle.fStyle.TelegramStyle;
            }

            jeanFormStyle.FormStyle = style;

            dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts");
            jeanModernButtonDelete.Font = new Font("Удалить", DataClass.sizeFontButtons);
            jeanModernButtonChange.Font = new Font("Изменить", DataClass.sizeFontButtons);

            dataGridViewClients.DefaultCellStyle.Font = new Font("Contacts", DataClass.sizeFontTables);
            dataGridViewClients.ColumnHeadersDefaultCellStyle.Font = new Font("Contacts", DataClass.sizeFontTables);
        }

        int key = 0;
        private void dataGridViewClients_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            key = Convert.ToInt32(dataGridViewClients.SelectedRows[0].Cells[0].Value.ToString());
            jeanTextBoxClient.Text = dataGridViewClients.SelectedRows[0].Cells[1].Value.ToString() + " " +
                dataGridViewClients.SelectedRows[0].Cells[2].Value.ToString() + " " + 
                dataGridViewClients.SelectedRows[0].Cells[11].Value.ToString();
            jeanTextBoxGender.Text = dataGridViewClients.SelectedRows[0].Cells[3].Value.ToString();
            jeanTextBoxPhone.Text = dataGridViewClients.SelectedRows[0].Cells[4].Value.ToString();
            jeanTextBoxNumberCard.Text = dataGridViewClients.SelectedRows[0].Cells[5].Value.ToString();
            jeanTextBoxPurchase.Text = dataGridViewClients.SelectedRows[0].Cells[6].Value.ToString();
            jeanTextBoxVisit.Text = dataGridViewClients.SelectedRows[0].Cells[7].Value.ToString();
            jeanTextBoxMembership.Text = dataGridViewClients.SelectedRows[0].Cells[8].Value.ToString();
            jeanTextBoxTerm.Text = dataGridViewClients.SelectedRows[0].Cells[9].Value.ToString();
            jeanTextBoxVisitsLeft.Text = dataGridViewClients.SelectedRows[0].Cells[10].Value.ToString();
            jeanTextBoxEmail.Text = dataGridViewClients.SelectedRows[0].Cells[12].Value.ToString();
            jeanTextBoxBirthday.Text = dataGridViewClients.SelectedRows[0].Cells[13].Value.ToString();
            jeanTextBoxDiscount.Text = dataGridViewClients.SelectedRows[0].Cells[14].Value.ToString();
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            string[] fullName = jeanTextBoxClient.Text.Split(' ');
            ClientsContext.CommandDataClient("UPDATE Contacts SET " +
                    "Фамилия = '" + fullName[0].Trim() + "'," +
                    "Имя = '" + fullName[1].Trim() + "'," +
                    "Пол = '" + jeanTextBoxGender.Text.Trim() + "'," +
                    "Телефон = '" + jeanTextBoxPhone.Text.Trim() + "'," +
                    "№Карты = '" + jeanTextBoxNumberCard.Text.Trim() + "'," +
                    "Покупки = '" + jeanTextBoxPurchase.Text.Trim() + "'," +
                    "Посетил = '" + jeanTextBoxVisit.Text.Trim() + "'," +
                    "Абонемент = '" + jeanTextBoxMembership.Text.Trim() + "'," +
                    "Срок_абонемента = '" + jeanTextBoxTerm.Text.Trim() + "'," +
                    "Посещений_осталось = '" + jeanTextBoxVisitsLeft.Text.Trim() + "'," +
                    "Отчество = '" + fullName[2].Trim() + "'," +
                    "Email = '" + jeanTextBoxEmail.Text.Trim() + "'," +
                    "Дата_рождения = '" + jeanTextBoxBirthday.Text.Trim() + "'," +
                    "Скидка = '" + jeanTextBoxDiscount.Text.Trim() + "' " +
                    "WHERE Id = '" + key + "';");

            Message.MessageWindowOk("Данные клиента обновлены");

            dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts");

            jeanTextBoxClient.Text = "";
            jeanTextBoxGender.Text = "";
            jeanTextBoxPhone.Text = "";
            jeanTextBoxNumberCard.Text = "";
            jeanTextBoxEmail.Text = "";
            jeanTextBoxBirthday.Text = "";
            jeanTextBoxDiscount.Text = "";
            jeanTextBoxVisitsLeft.Text = "";
            jeanTextBoxTerm.Text = "";
            jeanTextBoxMembership.Text = "";
            jeanTextBoxVisit.Text = "";
            jeanTextBoxPurchase.Text = "";
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            
            if (jeanTextBoxClient.Text == "")
            {
                Message.MessageWindowOk("Клиент не выбран");

                return;
            }
            
            DialogResult result = Message.MessageWindowYesNo("Вы действительно хотите удалить клиента?");

            if (result == DialogResult.No)
                return;

            ClientsContext.CommandDataClient("DELETE FROM Contacts Where Id = '" + key + "' ");

            Message.MessageWindowOk("Клиент удален");

            dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts");

            jeanTextBoxClient.Text = "";
            jeanTextBoxGender.Text = "";
            jeanTextBoxPhone.Text = "";
            jeanTextBoxNumberCard.Text = "";
            jeanTextBoxEmail.Text = "";
            jeanTextBoxBirthday.Text = "";
            jeanTextBoxDiscount.Text = "";
            jeanTextBoxVisitsLeft.Text = "";
            jeanTextBoxTerm.Text = "";
            jeanTextBoxMembership.Text = "";
            jeanTextBoxVisit.Text = "";
            jeanTextBoxPurchase.Text = "";
        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            jeanSoftTextBoxSearch.Texts = "";
            dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts");
        }

        private void textSearch_TextChanged(object sender, EventArgs e)
        {
            
            if (jeanSoftTextBoxSearch.Texts == "")
            {
                dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts");
                return;
            }
            
            string[] fullName = jeanSoftTextBoxSearch.Texts.Split(' ');
            fullName[0] = Char.ToUpper(fullName[0][0]) + fullName[0].Substring(1);
            try
            {
                fullName[1] = Char.ToUpper(fullName[1][0]) + fullName[1].Substring(1);

                dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase($"" +
                    $"SELECT * " +
                    $"FROM Contacts " +
                    $"WHERE №Карты LIKE '%{fullName[0]}%' " +
                    $"OR Фамилия LIKE '%{fullName[0]}%' " +
                    $"AND Имя LIKE '%{fullName[1]}%'");
            }
            catch
            {
                dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase($"" +
                    $"SELECT * " +
                    $"FROM Contacts " +
                    $"WHERE №Карты LIKE '%{fullName[0]}%' " +
                    $"OR Фамилия LIKE '%{fullName[0]}%' " +
                    $"OR Имя LIKE '%{fullName[0]}%'");
            }
        }
    }
}
