﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace GymApplicationV2._0
{
    public partial class ChangeData : Form
    {
        public ChangeData()
        {
            InitializeComponent();
        }

        private void ChangeData_Load(object sender, EventArgs e)
        {
            dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts");
            buttonDelete.Font = new Font("Удалить", DataClass.sizeFontButtons);
            buttonRefresh.Font = new Font("Обновить", DataClass.sizeFontButtons);

            dataGridViewClients.DefaultCellStyle.Font = new Font("Contacts", DataClass.sizeFontTables);
            dataGridViewClients.ColumnHeadersDefaultCellStyle.Font = new Font("Contacts", DataClass.sizeFontTables);
        }

        int key = 0;
        private void dataGridViewClients_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            key = Convert.ToInt32(dataGridViewClients.SelectedRows[0].Cells[0].Value.ToString());
            textSurname.Text = dataGridViewClients.SelectedRows[0].Cells[1].Value.ToString();
            textName.Text = dataGridViewClients.SelectedRows[0].Cells[2].Value.ToString();
            textSex.Text = dataGridViewClients.SelectedRows[0].Cells[3].Value.ToString();
            textNumber.Text = dataGridViewClients.SelectedRows[0].Cells[4].Value.ToString();
            textNumberCard.Text = dataGridViewClients.SelectedRows[0].Cells[5].Value.ToString();
            textBox3.Text = dataGridViewClients.SelectedRows[0].Cells[6].Value.ToString();
            textBox2.Text = dataGridViewClients.SelectedRows[0].Cells[7].Value.ToString();
            textBox1.Text = dataGridViewClients.SelectedRows[0].Cells[8].Value.ToString();
            textBox5.Text = dataGridViewClients.SelectedRows[0].Cells[9].Value.ToString();
            textBox4.Text = dataGridViewClients.SelectedRows[0].Cells[10].Value.ToString();
            textFather.Text = dataGridViewClients.SelectedRows[0].Cells[11].Value.ToString();
            textEmail.Text = dataGridViewClients.SelectedRows[0].Cells[12].Value.ToString();
            textBirthday.Text = dataGridViewClients.SelectedRows[0].Cells[13].Value.ToString();
            textDiscount.Text = dataGridViewClients.SelectedRows[0].Cells[14].Value.ToString();
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            ClientsContext.CommandDataClient("UPDATE Contacts SET " +
                    "Фамилия = '" + textSurname.Text.Trim() + "'," +
                    "Имя = '" + textName.Text.Trim() + "'," +
                    "Пол = '" + textSex.Text.Trim() + "'," +
                    "Телефон = '" + textNumber.Text.Trim() + "'," +
                    "№Карты = '" + textNumberCard.Text.Trim() + "'," +
                    "Покупки = '" + textBox3.Text.Trim() + "'," +
                    "Посетил = '" + textBox2.Text.Trim() + "'," +
                    "Абонемент = '" + textBox1.Text.Trim() + "'," +
                    "Срок_абонемента = '" + textBox5.Text.Trim() + "'," +
                    "Посещений_осталось = '" + textBox4.Text.Trim() + "'," +
                    "Отчество = '" + textFather.Text.Trim() + "'," +
                    "Email = '" + textEmail.Text.Trim() + "'," +
                    "Дата_рождения = '" + textBirthday.Text.Trim() + "'," +
                    "Скидка = '" + textDiscount.Text.Trim() + "' " +
                    "WHERE Id = '" + key + "';");

            Message.MessageWindowOk("Данные клиента обновлены");

            dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts");

            textSurname.Text = "";
            textName.Text = "";
            textSex.Text = "";
            textNumber.Text = "";
            textNumberCard.Text = "";
            textFather.Text = "";
            textEmail.Text = "";
            textBirthday.Text = "";
            textDiscount.Text = "";
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (textSurname.Text == "" || textName.Text == "")
            {
                Message.MessageWindowOk("Клиент не выбран");

                return;
            }

            DialogResult result = Message.MessageWindowYesNo("Вы действительно хотите удалить клиента?");

            if (result == DialogResult.No)
                return;

            ClientsContext.CommandDataClient("DELETE FROM Contacts Where Id = '" + key + "' ");

            Message.MessageWindowOk("Клиент удален");

            dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts");

            textSurname.Text = "";
            textName.Text = "";
            textSex.Text = "";
            textNumber.Text = "";
            textNumberCard.Text = "";
            textFather.Text = "";
            textEmail.Text = "";
            textBirthday.Text = "";
            textDiscount.Text = "";
        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            textSearch.Text = "";
            dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts");
        }

        private void textSearch_TextChanged(object sender, EventArgs e)
        {
            if (textSearch.Text == "")
            {
                dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts");
                return;
            }

            dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase($"" +
                $"SELECT * " +
                $"FROM Contacts " +
                $"WHERE №Карты LIKE '%{textSearch.Text}%' " +
                $"OR Фамилия LIKE '%{textSearch.Text}%' " +
                $"OR Имя LIKE '%{textSearch.Text}%'");
        }
    }
}
