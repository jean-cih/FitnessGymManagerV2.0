﻿namespace GymApplicationV2._0
{
    partial class NewClient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NewClient));
            this.dataGridViewServices = new System.Windows.Forms.DataGridView();
            this.radioButtonWoman = new System.Windows.Forms.RadioButton();
            this.radioButtonMan = new System.Windows.Forms.RadioButton();
            this.labelDiscount = new System.Windows.Forms.Label();
            this.checkBoxVisited = new System.Windows.Forms.CheckBox();
            this.jeanDateTimePickerSell = new GymApplicationV2._0.Controls.JeanDateTimePicker();
            this.jeanModernButtonAdd = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanModernButtonClients = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanTextBoxDiscount = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBoxPurchase = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBoxNumberCard = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBoxBirthday = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBoxFather = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBoxSurname = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBoxName = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBoxNumber = new GymApplicationV2._0.JeanTextBox();
            this.jeanFormStyle = new GymApplicationV2._0.Components.JeanFormStyle(this.components);
            this.jeanPanel = new GymApplicationV2._0.Controls.JeanPanel();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewServices)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewServices
            // 
            this.dataGridViewServices.AllowUserToAddRows = false;
            this.dataGridViewServices.AllowUserToDeleteRows = false;
            this.dataGridViewServices.AllowUserToResizeColumns = false;
            this.dataGridViewServices.AllowUserToResizeRows = false;
            this.dataGridViewServices.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewServices.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewServices.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewServices.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewServices.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridViewServices.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(230)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(230)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewServices.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewServices.ColumnHeadersHeight = 25;
            this.dataGridViewServices.EnableHeadersVisualStyles = false;
            this.dataGridViewServices.GridColor = System.Drawing.Color.Black;
            this.dataGridViewServices.Location = new System.Drawing.Point(429, 146);
            this.dataGridViewServices.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridViewServices.Name = "dataGridViewServices";
            this.dataGridViewServices.ReadOnly = true;
            this.dataGridViewServices.RowHeadersVisible = false;
            this.dataGridViewServices.RowHeadersWidth = 40;
            this.dataGridViewServices.RowTemplate.Height = 24;
            this.dataGridViewServices.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewServices.Size = new System.Drawing.Size(647, 270);
            this.dataGridViewServices.TabIndex = 23;
            this.dataGridViewServices.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewServices_CellContentClick);
            // 
            // radioButtonWoman
            // 
            this.radioButtonWoman.AutoSize = true;
            this.radioButtonWoman.Location = new System.Drawing.Point(107, 347);
            this.radioButtonWoman.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButtonWoman.Name = "radioButtonWoman";
            this.radioButtonWoman.Size = new System.Drawing.Size(53, 20);
            this.radioButtonWoman.TabIndex = 30;
            this.radioButtonWoman.Text = "жен";
            this.radioButtonWoman.UseVisualStyleBackColor = true;
            // 
            // radioButtonMan
            // 
            this.radioButtonMan.AutoSize = true;
            this.radioButtonMan.Location = new System.Drawing.Point(45, 347);
            this.radioButtonMan.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButtonMan.Name = "radioButtonMan";
            this.radioButtonMan.Size = new System.Drawing.Size(54, 20);
            this.radioButtonMan.TabIndex = 29;
            this.radioButtonMan.Text = "муж";
            this.radioButtonMan.UseVisualStyleBackColor = true;
            // 
            // labelDiscount
            // 
            this.labelDiscount.AutoSize = true;
            this.labelDiscount.Location = new System.Drawing.Point(835, 39);
            this.labelDiscount.Name = "labelDiscount";
            this.labelDiscount.Size = new System.Drawing.Size(173, 16);
            this.labelDiscount.TabIndex = 34;
            this.labelDiscount.Text = "Персональная скидка (%)";
            // 
            // checkBoxVisited
            // 
            this.checkBoxVisited.AutoSize = true;
            this.checkBoxVisited.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBoxVisited.Location = new System.Drawing.Point(93, 448);
            this.checkBoxVisited.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkBoxVisited.Name = "checkBoxVisited";
            this.checkBoxVisited.Size = new System.Drawing.Size(209, 20);
            this.checkBoxVisited.TabIndex = 36;
            this.checkBoxVisited.Text = "Отметить посещение сразу";
            this.checkBoxVisited.UseVisualStyleBackColor = true;
            // 
            // jeanDateTimePickerSell
            // 
            this.jeanDateTimePickerSell.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.jeanDateTimePickerSell.BorderSize = 0;
            this.jeanDateTimePickerSell.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F);
            this.jeanDateTimePickerSell.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.jeanDateTimePickerSell.Location = new System.Drawing.Point(693, 433);
            this.jeanDateTimePickerSell.MinimumSize = new System.Drawing.Size(4, 35);
            this.jeanDateTimePickerSell.Name = "jeanDateTimePickerSell";
            this.jeanDateTimePickerSell.Size = new System.Drawing.Size(146, 35);
            this.jeanDateTimePickerSell.SkinColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanDateTimePickerSell.TabIndex = 55;
            this.jeanDateTimePickerSell.TextColor = System.Drawing.Color.White;
            // 
            // jeanModernButtonAdd
            // 
            this.jeanModernButtonAdd.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.jeanModernButtonAdd.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonAdd.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonAdd.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButtonAdd.BorderRadius = 20;
            this.jeanModernButtonAdd.BorderSize = 2;
            this.jeanModernButtonAdd.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonAdd.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonAdd.Location = new System.Drawing.Point(406, 504);
            this.jeanModernButtonAdd.Name = "jeanModernButtonAdd";
            this.jeanModernButtonAdd.Size = new System.Drawing.Size(150, 55);
            this.jeanModernButtonAdd.TabIndex = 54;
            this.jeanModernButtonAdd.Text = "Добавить";
            this.jeanModernButtonAdd.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonAdd.UseVisualStyleBackColor = false;
            this.jeanModernButtonAdd.Click += new System.EventHandler(this.buttonSave_Click);
            // 
            // jeanModernButtonClients
            // 
            this.jeanModernButtonClients.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.jeanModernButtonClients.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonClients.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonClients.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButtonClients.BorderRadius = 20;
            this.jeanModernButtonClients.BorderSize = 2;
            this.jeanModernButtonClients.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonClients.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonClients.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonClients.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonClients.Location = new System.Drawing.Point(562, 504);
            this.jeanModernButtonClients.Name = "jeanModernButtonClients";
            this.jeanModernButtonClients.Size = new System.Drawing.Size(150, 55);
            this.jeanModernButtonClients.TabIndex = 53;
            this.jeanModernButtonClients.Text = "Клиенты";
            this.jeanModernButtonClients.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonClients.UseVisualStyleBackColor = false;
            this.jeanModernButtonClients.Click += new System.EventHandler(this.buttonClients_Click);
            // 
            // jeanTextBoxDiscount
            // 
            this.jeanTextBoxDiscount.BackColor = System.Drawing.Color.White;
            this.jeanTextBoxDiscount.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBoxDiscount.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBoxDiscount.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBoxDiscount.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBoxDiscount.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBoxDiscount.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBoxDiscount.Location = new System.Drawing.Point(1021, 32);
            this.jeanTextBoxDiscount.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.jeanTextBoxDiscount.Name = "jeanTextBoxDiscount";
            this.jeanTextBoxDiscount.SelectionStart = 0;
            this.jeanTextBoxDiscount.Size = new System.Drawing.Size(66, 30);
            this.jeanTextBoxDiscount.TabIndex = 44;
            this.jeanTextBoxDiscount.TextInput = "";
            this.jeanTextBoxDiscount.TextPreview = "";
            this.jeanTextBoxDiscount.UseSystemPasswordChar = false;
            // 
            // jeanTextBoxPurchase
            // 
            this.jeanTextBoxPurchase.BackColor = System.Drawing.Color.White;
            this.jeanTextBoxPurchase.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBoxPurchase.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBoxPurchase.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBoxPurchase.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBoxPurchase.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBoxPurchase.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBoxPurchase.Location = new System.Drawing.Point(621, 94);
            this.jeanTextBoxPurchase.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.jeanTextBoxPurchase.Name = "jeanTextBoxPurchase";
            this.jeanTextBoxPurchase.SelectionStart = 0;
            this.jeanTextBoxPurchase.Size = new System.Drawing.Size(255, 39);
            this.jeanTextBoxPurchase.TabIndex = 43;
            this.jeanTextBoxPurchase.TextInput = "";
            this.jeanTextBoxPurchase.TextPreview = "Услуга";
            this.jeanTextBoxPurchase.UseSystemPasswordChar = false;
            // 
            // jeanTextBoxNumberCard
            // 
            this.jeanTextBoxNumberCard.BackColor = System.Drawing.Color.White;
            this.jeanTextBoxNumberCard.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBoxNumberCard.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBoxNumberCard.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBoxNumberCard.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBoxNumberCard.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBoxNumberCard.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBoxNumberCard.Location = new System.Drawing.Point(45, 401);
            this.jeanTextBoxNumberCard.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.jeanTextBoxNumberCard.Name = "jeanTextBoxNumberCard";
            this.jeanTextBoxNumberCard.SelectionStart = 0;
            this.jeanTextBoxNumberCard.Size = new System.Drawing.Size(300, 39);
            this.jeanTextBoxNumberCard.TabIndex = 42;
            this.jeanTextBoxNumberCard.TextInput = "";
            this.jeanTextBoxNumberCard.TextPreview = "Номер карты";
            this.jeanTextBoxNumberCard.UseSystemPasswordChar = false;
            // 
            // jeanTextBoxBirthday
            // 
            this.jeanTextBoxBirthday.BackColor = System.Drawing.Color.White;
            this.jeanTextBoxBirthday.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBoxBirthday.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBoxBirthday.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBoxBirthday.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBoxBirthday.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBoxBirthday.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBoxBirthday.Location = new System.Drawing.Point(172, 332);
            this.jeanTextBoxBirthday.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.jeanTextBoxBirthday.Name = "jeanTextBoxBirthday";
            this.jeanTextBoxBirthday.SelectionStart = 0;
            this.jeanTextBoxBirthday.Size = new System.Drawing.Size(173, 39);
            this.jeanTextBoxBirthday.TabIndex = 41;
            this.jeanTextBoxBirthday.TextInput = "";
            this.jeanTextBoxBirthday.TextPreview = "День рождения";
            this.jeanTextBoxBirthday.UseSystemPasswordChar = false;
            // 
            // jeanTextBoxFather
            // 
            this.jeanTextBoxFather.BackColor = System.Drawing.Color.White;
            this.jeanTextBoxFather.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBoxFather.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBoxFather.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBoxFather.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBoxFather.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBoxFather.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBoxFather.Location = new System.Drawing.Point(45, 263);
            this.jeanTextBoxFather.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.jeanTextBoxFather.Name = "jeanTextBoxFather";
            this.jeanTextBoxFather.SelectionStart = 0;
            this.jeanTextBoxFather.Size = new System.Drawing.Size(300, 39);
            this.jeanTextBoxFather.TabIndex = 40;
            this.jeanTextBoxFather.TextInput = "";
            this.jeanTextBoxFather.TextPreview = "Отчество";
            this.jeanTextBoxFather.UseSystemPasswordChar = false;
            // 
            // jeanTextBoxSurname
            // 
            this.jeanTextBoxSurname.BackColor = System.Drawing.Color.White;
            this.jeanTextBoxSurname.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBoxSurname.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBoxSurname.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBoxSurname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBoxSurname.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBoxSurname.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBoxSurname.Location = new System.Drawing.Point(45, 192);
            this.jeanTextBoxSurname.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.jeanTextBoxSurname.Name = "jeanTextBoxSurname";
            this.jeanTextBoxSurname.SelectionStart = 0;
            this.jeanTextBoxSurname.Size = new System.Drawing.Size(300, 39);
            this.jeanTextBoxSurname.TabIndex = 39;
            this.jeanTextBoxSurname.TextInput = "";
            this.jeanTextBoxSurname.TextPreview = "Фамилия";
            this.jeanTextBoxSurname.UseSystemPasswordChar = false;
            // 
            // jeanTextBoxName
            // 
            this.jeanTextBoxName.BackColor = System.Drawing.Color.White;
            this.jeanTextBoxName.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBoxName.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBoxName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBoxName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBoxName.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBoxName.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBoxName.Location = new System.Drawing.Point(45, 118);
            this.jeanTextBoxName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.jeanTextBoxName.Name = "jeanTextBoxName";
            this.jeanTextBoxName.SelectionStart = 0;
            this.jeanTextBoxName.Size = new System.Drawing.Size(300, 39);
            this.jeanTextBoxName.TabIndex = 38;
            this.jeanTextBoxName.TextInput = "";
            this.jeanTextBoxName.TextPreview = "Имя";
            this.jeanTextBoxName.UseSystemPasswordChar = false;
            // 
            // jeanTextBoxNumber
            // 
            this.jeanTextBoxNumber.BackColor = System.Drawing.Color.White;
            this.jeanTextBoxNumber.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBoxNumber.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBoxNumber.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBoxNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBoxNumber.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBoxNumber.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBoxNumber.Location = new System.Drawing.Point(45, 49);
            this.jeanTextBoxNumber.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.jeanTextBoxNumber.Name = "jeanTextBoxNumber";
            this.jeanTextBoxNumber.SelectionStart = 0;
            this.jeanTextBoxNumber.Size = new System.Drawing.Size(192, 39);
            this.jeanTextBoxNumber.TabIndex = 37;
            this.jeanTextBoxNumber.TextInput = "";
            this.jeanTextBoxNumber.TextPreview = "Телефон";
            this.jeanTextBoxNumber.UseSystemPasswordChar = false;
            // 
            // jeanFormStyle
            // 
            this.jeanFormStyle.AllowUserResize = false;
            this.jeanFormStyle.BackColor = System.Drawing.Color.White;
            this.jeanFormStyle.ContextMenuForm = null;
            this.jeanFormStyle.ControlBoxButtonsWidth = 20;
            this.jeanFormStyle.EnableControlBoxIconsLight = false;
            this.jeanFormStyle.EnableControlBoxMouseLight = false;
            this.jeanFormStyle.Form = this;
            this.jeanFormStyle.FormStyle = GymApplicationV2._0.Components.JeanFormStyle.fStyle.None;
            this.jeanFormStyle.HeaderColor = System.Drawing.Color.Black;
            this.jeanFormStyle.HeaderColorAdditional = System.Drawing.Color.DarkOrange;
            this.jeanFormStyle.HeaderColorGradientEnable = true;
            this.jeanFormStyle.HeaderColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.jeanFormStyle.HeaderHeight = 30;
            this.jeanFormStyle.HeaderImage = null;
            this.jeanFormStyle.HeaderTextColor = System.Drawing.Color.White;
            this.jeanFormStyle.HeaderTextFont = new System.Drawing.Font("Segoe UI", 9.75F);
            // 
            // jeanPanel
            // 
            this.jeanPanel.BackColor = System.Drawing.Color.White;
            this.jeanPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.jeanPanel.BorderRadius = 30;
            this.jeanPanel.ForeColor = System.Drawing.Color.Black;
            this.jeanPanel.GradientAngle = 90F;
            this.jeanPanel.GradientBottomColor = System.Drawing.Color.DodgerBlue;
            this.jeanPanel.GradientTapColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            this.jeanPanel.Location = new System.Drawing.Point(406, 138);
            this.jeanPanel.Name = "jeanPanel";
            this.jeanPanel.Size = new System.Drawing.Size(692, 289);
            this.jeanPanel.TabIndex = 56;
            // 
            // NewClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1131, 647);
            this.Controls.Add(this.dataGridViewServices);
            this.Controls.Add(this.jeanPanel);
            this.Controls.Add(this.jeanDateTimePickerSell);
            this.Controls.Add(this.jeanModernButtonAdd);
            this.Controls.Add(this.jeanModernButtonClients);
            this.Controls.Add(this.jeanTextBoxDiscount);
            this.Controls.Add(this.jeanTextBoxPurchase);
            this.Controls.Add(this.jeanTextBoxNumberCard);
            this.Controls.Add(this.jeanTextBoxBirthday);
            this.Controls.Add(this.jeanTextBoxFather);
            this.Controls.Add(this.jeanTextBoxSurname);
            this.Controls.Add(this.jeanTextBoxName);
            this.Controls.Add(this.jeanTextBoxNumber);
            this.Controls.Add(this.checkBoxVisited);
            this.Controls.Add(this.labelDiscount);
            this.Controls.Add(this.radioButtonWoman);
            this.Controls.Add(this.radioButtonMan);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "NewClient";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Новый Клиент";
            this.Load += new System.EventHandler(this.NewClient_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewServices)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dataGridViewServices;
        private System.Windows.Forms.RadioButton radioButtonWoman;
        private System.Windows.Forms.RadioButton radioButtonMan;
        private System.Windows.Forms.Label labelDiscount;
        private System.Windows.Forms.CheckBox checkBoxVisited;
        private JeanTextBox jeanTextBoxNumber;
        private JeanTextBox jeanTextBoxName;
        private JeanTextBox jeanTextBoxSurname;
        private JeanTextBox jeanTextBoxFather;
        private JeanTextBox jeanTextBoxBirthday;
        private JeanTextBox jeanTextBoxNumberCard;
        private JeanTextBox jeanTextBoxPurchase;
        private JeanTextBox jeanTextBoxDiscount;
        protected internal Controls.JeanModernButton jeanModernButtonClients;
        protected internal Controls.JeanModernButton jeanModernButtonAdd;
        private Components.JeanFormStyle jeanFormStyle;
        private Controls.JeanDateTimePicker jeanDateTimePickerSell;
        private Controls.JeanPanel jeanPanel;
    }
}