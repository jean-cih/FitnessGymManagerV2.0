﻿namespace GymApplicationV2._0
{
    partial class NewClient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NewClient));
            this.radioButtonWoman = new System.Windows.Forms.RadioButton();
            this.radioButtonMan = new System.Windows.Forms.RadioButton();
            this.checkBoxVisited = new System.Windows.Forms.CheckBox();
            this.jeanDateTimePickerSell = new GymApplicationV2._0.Controls.JeanDateTimePicker();
            this.jeanModernButtonAdd = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanTextBoxPurchase = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBoxNumberCard = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBoxBirthday = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBoxFather = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBoxSurname = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBoxName = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBoxNumber = new GymApplicationV2._0.JeanTextBox();
            this.jeanFormStyle = new GymApplicationV2._0.Components.JeanFormStyle(this.components);
            this.jeanPanel = new GymApplicationV2._0.Controls.JeanPanel();
            this.dataGridViewServices = new System.Windows.Forms.DataGridView();
            this.jeanTextBoxDiscount = new GymApplicationV2._0.JeanTextBox();
            this.jeanModernButtonMoreDate = new GymApplicationV2._0.Controls.JeanModernButton();
            this.dataGridViewMoreDate = new System.Windows.Forms.DataGridView();
            this.panelMoreData = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.jeanTextBox12 = new GymApplicationV2._0.JeanTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.jeanTextBox10 = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBox11 = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBox9 = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBox8 = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBox7 = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBox6 = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBox5 = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBox4 = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBox3 = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBox2 = new GymApplicationV2._0.JeanTextBox();
            this.jeanTextBox1 = new GymApplicationV2._0.JeanTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewServices)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMoreDate)).BeginInit();
            this.panelMoreData.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // radioButtonWoman
            // 
            this.radioButtonWoman.AutoSize = true;
            this.radioButtonWoman.Location = new System.Drawing.Point(107, 347);
            this.radioButtonWoman.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButtonWoman.Name = "radioButtonWoman";
            this.radioButtonWoman.Size = new System.Drawing.Size(53, 20);
            this.radioButtonWoman.TabIndex = 30;
            this.radioButtonWoman.Text = "жен";
            this.radioButtonWoman.UseVisualStyleBackColor = true;
            // 
            // radioButtonMan
            // 
            this.radioButtonMan.AutoSize = true;
            this.radioButtonMan.Location = new System.Drawing.Point(45, 347);
            this.radioButtonMan.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButtonMan.Name = "radioButtonMan";
            this.radioButtonMan.Size = new System.Drawing.Size(54, 20);
            this.radioButtonMan.TabIndex = 29;
            this.radioButtonMan.Text = "муж";
            this.radioButtonMan.UseVisualStyleBackColor = true;
            // 
            // checkBoxVisited
            // 
            this.checkBoxVisited.AutoSize = true;
            this.checkBoxVisited.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBoxVisited.Location = new System.Drawing.Point(93, 448);
            this.checkBoxVisited.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkBoxVisited.Name = "checkBoxVisited";
            this.checkBoxVisited.Size = new System.Drawing.Size(209, 20);
            this.checkBoxVisited.TabIndex = 36;
            this.checkBoxVisited.Text = "Отметить посещение сразу";
            this.checkBoxVisited.UseVisualStyleBackColor = true;
            // 
            // jeanDateTimePickerSell
            // 
            this.jeanDateTimePickerSell.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.jeanDateTimePickerSell.BorderSize = 0;
            this.jeanDateTimePickerSell.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F);
            this.jeanDateTimePickerSell.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.jeanDateTimePickerSell.Location = new System.Drawing.Point(691, 405);
            this.jeanDateTimePickerSell.MinimumSize = new System.Drawing.Size(4, 35);
            this.jeanDateTimePickerSell.Name = "jeanDateTimePickerSell";
            this.jeanDateTimePickerSell.Size = new System.Drawing.Size(146, 35);
            this.jeanDateTimePickerSell.SkinColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanDateTimePickerSell.TabIndex = 55;
            this.jeanDateTimePickerSell.TextColor = System.Drawing.Color.White;
            // 
            // jeanModernButtonAdd
            // 
            this.jeanModernButtonAdd.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.jeanModernButtonAdd.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonAdd.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonAdd.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButtonAdd.BorderRadius = 20;
            this.jeanModernButtonAdd.BorderSize = 2;
            this.jeanModernButtonAdd.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonAdd.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonAdd.Location = new System.Drawing.Point(504, 502);
            this.jeanModernButtonAdd.Name = "jeanModernButtonAdd";
            this.jeanModernButtonAdd.Size = new System.Drawing.Size(150, 55);
            this.jeanModernButtonAdd.TabIndex = 54;
            this.jeanModernButtonAdd.Text = "Добавить";
            this.jeanModernButtonAdd.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonAdd.UseVisualStyleBackColor = false;
            this.jeanModernButtonAdd.Click += new System.EventHandler(this.buttonSave_Click);
            // 
            // jeanTextBoxPurchase
            // 
            this.jeanTextBoxPurchase.BackColor = System.Drawing.Color.White;
            this.jeanTextBoxPurchase.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBoxPurchase.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBoxPurchase.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBoxPurchase.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBoxPurchase.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBoxPurchase.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBoxPurchase.Location = new System.Drawing.Point(615, 62);
            this.jeanTextBoxPurchase.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.jeanTextBoxPurchase.Name = "jeanTextBoxPurchase";
            this.jeanTextBoxPurchase.SelectionStart = 0;
            this.jeanTextBoxPurchase.Size = new System.Drawing.Size(255, 39);
            this.jeanTextBoxPurchase.TabIndex = 43;
            this.jeanTextBoxPurchase.TextInput = "";
            this.jeanTextBoxPurchase.TextPreview = "Услуга";
            this.jeanTextBoxPurchase.UseSystemPasswordChar = false;
            this.jeanTextBoxPurchase.TextChanged += new System.EventHandler(this.jeanTextBoxPurchase_TextChanged);
            // 
            // jeanTextBoxNumberCard
            // 
            this.jeanTextBoxNumberCard.BackColor = System.Drawing.Color.White;
            this.jeanTextBoxNumberCard.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBoxNumberCard.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBoxNumberCard.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBoxNumberCard.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBoxNumberCard.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBoxNumberCard.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBoxNumberCard.Location = new System.Drawing.Point(45, 401);
            this.jeanTextBoxNumberCard.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.jeanTextBoxNumberCard.Name = "jeanTextBoxNumberCard";
            this.jeanTextBoxNumberCard.SelectionStart = 0;
            this.jeanTextBoxNumberCard.Size = new System.Drawing.Size(300, 39);
            this.jeanTextBoxNumberCard.TabIndex = 42;
            this.jeanTextBoxNumberCard.TextInput = "";
            this.jeanTextBoxNumberCard.TextPreview = "Номер карты";
            this.jeanTextBoxNumberCard.UseSystemPasswordChar = false;
            this.jeanTextBoxNumberCard.TextChanged += new System.EventHandler(this.jeanTextBoxNumberCard_TextChanged);
            // 
            // jeanTextBoxBirthday
            // 
            this.jeanTextBoxBirthday.BackColor = System.Drawing.Color.White;
            this.jeanTextBoxBirthday.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBoxBirthday.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBoxBirthday.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBoxBirthday.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBoxBirthday.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBoxBirthday.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBoxBirthday.Location = new System.Drawing.Point(172, 332);
            this.jeanTextBoxBirthday.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.jeanTextBoxBirthday.Name = "jeanTextBoxBirthday";
            this.jeanTextBoxBirthday.SelectionStart = 0;
            this.jeanTextBoxBirthday.Size = new System.Drawing.Size(173, 39);
            this.jeanTextBoxBirthday.TabIndex = 41;
            this.jeanTextBoxBirthday.TextInput = "";
            this.jeanTextBoxBirthday.TextPreview = "День рождения";
            this.jeanTextBoxBirthday.UseSystemPasswordChar = false;
            this.jeanTextBoxBirthday.TextChanged += new System.EventHandler(this.jeanTextBoxBirthday_TextChanged);
            this.jeanTextBoxBirthday.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.jeanTextBoxBirthday_KeyPress);
            this.jeanTextBoxBirthday.KeyDown += new System.Windows.Forms.KeyEventHandler(this.jeanTextBoxBirthday_KeyDown);
            // 
            // jeanTextBoxFather
            // 
            this.jeanTextBoxFather.BackColor = System.Drawing.Color.White;
            this.jeanTextBoxFather.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBoxFather.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBoxFather.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBoxFather.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBoxFather.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBoxFather.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBoxFather.Location = new System.Drawing.Point(45, 263);
            this.jeanTextBoxFather.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.jeanTextBoxFather.Name = "jeanTextBoxFather";
            this.jeanTextBoxFather.SelectionStart = 0;
            this.jeanTextBoxFather.Size = new System.Drawing.Size(300, 39);
            this.jeanTextBoxFather.TabIndex = 40;
            this.jeanTextBoxFather.TextInput = "";
            this.jeanTextBoxFather.TextPreview = "Отчество";
            this.jeanTextBoxFather.UseSystemPasswordChar = false;
            this.jeanTextBoxFather.TextChanged += new System.EventHandler(this.jeanTextBoxFather_TextChanged);
            // 
            // jeanTextBoxSurname
            // 
            this.jeanTextBoxSurname.BackColor = System.Drawing.Color.White;
            this.jeanTextBoxSurname.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBoxSurname.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBoxSurname.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBoxSurname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBoxSurname.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBoxSurname.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBoxSurname.Location = new System.Drawing.Point(45, 192);
            this.jeanTextBoxSurname.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.jeanTextBoxSurname.Name = "jeanTextBoxSurname";
            this.jeanTextBoxSurname.SelectionStart = 0;
            this.jeanTextBoxSurname.Size = new System.Drawing.Size(300, 39);
            this.jeanTextBoxSurname.TabIndex = 39;
            this.jeanTextBoxSurname.TextInput = "";
            this.jeanTextBoxSurname.TextPreview = "Фамилия";
            this.jeanTextBoxSurname.UseSystemPasswordChar = false;
            this.jeanTextBoxSurname.TextChanged += new System.EventHandler(this.jeanTextBoxSurname_TextChanged);
            // 
            // jeanTextBoxName
            // 
            this.jeanTextBoxName.BackColor = System.Drawing.Color.White;
            this.jeanTextBoxName.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBoxName.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBoxName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBoxName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBoxName.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBoxName.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBoxName.Location = new System.Drawing.Point(45, 118);
            this.jeanTextBoxName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.jeanTextBoxName.Name = "jeanTextBoxName";
            this.jeanTextBoxName.SelectionStart = 0;
            this.jeanTextBoxName.Size = new System.Drawing.Size(300, 39);
            this.jeanTextBoxName.TabIndex = 38;
            this.jeanTextBoxName.TextInput = "";
            this.jeanTextBoxName.TextPreview = "Имя";
            this.jeanTextBoxName.UseSystemPasswordChar = false;
            this.jeanTextBoxName.TextChanged += new System.EventHandler(this.jeanTextBoxName_TextChanged);
            // 
            // jeanTextBoxNumber
            // 
            this.jeanTextBoxNumber.BackColor = System.Drawing.Color.White;
            this.jeanTextBoxNumber.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBoxNumber.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBoxNumber.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBoxNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBoxNumber.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBoxNumber.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBoxNumber.Location = new System.Drawing.Point(45, 49);
            this.jeanTextBoxNumber.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.jeanTextBoxNumber.Name = "jeanTextBoxNumber";
            this.jeanTextBoxNumber.SelectionStart = 0;
            this.jeanTextBoxNumber.Size = new System.Drawing.Size(192, 39);
            this.jeanTextBoxNumber.TabIndex = 37;
            this.jeanTextBoxNumber.TextInput = "";
            this.jeanTextBoxNumber.TextPreview = "Телефон";
            this.jeanTextBoxNumber.UseSystemPasswordChar = false;
            this.jeanTextBoxNumber.TextChanged += new System.EventHandler(this.jeanTextBoxNumber_TextChanged);
            this.jeanTextBoxNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.jeanTextBoxNumber_KeyPress);
            this.jeanTextBoxNumber.Click += new System.EventHandler(this.jeanTextBoxNumber_Click);
            // 
            // jeanFormStyle
            // 
            this.jeanFormStyle.AllowUserResize = false;
            this.jeanFormStyle.BackColor = System.Drawing.Color.White;
            this.jeanFormStyle.ContextMenuForm = null;
            this.jeanFormStyle.ControlBoxButtonsWidth = 20;
            this.jeanFormStyle.EnableControlBoxIconsLight = false;
            this.jeanFormStyle.EnableControlBoxMouseLight = false;
            this.jeanFormStyle.Form = this;
            this.jeanFormStyle.FormStyle = GymApplicationV2._0.Components.JeanFormStyle.fStyle.None;
            this.jeanFormStyle.HeaderColor = System.Drawing.Color.Black;
            this.jeanFormStyle.HeaderColorAdditional = System.Drawing.Color.DarkOrange;
            this.jeanFormStyle.HeaderColorGradientEnable = true;
            this.jeanFormStyle.HeaderColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.jeanFormStyle.HeaderHeight = 30;
            this.jeanFormStyle.HeaderImage = null;
            this.jeanFormStyle.HeaderTextColor = System.Drawing.Color.White;
            this.jeanFormStyle.HeaderTextFont = new System.Drawing.Font("Segoe UI", 9.75F);
            // 
            // jeanPanel
            // 
            this.jeanPanel.BackColor = System.Drawing.Color.White;
            this.jeanPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.jeanPanel.BorderRadius = 30;
            this.jeanPanel.ForeColor = System.Drawing.Color.Black;
            this.jeanPanel.GradientAngle = 90F;
            this.jeanPanel.GradientBottomColor = System.Drawing.Color.DodgerBlue;
            this.jeanPanel.GradientTapColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            this.jeanPanel.Location = new System.Drawing.Point(400, 106);
            this.jeanPanel.Name = "jeanPanel";
            this.jeanPanel.Size = new System.Drawing.Size(692, 289);
            this.jeanPanel.TabIndex = 56;
            // 
            // dataGridViewServices
            // 
            this.dataGridViewServices.AllowUserToAddRows = false;
            this.dataGridViewServices.AllowUserToDeleteRows = false;
            this.dataGridViewServices.AllowUserToResizeColumns = false;
            this.dataGridViewServices.AllowUserToResizeRows = false;
            this.dataGridViewServices.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewServices.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewServices.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewServices.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewServices.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridViewServices.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(230)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(230)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewServices.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewServices.ColumnHeadersHeight = 25;
            this.dataGridViewServices.EnableHeadersVisualStyles = false;
            this.dataGridViewServices.GridColor = System.Drawing.Color.Black;
            this.dataGridViewServices.Location = new System.Drawing.Point(423, 114);
            this.dataGridViewServices.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridViewServices.Name = "dataGridViewServices";
            this.dataGridViewServices.ReadOnly = true;
            this.dataGridViewServices.RowHeadersVisible = false;
            this.dataGridViewServices.RowHeadersWidth = 40;
            this.dataGridViewServices.RowTemplate.Height = 24;
            this.dataGridViewServices.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewServices.Size = new System.Drawing.Size(647, 270);
            this.dataGridViewServices.TabIndex = 23;
            this.dataGridViewServices.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewServices_CellContentClick);
            // 
            // jeanTextBoxDiscount
            // 
            this.jeanTextBoxDiscount.BackColor = System.Drawing.Color.White;
            this.jeanTextBoxDiscount.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBoxDiscount.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBoxDiscount.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBoxDiscount.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F);
            this.jeanTextBoxDiscount.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBoxDiscount.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBoxDiscount.Location = new System.Drawing.Point(963, 400);
            this.jeanTextBoxDiscount.Name = "jeanTextBoxDiscount";
            this.jeanTextBoxDiscount.SelectionStart = 0;
            this.jeanTextBoxDiscount.Size = new System.Drawing.Size(129, 40);
            this.jeanTextBoxDiscount.TabIndex = 57;
            this.jeanTextBoxDiscount.TextInput = "";
            this.jeanTextBoxDiscount.TextPreview = "Скидка (%)";
            this.jeanTextBoxDiscount.UseSystemPasswordChar = false;
            this.jeanTextBoxDiscount.TextChanged += new System.EventHandler(this.jeanTextBoxDiscount_TextChanged);
            // 
            // jeanModernButtonMoreDate
            // 
            this.jeanModernButtonMoreDate.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonMoreDate.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonMoreDate.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButtonMoreDate.BorderRadius = 20;
            this.jeanModernButtonMoreDate.BorderSize = 2;
            this.jeanModernButtonMoreDate.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonMoreDate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonMoreDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonMoreDate.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonMoreDate.Location = new System.Drawing.Point(969, 2);
            this.jeanModernButtonMoreDate.Name = "jeanModernButtonMoreDate";
            this.jeanModernButtonMoreDate.Size = new System.Drawing.Size(150, 40);
            this.jeanModernButtonMoreDate.TabIndex = 58;
            this.jeanModernButtonMoreDate.Text = "Др. данные";
            this.jeanModernButtonMoreDate.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonMoreDate.UseVisualStyleBackColor = false;
            this.jeanModernButtonMoreDate.Click += new System.EventHandler(this.jeanModernButtonMoreDate_Click);
            // 
            // dataGridViewMoreDate
            // 
            this.dataGridViewMoreDate.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewMoreDate.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewMoreDate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewMoreDate.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewMoreDate.Name = "dataGridViewMoreDate";
            this.dataGridViewMoreDate.RowHeadersWidth = 51;
            this.dataGridViewMoreDate.RowTemplate.Height = 24;
            this.dataGridViewMoreDate.Size = new System.Drawing.Size(736, 392);
            this.dataGridViewMoreDate.TabIndex = 0;
            // 
            // panelMoreData
            // 
            this.panelMoreData.Controls.Add(this.panel1);
            this.panelMoreData.Controls.Add(this.jeanTextBox11);
            this.panelMoreData.Controls.Add(this.jeanTextBox9);
            this.panelMoreData.Controls.Add(this.jeanTextBox8);
            this.panelMoreData.Controls.Add(this.jeanTextBox7);
            this.panelMoreData.Controls.Add(this.jeanTextBox6);
            this.panelMoreData.Controls.Add(this.jeanTextBox5);
            this.panelMoreData.Controls.Add(this.jeanTextBox4);
            this.panelMoreData.Controls.Add(this.jeanTextBox3);
            this.panelMoreData.Controls.Add(this.jeanTextBox2);
            this.panelMoreData.Controls.Add(this.jeanTextBox1);
            this.panelMoreData.Controls.Add(this.dataGridViewMoreDate);
            this.panelMoreData.Location = new System.Drawing.Point(383, 62);
            this.panelMoreData.Name = "panelMoreData";
            this.panelMoreData.Size = new System.Drawing.Size(736, 392);
            this.panelMoreData.TabIndex = 59;
            this.panelMoreData.Visible = false;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.jeanTextBox12);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.jeanTextBox10);
            this.panel1.Location = new System.Drawing.Point(38, 27);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(414, 190);
            this.panel1.TabIndex = 50;
            // 
            // jeanTextBox12
            // 
            this.jeanTextBox12.BackColor = System.Drawing.Color.White;
            this.jeanTextBox12.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBox12.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBox12.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBox12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBox12.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBox12.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBox12.Location = new System.Drawing.Point(22, 111);
            this.jeanTextBox12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.jeanTextBox12.Name = "jeanTextBox12";
            this.jeanTextBox12.SelectionStart = 0;
            this.jeanTextBox12.Size = new System.Drawing.Size(330, 65);
            this.jeanTextBox12.TabIndex = 50;
            this.jeanTextBox12.TextInput = "";
            this.jeanTextBox12.TextPreview = "Когда и кем выдан";
            this.jeanTextBox12.UseSystemPasswordChar = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(14, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 25);
            this.label1.TabIndex = 49;
            this.label1.Text = "Паспорт";
            // 
            // jeanTextBox10
            // 
            this.jeanTextBox10.BackColor = System.Drawing.Color.White;
            this.jeanTextBox10.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBox10.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBox10.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBox10.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBox10.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBox10.Location = new System.Drawing.Point(22, 51);
            this.jeanTextBox10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.jeanTextBox10.Name = "jeanTextBox10";
            this.jeanTextBox10.SelectionStart = 0;
            this.jeanTextBox10.Size = new System.Drawing.Size(330, 39);
            this.jeanTextBox10.TabIndex = 47;
            this.jeanTextBox10.TextInput = "";
            this.jeanTextBox10.TextPreview = "Серия, номер";
            this.jeanTextBox10.UseSystemPasswordChar = false;
            // 
            // jeanTextBox11
            // 
            this.jeanTextBox11.BackColor = System.Drawing.Color.White;
            this.jeanTextBox11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBox11.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBox11.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBox11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBox11.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBox11.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBox11.Location = new System.Drawing.Point(356, 270);
            this.jeanTextBox11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.jeanTextBox11.Name = "jeanTextBox11";
            this.jeanTextBox11.SelectionStart = 0;
            this.jeanTextBox11.Size = new System.Drawing.Size(269, 39);
            this.jeanTextBox11.TabIndex = 48;
            this.jeanTextBox11.TextInput = "";
            this.jeanTextBox11.TextPreview = "Email";
            this.jeanTextBox11.UseSystemPasswordChar = false;
            // 
            // jeanTextBox9
            // 
            this.jeanTextBox9.BackColor = System.Drawing.Color.White;
            this.jeanTextBox9.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBox9.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBox9.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBox9.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBox9.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBox9.Location = new System.Drawing.Point(458, 555);
            this.jeanTextBox9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.jeanTextBox9.Name = "jeanTextBox9";
            this.jeanTextBox9.SelectionStart = 0;
            this.jeanTextBox9.Size = new System.Drawing.Size(120, 39);
            this.jeanTextBox9.TabIndex = 46;
            this.jeanTextBox9.TextInput = "";
            this.jeanTextBox9.TextPreview = "Квартира";
            this.jeanTextBox9.UseSystemPasswordChar = false;
            // 
            // jeanTextBox8
            // 
            this.jeanTextBox8.BackColor = System.Drawing.Color.White;
            this.jeanTextBox8.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBox8.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBox8.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBox8.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBox8.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBox8.Location = new System.Drawing.Point(458, 482);
            this.jeanTextBox8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.jeanTextBox8.Name = "jeanTextBox8";
            this.jeanTextBox8.SelectionStart = 0;
            this.jeanTextBox8.Size = new System.Drawing.Size(120, 39);
            this.jeanTextBox8.TabIndex = 45;
            this.jeanTextBox8.TextInput = "";
            this.jeanTextBox8.TextPreview = "Дом";
            this.jeanTextBox8.UseSystemPasswordChar = false;
            // 
            // jeanTextBox7
            // 
            this.jeanTextBox7.BackColor = System.Drawing.Color.White;
            this.jeanTextBox7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBox7.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBox7.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBox7.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBox7.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBox7.Location = new System.Drawing.Point(600, 482);
            this.jeanTextBox7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.jeanTextBox7.Name = "jeanTextBox7";
            this.jeanTextBox7.SelectionStart = 0;
            this.jeanTextBox7.Size = new System.Drawing.Size(120, 39);
            this.jeanTextBox7.TabIndex = 44;
            this.jeanTextBox7.TextInput = "";
            this.jeanTextBox7.TextPreview = "Корпус";
            this.jeanTextBox7.UseSystemPasswordChar = false;
            // 
            // jeanTextBox6
            // 
            this.jeanTextBox6.BackColor = System.Drawing.Color.White;
            this.jeanTextBox6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBox6.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBox6.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBox6.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBox6.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBox6.Location = new System.Drawing.Point(600, 555);
            this.jeanTextBox6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.jeanTextBox6.Name = "jeanTextBox6";
            this.jeanTextBox6.SelectionStart = 0;
            this.jeanTextBox6.Size = new System.Drawing.Size(120, 39);
            this.jeanTextBox6.TabIndex = 43;
            this.jeanTextBox6.TextInput = "";
            this.jeanTextBox6.TextPreview = "Индекс";
            this.jeanTextBox6.UseSystemPasswordChar = false;
            // 
            // jeanTextBox5
            // 
            this.jeanTextBox5.BackColor = System.Drawing.Color.White;
            this.jeanTextBox5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBox5.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBox5.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBox5.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBox5.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBox5.Location = new System.Drawing.Point(38, 556);
            this.jeanTextBox5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.jeanTextBox5.Name = "jeanTextBox5";
            this.jeanTextBox5.SelectionStart = 0;
            this.jeanTextBox5.Size = new System.Drawing.Size(393, 39);
            this.jeanTextBox5.TabIndex = 42;
            this.jeanTextBox5.TextInput = "";
            this.jeanTextBox5.TextPreview = "Улица, проспект, площадь";
            this.jeanTextBox5.UseSystemPasswordChar = false;
            // 
            // jeanTextBox4
            // 
            this.jeanTextBox4.BackColor = System.Drawing.Color.White;
            this.jeanTextBox4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBox4.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBox4.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBox4.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBox4.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBox4.Location = new System.Drawing.Point(38, 482);
            this.jeanTextBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.jeanTextBox4.Name = "jeanTextBox4";
            this.jeanTextBox4.SelectionStart = 0;
            this.jeanTextBox4.Size = new System.Drawing.Size(393, 39);
            this.jeanTextBox4.TabIndex = 41;
            this.jeanTextBox4.TextInput = "";
            this.jeanTextBox4.TextPreview = "Город, населенный пункт";
            this.jeanTextBox4.UseSystemPasswordChar = false;
            // 
            // jeanTextBox3
            // 
            this.jeanTextBox3.BackColor = System.Drawing.Color.White;
            this.jeanTextBox3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBox3.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBox3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBox3.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBox3.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBox3.Location = new System.Drawing.Point(38, 413);
            this.jeanTextBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.jeanTextBox3.Name = "jeanTextBox3";
            this.jeanTextBox3.SelectionStart = 0;
            this.jeanTextBox3.Size = new System.Drawing.Size(393, 39);
            this.jeanTextBox3.TabIndex = 40;
            this.jeanTextBox3.TextInput = "";
            this.jeanTextBox3.TextPreview = "Район";
            this.jeanTextBox3.UseSystemPasswordChar = false;
            // 
            // jeanTextBox2
            // 
            this.jeanTextBox2.BackColor = System.Drawing.Color.White;
            this.jeanTextBox2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBox2.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBox2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBox2.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBox2.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBox2.Location = new System.Drawing.Point(38, 340);
            this.jeanTextBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.jeanTextBox2.Name = "jeanTextBox2";
            this.jeanTextBox2.SelectionStart = 0;
            this.jeanTextBox2.Size = new System.Drawing.Size(393, 39);
            this.jeanTextBox2.TabIndex = 39;
            this.jeanTextBox2.TextInput = "";
            this.jeanTextBox2.TextPreview = "Регион";
            this.jeanTextBox2.UseSystemPasswordChar = false;
            // 
            // jeanTextBox1
            // 
            this.jeanTextBox1.BackColor = System.Drawing.Color.White;
            this.jeanTextBox1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.jeanTextBox1.BorderColorNotActive = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.jeanTextBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.jeanTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanTextBox1.FontTextPreview = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.jeanTextBox1.ForeColor = System.Drawing.Color.Black;
            this.jeanTextBox1.Location = new System.Drawing.Point(38, 270);
            this.jeanTextBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.jeanTextBox1.Name = "jeanTextBox1";
            this.jeanTextBox1.SelectionStart = 0;
            this.jeanTextBox1.Size = new System.Drawing.Size(207, 39);
            this.jeanTextBox1.TabIndex = 38;
            this.jeanTextBox1.TextInput = "";
            this.jeanTextBox1.TextPreview = "Второй телефон";
            this.jeanTextBox1.UseSystemPasswordChar = false;
            // 
            // NewClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1131, 647);
            this.Controls.Add(this.panelMoreData);
            this.Controls.Add(this.jeanModernButtonMoreDate);
            this.Controls.Add(this.jeanTextBoxDiscount);
            this.Controls.Add(this.dataGridViewServices);
            this.Controls.Add(this.jeanPanel);
            this.Controls.Add(this.jeanDateTimePickerSell);
            this.Controls.Add(this.jeanModernButtonAdd);
            this.Controls.Add(this.jeanTextBoxPurchase);
            this.Controls.Add(this.jeanTextBoxNumberCard);
            this.Controls.Add(this.jeanTextBoxBirthday);
            this.Controls.Add(this.jeanTextBoxFather);
            this.Controls.Add(this.jeanTextBoxSurname);
            this.Controls.Add(this.jeanTextBoxName);
            this.Controls.Add(this.jeanTextBoxNumber);
            this.Controls.Add(this.checkBoxVisited);
            this.Controls.Add(this.radioButtonWoman);
            this.Controls.Add(this.radioButtonMan);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "NewClient";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Новый Клиент";
            this.Load += new System.EventHandler(this.NewClient_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewServices)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMoreDate)).EndInit();
            this.panelMoreData.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.RadioButton radioButtonWoman;
        private System.Windows.Forms.RadioButton radioButtonMan;
        private System.Windows.Forms.CheckBox checkBoxVisited;
        private JeanTextBox jeanTextBoxNumber;
        private JeanTextBox jeanTextBoxName;
        private JeanTextBox jeanTextBoxSurname;
        private JeanTextBox jeanTextBoxFather;
        private JeanTextBox jeanTextBoxBirthday;
        private JeanTextBox jeanTextBoxNumberCard;
        private JeanTextBox jeanTextBoxPurchase;
        protected internal Controls.JeanModernButton jeanModernButtonAdd;
        private Components.JeanFormStyle jeanFormStyle;
        private Controls.JeanDateTimePicker jeanDateTimePickerSell;
        private Controls.JeanPanel jeanPanel;
        private System.Windows.Forms.DataGridView dataGridViewServices;
        private JeanTextBox jeanTextBoxDiscount;
        private Controls.JeanModernButton jeanModernButtonMoreDate;
        private System.Windows.Forms.Panel panelMoreData;
        private System.Windows.Forms.DataGridView dataGridViewMoreDate;
        private JeanTextBox jeanTextBox2;
        private JeanTextBox jeanTextBox1;
        private JeanTextBox jeanTextBox11;
        private JeanTextBox jeanTextBox10;
        private JeanTextBox jeanTextBox9;
        private JeanTextBox jeanTextBox8;
        private JeanTextBox jeanTextBox7;
        private JeanTextBox jeanTextBox6;
        private JeanTextBox jeanTextBox5;
        private JeanTextBox jeanTextBox4;
        private JeanTextBox jeanTextBox3;
        private System.Windows.Forms.Panel panel1;
        private JeanTextBox jeanTextBox12;
        private System.Windows.Forms.Label label1;
    }
}