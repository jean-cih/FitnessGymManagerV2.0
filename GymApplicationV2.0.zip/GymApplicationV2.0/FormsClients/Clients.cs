﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlTypes;
using System.Text.RegularExpressions;
using GymApplicationV2._0.Components;

namespace GymApplicationV2._0
{
    public partial class Clients : Form
    {
        public Clients()
        {
            InitializeComponent();
        }

        private void Clients_Load(object sender, EventArgs e)
        {
            JeanFormStyle.fStyle style = JeanFormStyle.fStyle.None;
            if (DataClass.styleForm == "UserStyle")
            {
                style = JeanFormStyle.fStyle.UserStyle;
            }
            else if (DataClass.styleForm == "SimpleDark")
            {
                style = JeanFormStyle.fStyle.SimpleDark;
            }
            else if (DataClass.styleForm == "TelegramStyle")
            {
                style = JeanFormStyle.fStyle.TelegramStyle;
            }
            jeanFormStyle.FormStyle = style;

            dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts");
            //jeanModernButtonRefresh.Font = new Font("Обновить", DataClass.sizeFontButtons);
            jeanModernButtonChangeData.Font = new Font("Изменить данные клиента", DataClass.sizeFontButtons);

            dataGridViewClients.DefaultCellStyle.Font = new Font("Contacts", DataClass.sizeFontTables);
            dataGridViewClients.ColumnHeadersDefaultCellStyle.Font = new Font("Contacts", DataClass.sizeFontTables);

        }

        private void dataGridViewClients_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        /*
        private void jeanModernButtonRefresh_Click(object sender, EventArgs e)
        {
            jeanSoftTextBoxSearch.Texts = "";
            dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts");
        }
        */
        private void jeanModernButtonChangeData_Click(object sender, EventArgs e)
        {
            ChangeData changeData = new ChangeData();
            changeData.Show();
            this.Close();
        }

        private void jeanSoftTextBoxSearch__TextChanged(object sender, EventArgs e)
        {
            if (jeanSoftTextBoxSearch.Texts.Length > 0)
            {
                jeanModernButtonErase.Visible = true;
            }
            else
            {
                jeanModernButtonErase.Visible = false;
                dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts");
                return;
            }

            string[] fullName = jeanSoftTextBoxSearch.Texts.Split(' ');
            fullName[0] = Char.ToUpper(fullName[0][0]) + fullName[0].Substring(1);
            try
            {
                fullName[1] = Char.ToUpper(fullName[1][0]) + fullName[1].Substring(1);

                dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase($"" +
                    $"SELECT * " +
                    $"FROM Contacts " +
                    $"WHERE №Карты LIKE '%{fullName[0]}%' " +
                    $"OR Фамилия LIKE '%{fullName[0]}%' " +
                    $"AND Имя LIKE '%{fullName[1]}%'");
            }
            catch
            {
                dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase($"" +
                    $"SELECT * " +
                    $"FROM Contacts " +
                    $"WHERE №Карты LIKE '%{fullName[0]}%' " +
                    $"OR Фамилия LIKE '%{fullName[0]}%' " +
                    $"OR Имя LIKE '%{fullName[0]}%'");
            }
        }

        private void jeanModernButtonErase_Click(object sender, EventArgs e)
        {
            jeanSoftTextBoxSearch.Texts = "";
        }
    }
}
