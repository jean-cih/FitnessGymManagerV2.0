﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlTypes;
using System.Text.RegularExpressions;
using GymApplicationV2._0.Components;
using GymApplicationV2._0.FormsClients;
using System.Text.Json.Serialization;
using System.Drawing;
using System.Drawing.Drawing2D;
//using Microsoft.Office.Interop.Excel;

namespace GymApplicationV2._0
{
    public partial class Clients : Form
    {
        private Button button;

        private Panel dataPanel;
        private Timer animationTimer;

        string path = "\\Photos\\";

        int location;
        public Clients()
        {
            InitializeComponent();

            dataGridViewClients.CellMouseEnter += dataGridViewClients_CellMouseEnter;
        }

        private void jeanModernButtonExit_Click(object sender, EventArgs e)
        {
            jeanPanelPerson.Visible = false;
            jeanPanelProfile.Visible = false;
        }

        private void button_Click(object sender, EventArgs e)
        {
            int rowIndex = location / dataGridViewClients.Rows[0].Height;

            string data = dataGridViewClients.Rows[rowIndex].Cells[0].Value.ToString();
            string fullName = dataGridViewClients.Rows[rowIndex].Cells[1].Value.ToString() + " " + dataGridViewClients.Rows[rowIndex].Cells[2].Value.ToString(); ;
            string numberPhone = dataGridViewClients.Rows[rowIndex].Cells[4].Value.ToString();
            string numberCardPerson = dataGridViewClients.Rows[rowIndex].Cells[5].Value.ToString();
            string membershipPerson = dataGridViewClients.Rows[rowIndex].Cells[8].Value.ToString();

            string birthdayPerson = dataGridViewClients.Rows[rowIndex].Cells[13].Value.ToString();
            string visitPerson = dataGridViewClients.Rows[rowIndex].Cells[10].Value.ToString();
            string leftPerson = dataGridViewClients.Rows[rowIndex].Cells[9].Value.ToString();
            string savedPerson = dataGridViewClients.Rows[rowIndex].Cells[15].Value.ToString();
            string emailPerson = dataGridViewClients.Rows[rowIndex].Cells[12].Value.ToString();
            string sex = dataGridViewClients.Rows[rowIndex].Cells[3].Value.ToString();

            if (!checkBoxPerson.Checked)
            {

                jeanPanelProfile.Location = new Point(jeanPanel.Width - jeanPanelProfile.Width, 0);
                jeanPanelProfile.Visible = true;

                jeanPanelPerson.Location = new Point(jeanPanel.Width - jeanPanelPerson.Width, jeanPanelProfile.Height);
                jeanPanelPerson.Visible = true;
                jeanPanelPerson.VerticalScroll.Value = 0;

                name.Text = fullName;
                name.Location = new Point(jeanPanelPerson.Width / 2 - name.Width / 2, 180);
                number.Text = numberPhone;
                birthday.Text = string.Compare(birthdayPerson, "") != 0 ? birthdayPerson : "не указан";
                sav.Text = savedPerson;
                email.Text = string.Compare(emailPerson, "") != 0 ? emailPerson : "не указан";
                id.Text = data;

                //Карта
                membership.Text = membershipPerson;
                numberCard.Text = "№ " + numberCardPerson;
                visit.Text = visitPerson;
                left.Text = leftPerson;

                string pathToPhotos = Environment.CurrentDirectory;
                pictureBoxPerson.Image = Image.FromFile(FindPhoto(name.Text, pathToPhotos + path, sex));
                MakePictureBoxRound(pictureBoxPerson, 75);
            }
            else
            {
                Person person = new Person();

                person.namePerson.Text = fullName;
                person.numberPerson.Text = numberPhone;
                person.birthDay.Text = string.Compare(birthdayPerson, "") != 0 ? birthdayPerson : "не указан";
                person.saved.Text = savedPerson;
                person.email.Text = string.Compare(emailPerson, "") != 0 ? emailPerson : "не указан";

                //Карта
                person.membershipPerson.Text = membershipPerson;
                person.numberCard.Text = "№ " + numberCardPerson;
                person.visitDate.Text = visitPerson;
                person.visit.Text = leftPerson;

                person.Show();
            }
        }

        public void MakePictureBoxRound(PictureBox pictureBox, int radius)
        {
            Graphics path = Graphics.FromHwnd(pictureBox.Handle);
            path.SmoothingMode = SmoothingMode.AntiAlias;

            GraphicsPath roundPath = new GraphicsPath();
            roundPath.AddEllipse(0, 0, radius * 2, radius * 2);

            pictureBox.Region = new Region(roundPath);
        }

        private string FindPhoto(string clientName, string folderPath, string sex)
        {
            foreach (string filePath in Directory.EnumerateFiles(folderPath))
            {
                string fileName = Path.GetFileNameWithoutExtension(filePath);

                if (fileName.Equals(clientName, StringComparison.OrdinalIgnoreCase))
                {
                    return filePath;
                }
            }
            string sexPhoto = "userMale.png";
            if (string.Compare(sex, "Женский") == 0)
            {
                sexPhoto = "userFemale.png";
            }

            return Environment.CurrentDirectory + path + sexPhoto;
        }

        private void dataGridViewClients_CellMouseEnter(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0 && e.RowIndex < dataGridViewClients.Rows.Count && e.ColumnIndex < dataGridViewClients.Columns.Count) 
            { 
                if (e.ColumnIndex == 0)
                {
                    if (button != null)
                    {
                        dataGridViewClients.Controls.Remove(button);
                    }

                    button = new Button();
                    button.Text = "Открыть";
                    button.Size = new Size(80, 30);

                    location = e.RowIndex * dataGridViewClients.Rows[e.RowIndex].Height;

                    int x = dataGridViewClients.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, true).X;
                    int y = dataGridViewClients.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, true).Y;

                    button.Location = new Point(x + dataGridViewClients.Columns[e.ColumnIndex].Width, y);

                    dataGridViewClients.Controls.Add(button);

                    button.Click += button_Click;
                }
                else
                {
                    if (button != null)
                    {
                        dataGridViewClients.Controls.Remove(button);
                    }
                }
            }
        }


        private void Clients_Load(object sender, EventArgs e)
        {
            this.Width = Convert.ToInt32(Screen.PrimaryScreen.Bounds.Width * 0.85);
            this.Height = Convert.ToInt32(Screen.PrimaryScreen.Bounds.Height * 0.85);

            jeanPanel.Size = new Size(this.Width - 40, this.Height - 150);
            jeanSoftTextBoxSearch.Location = new Point(this.Width / 2 - 150, 30);
            jeanModernButtonErase.Location = new System.Drawing.Point(this.Width / 2 - 150 + 260, 35);
            pictureBoxSearch.Location = new Point(this.Width / 2 - 140, 35);
            jeanModernButtonChangeData.Location = new Point(this.Width - 160, 13);

            dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts");

            jeanModernButtonChangeData.Font = new Font("Изменить данные клиента", DataClass.sizeFontButtons);

            dataGridViewClients.DefaultCellStyle.Font = new Font("Contacts", DataClass.sizeFontTables);
            dataGridViewClients.ColumnHeadersDefaultCellStyle.Font = new Font("Contacts", DataClass.sizeFontTables);

        }

        private void dataGridViewClients_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        
        private void jeanModernButtonChangeData_Click(object sender, EventArgs e)
        {
            ChangeData changeData = new ChangeData();
            changeData.Show();
            this.Close();
        }

        private void jeanSoftTextBoxSearch__TextChanged(object sender, EventArgs e)
        {
            if (jeanSoftTextBoxSearch.Texts.Length > 0)
            {
                jeanModernButtonErase.Visible = true;
            }
            else
            {
                jeanModernButtonErase.Visible = false;
                dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts");
                return;
            }

            string[] fullName = jeanSoftTextBoxSearch.Texts.Split(' ');
            fullName[0] = Char.ToUpper(fullName[0][0]) + fullName[0].Substring(1);
            try
            {
                fullName[1] = Char.ToUpper(fullName[1][0]) + fullName[1].Substring(1);

                dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase($"" +
                    $"SELECT * " +
                    $"FROM Contacts " +
                    $"WHERE №Карты LIKE '%{fullName[0]}%' " +
                    $"OR Фамилия LIKE '%{fullName[0]}%' " +
                    $"AND Имя LIKE '%{fullName[1]}%' " +
                    $"OR Имя LIKE '%{fullName[0]}%' " +
                    $"AND Фамилия LIKE '%{fullName[1]}%'");
            }
            catch
            {
                dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase($"" +
                    $"SELECT * " +
                    $"FROM Contacts " +
                    $"WHERE №Карты LIKE '%{fullName[0]}%' " +
                    $"OR Фамилия LIKE '%{fullName[0]}%' " +
                    $"OR Имя LIKE '%{fullName[0]}%'");
            }
        }

        private void jeanModernButtonErase_Click(object sender, EventArgs e)
        {
            jeanSoftTextBoxSearch.Texts = "";
        }
    }
}
