﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Entity;
using System.Data.SQLite;
using System.IO;
using System.Drawing.Text;
using System.Text.RegularExpressions;
using System.Globalization;
using System.Data.Entity.Infrastructure;
using GymApplicationV2._0.Components;

namespace GymApplicationV2._0
{
    public partial class NewClient : Form
    {
        public NewClient()
        {
            InitializeComponent();

            this.KeyPreview = true;
            this.KeyDown += jeanTextBoxBirthday_KeyDown;

        }

        private void NewClient_Load(object sender, EventArgs e)
        {
            JeanFormStyle.fStyle style = JeanFormStyle.fStyle.None;
            if (DataClass.styleForm == "UserStyle")
            {
                style = JeanFormStyle.fStyle.UserStyle;
            }
            else if (DataClass.styleForm == "SimpleDark")
            {
                style = JeanFormStyle.fStyle.SimpleDark;
            }
            else if (DataClass.styleForm == "TelegramStyle")
            {
                style = JeanFormStyle.fStyle.TelegramStyle;
            }

            jeanFormStyle.FormStyle = style;


            dataGridViewServices.DataSource = ServicesContext.GetDataFromDatabase("SELECT Наименование, Цена, СрокДействия, Количество FROM Descriptions");


            jeanModernButtonAdd.Font = new Font("Добавить", DataClass.sizeFontButtons);

            dataGridViewServices.DefaultCellStyle.Font = new Font("Contacts", DataClass.sizeFontTables);
            dataGridViewServices.ColumnHeadersDefaultCellStyle.Font = new Font("Contacts", DataClass.sizeFontTables);

            radioButtonMan.Font = new Font("муж", DataClass.sizeFontCaptions - 2);
            radioButtonWoman.Font = new Font("жен", DataClass.sizeFontCaptions - 2);
            checkBoxVisited.Font = new Font("Отметить посещение сразу", DataClass.sizeFontCaptions - 2);  
        }

        string lefts = "", price = "", termMembership = "";
        private void dataGridViewServices_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            jeanTextBoxPurchase.Text = dataGridViewServices.SelectedRows[0].Cells[0].Value.ToString();
            lefts = dataGridViewServices.SelectedRows[0].Cells[3].Value.ToString();
            price = dataGridViewServices.SelectedRows[0].Cells[1].Value.ToString();
            termMembership = dataGridViewServices.SelectedRows[0].Cells[2].Value.ToString();
        }


        bool space;
        private void jeanTextBoxBirthday_KeyDown(object sender, KeyEventArgs e)
        {
            space = e.KeyCode == Keys.Space ? true : false;
        }

        bool isDigit;
        private void jeanTextBoxBirthday_KeyPress(object sender, KeyPressEventArgs e)
        {
            isDigit = char.IsDigit(e.KeyChar) ? true : false;
        }

        private void jeanTextBoxBirthday_TextChanged(object sender, EventArgs e)
        {
            if (jeanTextBoxBirthday.Text.Length == 2 && space)
            {
                jeanTextBoxBirthday.Text = "0" + jeanTextBoxBirthday.Text[jeanTextBoxBirthday.Text.Length - 2] + ".";
                jeanTextBoxBirthday.SelectionStart = jeanTextBoxBirthday.Text.Length;
            }
            else if (jeanTextBoxBirthday.Text.Length == 5 && space)
            {
                jeanTextBoxBirthday.Text = jeanTextBoxBirthday.Text.Substring(0, 3) + "0" + jeanTextBoxBirthday.Text[jeanTextBoxBirthday.Text.Length - 2] + ".";
                jeanTextBoxBirthday.SelectionStart = jeanTextBoxBirthday.Text.Length;
            }

            if ((jeanTextBoxBirthday.Text.Length == 2 || jeanTextBoxBirthday.Text.Length == 5) && isDigit)
            {
                jeanTextBoxBirthday.Text += '.';
                jeanTextBoxBirthday.SelectionStart = jeanTextBoxBirthday.Text.Length;
            }
            
            if (jeanTextBoxBirthday.Text.Length == 10 && (Convert.ToInt32(jeanTextBoxBirthday.Text.Substring(0, 2)) > 32 || Convert.ToInt32(jeanTextBoxBirthday.Text.Substring(3, 2)) > 12 || Convert.ToInt32(jeanTextBoxBirthday.Text.Substring(6, 4)) > DateTime.Now.Year))
            {
                jeanTextBoxBirthday.BackColor = Color.FromArgb(255, 150, 150);

            }
            else
            {
                jeanTextBoxBirthday.BackColor = Color.White;
            }       
        }

        private void jeanTextBoxNumber_Click(object sender, EventArgs e)
        {
            if (jeanTextBoxNumber.Text.Length == 0)
            {
                jeanTextBoxNumber.Text = "+7";
                jeanTextBoxNumber.SelectionStart = jeanTextBoxNumber.Text.Length;
            }
        }

        private void jeanTextBoxNumber_KeyPress(object sender, KeyPressEventArgs e)
        {     
            if(!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                jeanTextBoxNumber.BackColor = Color.FromArgb(255, 150, 150);
            } 
        }

        private void jeanTextBoxNumber_TextChanged(object sender, EventArgs e)
        {
            if (jeanTextBoxNumber.Text == "")
            {
                jeanTextBoxNumber.Text += "+7";
                jeanTextBoxNumber.SelectionStart = jeanTextBoxNumber.Text.Length;
            }

            if (Regex.IsMatch(jeanTextBoxNumber.Text.Substring(1, jeanTextBoxNumber.Text.Length - 1), @"^-?\d+(\d+)?$") && jeanTextBoxNumber.Text.Length <= 12)
            {
                jeanTextBoxNumber.BackColor = Color.White;
            }
            else
            {
                jeanTextBoxNumber.BackColor = Color.FromArgb(255, 150, 150);
            }
        }

        private void jeanTextBoxName_TextChanged(object sender, EventArgs e)
        {
            if (jeanTextBoxName.Text.All(c => !char.IsDigit(c)) && jeanTextBoxName.Text.Length <= 20)
            {
                jeanTextBoxName.BackColor = Color.White;
            }
            else
            {
                jeanTextBoxName.BackColor = Color.FromArgb(255, 150, 150);
            }
        }

        private void jeanTextBoxSurname_TextChanged(object sender, EventArgs e)
        {
            if (jeanTextBoxSurname.Text.All(c => !char.IsDigit(c)) && jeanTextBoxSurname.Text.Length <= 20)
            {
                jeanTextBoxSurname.BackColor = Color.White;
            }
            else
            {
                jeanTextBoxSurname.BackColor = Color.FromArgb(255, 150, 150);
            }
        }

        private void jeanTextBoxFather_TextChanged(object sender, EventArgs e)
        {
            if (jeanTextBoxFather.Text.All(c => !char.IsDigit(c)) && jeanTextBoxFather.Text.Length <= 20)
            {
                jeanTextBoxFather.BackColor = Color.White;
            }
            else
            {
                jeanTextBoxFather.BackColor = Color.FromArgb(255, 150, 150);
            }
        }

        private void jeanTextBoxNumberCard_TextChanged(object sender, EventArgs e)
        {
            if ((Regex.IsMatch(jeanTextBoxNumberCard.Text.Substring(0, jeanTextBoxNumberCard.Text.Length), @"^-?\d+(\d+)?$") && jeanTextBoxNumberCard.Text.Length <= 13) || jeanTextBoxNumberCard.Text.Length == 0)
            {
                jeanTextBoxNumberCard.BackColor = Color.White;
            }
            else
            {
                jeanTextBoxNumberCard.BackColor = Color.FromArgb(255, 150, 150);
            }
        }

        private void jeanTextBoxDiscount_TextChanged(object sender, EventArgs e)
        {
            if (jeanTextBoxDiscount.Text.Length == 0 || (Regex.IsMatch(jeanTextBoxDiscount.Text.Substring(0, jeanTextBoxDiscount.Text.Length), @"^-?\d+(\d+)?$") && Convert.ToInt32(jeanTextBoxDiscount.Text) <= 100))
            {
                jeanTextBoxDiscount.BackColor = Color.White;
            }
            else
            {
                jeanTextBoxDiscount.BackColor = Color.FromArgb(255, 150, 150);
            }
        }

        int k = 0;
        private void jeanModernButtonMoreDate_Click(object sender, EventArgs e)
        {
            if (k % 2 == 0)
            {
                panelMoreData.Visible = true;
            }
            else
            {
                panelMoreData.Visible = false;
            }
            k++;
        }

        private void jeanTextBoxPurchase_TextChanged(object sender, EventArgs e)
        {
            if (jeanTextBoxPurchase.Text.Length <= 100)
            {
                jeanTextBoxPurchase.BackColor = Color.White;
            }
            else
            {
                jeanTextBoxPurchase.BackColor = Color.FromArgb(255, 150, 150);
            }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            if (jeanTextBoxNumber.BackColor != Color.White || jeanTextBoxName.BackColor != Color.White || 
                jeanTextBoxSurname.BackColor != Color.White || jeanTextBoxFather.BackColor != Color.White || 
                jeanTextBoxPurchase.BackColor != Color.White || jeanTextBoxDiscount.BackColor != Color.White || 
                jeanTextBoxBirthday.BackColor != Color.White || jeanTextBoxNumberCard.BackColor != Color.White)
            {
                Message.MessageWindowOk("Неправильные данные");
                return;
            }

            if (jeanTextBoxNumber.Text.Length == 0 || jeanTextBoxName.Text.Length == 0 || jeanTextBoxSurname.Text.Length == 0)
            {
                Message.MessageWindowOk("Незаполненные данные");
                return;
            }

            if (jeanTextBoxPurchase.Text.Length != 0 && jeanTextBoxNumberCard.Text.Length == 0)
            {
                Message.MessageWindowOk("Для абонемента нужен номер карты");
                return;
            }

            if (jeanTextBoxPurchase.Text.Length == 0 && jeanTextBoxNumberCard.Text.Length == 13)
            {
                Message.MessageWindowOk("Выберете услугу");
                return;
            }

            //Получение максимального id клиента
            SQLiteConnection conn2 = new SQLiteConnection(ClientsContext.ConnectionStringClients());
            conn2.Open();

            SQLiteCommand cmd2 = new SQLiteCommand("SELECT Id FROM Contacts", conn2);
            SQLiteDataReader reader = cmd2.ExecuteReader();

            object id = null;
            while (reader.Read())
            {
                id = reader[0];
            }

            reader.Close();
            cmd2.Dispose();
            conn2.Close();

            int number;

            if (id != null)
                number = Convert.ToInt32(id) + 1;
            else
                number = 1;


            string gender;
            if (radioButtonMan.Checked)
            {
                gender = "Мужской";
            }
            else if (radioButtonWoman.Checked)
            {
                gender = "Женский";
            }
            else
            {
                gender = "";
            }

            string purchase = price;
            int markRightNow = 0;
            string dateNow = "";
            string termDate = "";
            string leftVisit = "";
            string discounts = "";
            //Добавляем нового клиента
            using (SQLiteConnection conn = new SQLiteConnection(ClientsContext.ConnectionStringClients()))
            {
                string commandStringNew = "INSERT INTO Contacts (" +
                    "[Id],[Фамилия],[Имя],[Пол],[Телефон],[№Карты],[Покупки],[Посетил],[Абонемент],[Срок_абонемента],[Посещений_осталось],[Отчество],[Email],[Дата_рождения],[Скидка],[Сохранено])" +
                    " VALUES (@Id,@Фамилия,@Имя,@Пол,@Телефон,@№Карты,@Покупки,@Посетил,@Абонемент,@Срок_абонемента,@Посещений_осталось,@Отчество,@Email,@Дата_рождения,@Скидка,@Сохранено)";
                using (SQLiteCommand cmd = new SQLiteCommand(commandStringNew, conn))
                {
                    conn.Open();

                    cmd.Parameters.AddWithValue("@Id", number.ToString());
                    cmd.Parameters.AddWithValue("@Фамилия", jeanTextBoxSurname.Text);
                    cmd.Parameters.AddWithValue("@Имя", jeanTextBoxName.Text);
                    cmd.Parameters.AddWithValue("@Пол", gender);
                    cmd.Parameters.AddWithValue("@Телефон", jeanTextBoxNumber.Text);
                    cmd.Parameters.AddWithValue("@№Карты", jeanTextBoxNumberCard.Text);

                    if (decimal.TryParse(jeanTextBoxDiscount.Text, NumberStyles.Number, CultureInfo.InvariantCulture, out decimal discount) && price != "")
                    {
                        purchase = Convert.ToInt32(Convert.ToDecimal(price) * (1 - discount / 100)).ToString();
                    }
                    cmd.Parameters.AddWithValue("@Покупки", price);

                    if (checkBoxVisited.Checked)
                    {
                        markRightNow = 1;
                        dateNow = DateTime.Now.ToString();
                    }
                    cmd.Parameters.AddWithValue("@Посетил", dateNow);

                    cmd.Parameters.AddWithValue("@Абонемент", jeanTextBoxPurchase.Text);
                    //Прибавить срок абонемента
                    if (jeanTextBoxPurchase.Text != "")
                    {
                        termDate = new DateTime(jeanDateTimePickerSell.Value.Year, jeanDateTimePickerSell.Value.Month + Convert.ToInt32(termMembership), jeanDateTimePickerSell.Value.Day).ToShortDateString().ToString();
                    }
                    cmd.Parameters.AddWithValue("@Срок_абонемента", termDate);

                    if (lefts != "")
                    {
                        leftVisit = (Convert.ToInt32(lefts) - markRightNow).ToString();
                    }
                    cmd.Parameters.AddWithValue("@Посещений_осталось", leftVisit);
                     
                    cmd.Parameters.AddWithValue("@Отчество", jeanTextBoxFather.Text);
                    cmd.Parameters.AddWithValue("@Email", "");
                    cmd.Parameters.AddWithValue("@Дата_рождения", jeanTextBoxBirthday.Text);
                    if (jeanTextBoxDiscount.Text != "")
                    {
                        discounts = jeanTextBoxDiscount.Text + " %";
                    }
                    cmd.Parameters.AddWithValue("@Скидка", discounts);

                    cmd.Parameters.AddWithValue("@Сохранено", DateTime.Now.ToString());

                    cmd.ExecuteNonQuery();
                }

            }
            object quantity = ServicesContext.GetElementService("SELECT ПроданныхЗаМесяц FROM Descriptions WHERE Наименование = '" + jeanTextBoxPurchase.Text + "';"); ;
            if (jeanTextBoxPurchase.Text != "")
            {
                ServicesContext.CommandDataServices("UPDATE Descriptions SET " +
                    "ПроданныхЗаМесяц = '" + (Convert.ToInt32(quantity) + 1).ToString() + "' " +
                    "WHERE Наименование = '" + jeanTextBoxPurchase.Text + "';");

                //Получение максимального id клиента
                SQLiteConnection conn3 = new SQLiteConnection(HistoryPaymentContext.ConnectionStringPayment());
                conn3.Open();

                SQLiteCommand cmd3 = new SQLiteCommand("SELECT Id FROM History", conn3);
                SQLiteDataReader reader3 = cmd3.ExecuteReader();

                object idPay = null;
                while (reader3.Read())
                {
                    idPay = reader3[0];
                }

                reader3.Close();
                cmd3.Dispose();
                conn3.Close();

                int numberPay;
                if (idPay != null)
                    numberPay = Convert.ToInt32(idPay) + 1;
                else
                    numberPay = 1;

                using (SQLiteConnection conn = new SQLiteConnection(HistoryPaymentContext.ConnectionStringPayment()))
                {
                    //Добавить абонемент
                    string commandStringNew = "INSERT INTO History (" +
                    "[Id],[Клиент],[Абонемент],[Дата_начала],[Дата_окончания],[Цена],[Дата_платежа])" +
                    " VALUES (@Id,@Клиент,@Абонемент,@Дата_начала,@Дата_окончания,@Цена,@Дата_платежа)";

                    using (SQLiteCommand cmd = new SQLiteCommand(commandStringNew, conn))
                    {
                        conn.Open();
           
                        cmd.Parameters.AddWithValue("@Id", numberPay);
                        cmd.Parameters.AddWithValue("@Клиент", jeanTextBoxSurname.Text + " " + jeanTextBoxName.Text + " " + jeanTextBoxFather.Text);
                        cmd.Parameters.AddWithValue("@Абонемент", jeanTextBoxPurchase.Text);
                        cmd.Parameters.AddWithValue("@Дата_начала", jeanDateTimePickerSell.Value.ToShortDateString());
                        cmd.Parameters.AddWithValue("@Дата_окончания", termDate);
                        cmd.Parameters.AddWithValue("@Цена", purchase);
                        cmd.Parameters.AddWithValue("@Дата_платежа", DateTime.Now.ToShortDateString());

                        cmd.ExecuteNonQuery();
                    }
                }
            }

            jeanTextBoxSurname.Text = "";
            jeanTextBoxName.Text = "";
            jeanTextBoxNumber.Text = "";
            jeanTextBoxNumberCard.Text = "";
            jeanTextBoxPurchase.Text = "";
            jeanTextBoxFather.Text = "";
            jeanTextBoxBirthday.Text = "";
            jeanTextBoxDiscount.Text = "";

            Message.MessageWindowOk("Клиент добавлен");
        }
    }
}
