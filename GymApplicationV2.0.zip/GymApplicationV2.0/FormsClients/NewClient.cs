﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Entity;
using System.Data.SQLite;
using System.IO;
using System.Drawing.Text;
using System.Text.RegularExpressions;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Globalization;
using System.Data.Entity.Infrastructure;

namespace GymApplicationV2._0
{
    public partial class NewClient : Form
    {
        public NewClient()
        {
            InitializeComponent();
        }

        private void NewClient_Load(object sender, EventArgs e)
        {
            dataGridViewServices.DataSource = ServicesContext.GetDataFromDatabase("SELECT Наименование, Цена, СрокДействия, Количество FROM Descriptions");
            
            jeanModernButtonAdd.Font = new Font("Добавить", DataClass.sizeFontButtons);
            jeanModernButtonClients.Font = new Font("Клиент", DataClass.sizeFontButtons);

            dataGridViewServices.DefaultCellStyle.Font = new Font("Contacts", DataClass.sizeFontTables);
            dataGridViewServices.ColumnHeadersDefaultCellStyle.Font = new Font("Contacts", DataClass.sizeFontTables);

            radioButtonMan.Font = new Font("муж", DataClass.sizeFontCaptions - 2);
            radioButtonWoman.Font = new Font("жен", DataClass.sizeFontCaptions - 2);
            checkBoxVisited.Font = new Font("Отметить посещение сразу", DataClass.sizeFontCaptions - 2);
            labelDiscount.Font = new Font("Персональная скидка (%)", DataClass.sizeFontCaptions - 2);
        }

        string lefts = "", price = "", termMembership = "";
        private void dataGridViewServices_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            jeanTextBoxPurchase.Text = dataGridViewServices.SelectedRows[0].Cells[0].Value.ToString();
            lefts = dataGridViewServices.SelectedRows[0].Cells[3].Value.ToString();
            price = dataGridViewServices.SelectedRows[0].Cells[1].Value.ToString();
            termMembership = dataGridViewServices.SelectedRows[0].Cells[2].Value.ToString();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            if (jeanTextBoxSurname.Text == "" || jeanTextBoxName.Text == "" || (jeanTextBoxPurchase.Text != "" && jeanTextBoxNumberCard.Text == "") || (jeanTextBoxPurchase.Text == "" && jeanTextBoxNumberCard.Text != ""))
            {
                Message.MessageWindowOk("Незаполненные поля");

                return;
            }

            if (jeanTextBoxSurname.Text.Length > 20 || jeanTextBoxName.Text.Length > 20 || jeanTextBoxNumberCard.Text.Length > 20 || jeanTextBoxFather.Text.Length > 20)
            {
                Message.MessageWindowOk("Превышен лимит количества символов");

                return;
            }

            Regex regex = new Regex(@"^\d{11}$");
            if (!regex.IsMatch(jeanTextBoxNumber.Text))
            {
                Message.MessageWindowOk("Не правильный формат номера");
 
                return;
            }

            //Получение максимального id клиента
            SQLiteConnection conn2 = new SQLiteConnection(ClientsContext.ConnectionStringClients());
            conn2.Open();

            SQLiteCommand cmd2 = new SQLiteCommand("SELECT Id FROM Contacts", conn2);
            SQLiteDataReader reader = cmd2.ExecuteReader();

            object id = null;
            while (reader.Read())
            {
                id = reader[0];
            }

            reader.Close();
            cmd2.Dispose();
            conn2.Close();

            int number;

            if (id != null)
                number = Convert.ToInt32(id) + 1;
            else
                number = 1;

            //пол не заносится в таблицу
            string gender;
            if (radioButtonMan.Checked)
            {
                gender = "Мужской";
            }
            else if (radioButtonWoman.Checked)
            {
                gender = "Женский";
            }
            else
            {
                gender = "";
            }

            string purchase = price;
            int markRightNow = 0;
            string dateNow = "";
            string termDate = "";
            string leftVisit = "";
            string discounts = "";
            //Добавляем нового клиента
            using (SQLiteConnection conn = new SQLiteConnection(ClientsContext.ConnectionStringClients()))
            {
                string commandStringNew = "INSERT INTO Contacts (" +
                    "[Id],[Фамилия],[Имя],[Пол],[Телефон],[№Карты],[Покупки],[Посетил],[Абонемент],[Срок_абонемента],[Посещений_осталось],[Отчество],[Email],[Дата_рождения],[Скидка],[Сохранено])" +
                    " VALUES (@Id,@Фамилия,@Имя,@Пол,@Телефон,@№Карты,@Покупки,@Посетил,@Абонемент,@Срок_абонемента,@Посещений_осталось,@Отчество,@Email,@Дата_рождения,@Скидка,@Сохранено)";
                using (SQLiteCommand cmd = new SQLiteCommand(commandStringNew, conn))
                {
                    conn.Open();

                    cmd.Parameters.AddWithValue("@Id", number.ToString());
                    cmd.Parameters.AddWithValue("@Фамилия", jeanTextBoxSurname.Text);
                    cmd.Parameters.AddWithValue("@Имя", jeanTextBoxName.Text);
                    cmd.Parameters.AddWithValue("@Пол", gender);
                    cmd.Parameters.AddWithValue("@Телефон", jeanTextBoxNumber.Text);
                    cmd.Parameters.AddWithValue("@№Карты", jeanTextBoxNumberCard.Text);

                    if (decimal.TryParse(jeanTextBoxDiscount.Text, NumberStyles.Number, CultureInfo.InvariantCulture, out decimal discount) && price != "")
                    {
                        purchase = Convert.ToInt32(Convert.ToDecimal(price) * (1 - discount / 100)).ToString();
                    }
                    cmd.Parameters.AddWithValue("@Покупки", price);

                    if (checkBoxVisited.Checked)
                    {
                        markRightNow = 1;
                        dateNow = DateTime.Now.ToString();
                    }
                    cmd.Parameters.AddWithValue("@Посетил", dateNow);

                    cmd.Parameters.AddWithValue("@Абонемент", jeanTextBoxPurchase.Text);
                    //Прибавить срок абонемента
                    if (jeanTextBoxPurchase.Text != "")
                    {
                        termDate = new DateTime(dateTimePickerClient.Value.Year, dateTimePickerClient.Value.Month + Convert.ToInt32(termMembership), dateTimePickerClient.Value.Day).ToString();
                    }
                    cmd.Parameters.AddWithValue("@Срок_абонемента", termDate);

                    if (lefts != "")
                    {
                        leftVisit = (Convert.ToInt32(lefts) - markRightNow).ToString();
                    }
                    cmd.Parameters.AddWithValue("@Посещений_осталось", leftVisit);
                     
                    cmd.Parameters.AddWithValue("@Отчество", jeanTextBoxFather.Text);
                    cmd.Parameters.AddWithValue("@Email", "");
                    cmd.Parameters.AddWithValue("@Дата_рождения", jeanTextBoxBirthday.Text);
                    if (jeanTextBoxDiscount.Text != "")
                    {
                        discounts = jeanTextBoxDiscount.Text + " %";
                    }
                    cmd.Parameters.AddWithValue("@Скидка", discounts);

                    cmd.Parameters.AddWithValue("@Сохранено", DateTime.Now.ToString());

                    cmd.ExecuteNonQuery();
                }

            }
            object quantity = ServicesContext.GetElementService("SELECT ПроданныхЗаМесяц FROM Descriptions WHERE Наименование = '" + jeanTextBoxPurchase.Text + "';"); ;
            if (jeanTextBoxPurchase.Text != "")
            {
                ServicesContext.CommandDataServices("UPDATE Descriptions SET " +
                    "ПроданныхЗаМесяц = '" + (Convert.ToInt32(quantity) + 1).ToString() + "' " +
                    "WHERE Наименование = '" + jeanTextBoxPurchase.Text + "';");

                //Получение максимального id клиента
                SQLiteConnection conn3 = new SQLiteConnection(HistoryPaymentContext.ConnectionStringPayment());
                conn3.Open();

                SQLiteCommand cmd3 = new SQLiteCommand("SELECT Id FROM History", conn3);
                SQLiteDataReader reader3 = cmd3.ExecuteReader();

                object idPay = null;
                while (reader3.Read())
                {
                    idPay = reader3[0];
                }

                reader3.Close();
                cmd3.Dispose();
                conn3.Close();

                int numberPay;
                if (idPay != null)
                    numberPay = Convert.ToInt32(idPay) + 1;
                else
                    numberPay = 1;

                using (SQLiteConnection conn = new SQLiteConnection(HistoryPaymentContext.ConnectionStringPayment()))
                {
                    //Добавить абонемент
                    string commandStringNew = "INSERT INTO History (" +
                    "[Id],[ФИО],[Абонемент],[Дата_начала],[Дата_окончания],[Цена])" +
                    " VALUES (@Id,@ФИО,@Абонемент,@Дата_начала,@Дата_окончания,@Цена)";

                    using (SQLiteCommand cmd = new SQLiteCommand(commandStringNew, conn))
                    {
                        conn.Open();

                        cmd.Parameters.AddWithValue("@Id", numberPay);
                        cmd.Parameters.AddWithValue("@ФИО", jeanTextBoxSurname.Text + " " + jeanTextBoxName.Text + " " + jeanTextBoxFather.Text);
                        cmd.Parameters.AddWithValue("@Абонемент", jeanTextBoxPurchase.Text);
                        cmd.Parameters.AddWithValue("@Дата_начала", dateTimePickerClient.Value);
                        cmd.Parameters.AddWithValue("@Дата_окончания", termDate);
                        cmd.Parameters.AddWithValue("@Цена", purchase);

                        cmd.ExecuteNonQuery();
                    }
                }
            }

            jeanTextBoxSurname.Text = "";
            jeanTextBoxName.Text = "";
            jeanTextBoxNumber.Text = "";
            jeanTextBoxNumberCard.Text = "";
            jeanTextBoxPurchase.Text = "";
            jeanTextBoxFather.Text = "";
            jeanTextBoxBirthday.Text = "";
            jeanTextBoxDiscount.Text = "";

            Message.MessageWindowOk("Клиент добавлен");
        }

        private void buttonClients_Click(object sender, EventArgs e)
        {
            Clients clients = new Clients();
            clients.Show();
        }
    }
}
