﻿namespace GymApplicationV2._0
{
    partial class Clients
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Clients));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pictureBoxSearch = new System.Windows.Forms.PictureBox();
            this.checkBoxPerson = new System.Windows.Forms.CheckBox();
            this.jeanPanel = new GymApplicationV2._0.Controls.JeanPanel();
            this.jeanPanelProfile = new GymApplicationV2._0.Controls.JeanPanel();
            this.jeanModernButtonExit = new GymApplicationV2._0.Controls.JeanModernButton();
            this.profile = new System.Windows.Forms.Label();
            this.jeanPanelPerson = new GymApplicationV2._0.Controls.JeanPanel();
            this.saved = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.visit = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.left = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.membership = new System.Windows.Forms.Label();
            this.numberCard = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.id = new System.Windows.Forms.Label();
            this.birthday = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBoxPerson = new System.Windows.Forms.PictureBox();
            this.email = new System.Windows.Forms.Label();
            this.sav = new System.Windows.Forms.Label();
            this.number = new System.Windows.Forms.Label();
            this.name = new System.Windows.Forms.Label();
            this.dataGridViewClients = new System.Windows.Forms.DataGridView();
            this.jeanModernButtonErase = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanSoftTextBoxSearch = new GymApplicationV2._0.Controls.jeanSoftTextBox();
            this.jeanModernButtonChangeData = new GymApplicationV2._0.Controls.JeanModernButton();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSearch)).BeginInit();
            this.jeanPanel.SuspendLayout();
            this.jeanPanelProfile.SuspendLayout();
            this.jeanPanelPerson.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPerson)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewClients)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBoxSearch
            // 
            this.pictureBoxSearch.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pictureBoxSearch.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxSearch.Image")));
            this.pictureBoxSearch.Location = new System.Drawing.Point(445, 46);
            this.pictureBoxSearch.Name = "pictureBoxSearch";
            this.pictureBoxSearch.Size = new System.Drawing.Size(35, 30);
            this.pictureBoxSearch.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxSearch.TabIndex = 47;
            this.pictureBoxSearch.TabStop = false;
            // 
            // checkBoxPerson
            // 
            this.checkBoxPerson.AutoSize = true;
            this.checkBoxPerson.Location = new System.Drawing.Point(31, 61);
            this.checkBoxPerson.Name = "checkBoxPerson";
            this.checkBoxPerson.Size = new System.Drawing.Size(116, 20);
            this.checkBoxPerson.TabIndex = 49;
            this.checkBoxPerson.Text = "В новом окне";
            this.checkBoxPerson.UseVisualStyleBackColor = true;
            // 
            // jeanPanel
            // 
            this.jeanPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.jeanPanel.BackColor = System.Drawing.Color.White;
            this.jeanPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.jeanPanel.BorderRadius = 30;
            this.jeanPanel.Controls.Add(this.jeanPanelProfile);
            this.jeanPanel.Controls.Add(this.jeanPanelPerson);
            this.jeanPanel.Controls.Add(this.dataGridViewClients);
            this.jeanPanel.ForeColor = System.Drawing.Color.Black;
            this.jeanPanel.GradientAngle = 90F;
            this.jeanPanel.GradientBottomColor = System.Drawing.Color.DodgerBlue;
            this.jeanPanel.GradientTapColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            this.jeanPanel.Location = new System.Drawing.Point(5, 82);
            this.jeanPanel.Name = "jeanPanel";
            this.jeanPanel.Size = new System.Drawing.Size(1267, 757);
            this.jeanPanel.TabIndex = 48;
            // 
            // jeanPanelProfile
            // 
            this.jeanPanelProfile.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jeanPanelProfile.BackColor = System.Drawing.Color.WhiteSmoke;
            this.jeanPanelProfile.BorderRadius = 0;
            this.jeanPanelProfile.Controls.Add(this.jeanModernButtonExit);
            this.jeanPanelProfile.Controls.Add(this.profile);
            this.jeanPanelProfile.ForeColor = System.Drawing.Color.Black;
            this.jeanPanelProfile.GradientAngle = 90F;
            this.jeanPanelProfile.GradientBottomColor = System.Drawing.SystemColors.HighlightText;
            this.jeanPanelProfile.GradientTapColor = System.Drawing.SystemColors.HighlightText;
            this.jeanPanelProfile.Location = new System.Drawing.Point(774, 0);
            this.jeanPanelProfile.Name = "jeanPanelProfile";
            this.jeanPanelProfile.Size = new System.Drawing.Size(494, 70);
            this.jeanPanelProfile.TabIndex = 52;
            this.jeanPanelProfile.Visible = false;
            // 
            // jeanModernButtonExit
            // 
            this.jeanModernButtonExit.BackColor = System.Drawing.Color.Transparent;
            this.jeanModernButtonExit.BackgroundColor = System.Drawing.Color.Transparent;
            this.jeanModernButtonExit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("jeanModernButtonExit.BackgroundImage")));
            this.jeanModernButtonExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.jeanModernButtonExit.BorderColor = System.Drawing.Color.Transparent;
            this.jeanModernButtonExit.BorderRadius = 40;
            this.jeanModernButtonExit.BorderSize = 0;
            this.jeanModernButtonExit.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonExit.ForeColor = System.Drawing.Color.Transparent;
            this.jeanModernButtonExit.Location = new System.Drawing.Point(439, 15);
            this.jeanModernButtonExit.Name = "jeanModernButtonExit";
            this.jeanModernButtonExit.Size = new System.Drawing.Size(40, 40);
            this.jeanModernButtonExit.TabIndex = 52;
            this.jeanModernButtonExit.TextColor = System.Drawing.Color.Transparent;
            this.jeanModernButtonExit.UseVisualStyleBackColor = false;
            this.jeanModernButtonExit.Click += new System.EventHandler(this.jeanModernButtonExit_Click);
            // 
            // profile
            // 
            this.profile.AutoSize = true;
            this.profile.BackColor = System.Drawing.SystemColors.HighlightText;
            this.profile.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.profile.Location = new System.Drawing.Point(24, 21);
            this.profile.Name = "profile";
            this.profile.Size = new System.Drawing.Size(126, 29);
            this.profile.TabIndex = 0;
            this.profile.Text = "Профиль";
            // 
            // jeanPanelPerson
            // 
            this.jeanPanelPerson.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.jeanPanelPerson.AutoScroll = true;
            this.jeanPanelPerson.AutoScrollMargin = new System.Drawing.Size(0, 50);
            this.jeanPanelPerson.AutoScrollMinSize = new System.Drawing.Size(30, 30);
            this.jeanPanelPerson.BackColor = System.Drawing.Color.White;
            this.jeanPanelPerson.BorderRadius = 0;
            this.jeanPanelPerson.Controls.Add(this.saved);
            this.jeanPanelPerson.Controls.Add(this.label8);
            this.jeanPanelPerson.Controls.Add(this.visit);
            this.jeanPanelPerson.Controls.Add(this.label17);
            this.jeanPanelPerson.Controls.Add(this.left);
            this.jeanPanelPerson.Controls.Add(this.label7);
            this.jeanPanelPerson.Controls.Add(this.label10);
            this.jeanPanelPerson.Controls.Add(this.membership);
            this.jeanPanelPerson.Controls.Add(this.numberCard);
            this.jeanPanelPerson.Controls.Add(this.label11);
            this.jeanPanelPerson.Controls.Add(this.label14);
            this.jeanPanelPerson.Controls.Add(this.label6);
            this.jeanPanelPerson.Controls.Add(this.label3);
            this.jeanPanelPerson.Controls.Add(this.label5);
            this.jeanPanelPerson.Controls.Add(this.label4);
            this.jeanPanelPerson.Controls.Add(this.id);
            this.jeanPanelPerson.Controls.Add(this.birthday);
            this.jeanPanelPerson.Controls.Add(this.label1);
            this.jeanPanelPerson.Controls.Add(this.pictureBoxPerson);
            this.jeanPanelPerson.Controls.Add(this.email);
            this.jeanPanelPerson.Controls.Add(this.sav);
            this.jeanPanelPerson.Controls.Add(this.number);
            this.jeanPanelPerson.Controls.Add(this.name);
            this.jeanPanelPerson.ForeColor = System.Drawing.Color.Black;
            this.jeanPanelPerson.GradientAngle = 90F;
            this.jeanPanelPerson.GradientBottomColor = System.Drawing.Color.White;
            this.jeanPanelPerson.GradientTapColor = System.Drawing.Color.White;
            this.jeanPanelPerson.Location = new System.Drawing.Point(774, 76);
            this.jeanPanelPerson.Name = "jeanPanelPerson";
            this.jeanPanelPerson.Size = new System.Drawing.Size(493, 681);
            this.jeanPanelPerson.TabIndex = 29;
            this.jeanPanelPerson.Visible = false;
            // 
            // saved
            // 
            this.saved.AutoSize = true;
            this.saved.BackColor = System.Drawing.Color.Transparent;
            this.saved.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.saved.ForeColor = System.Drawing.Color.DimGray;
            this.saved.Location = new System.Drawing.Point(20, 877);
            this.saved.Name = "saved";
            this.saved.Size = new System.Drawing.Size(101, 20);
            this.saved.TabIndex = 74;
            this.saved.Text = "24:04:2012";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(20, 852);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(100, 25);
            this.label8.TabIndex = 75;
            this.label8.Text = "Сохранен";
            // 
            // visit
            // 
            this.visit.AutoSize = true;
            this.visit.BackColor = System.Drawing.Color.Transparent;
            this.visit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.visit.ForeColor = System.Drawing.Color.DimGray;
            this.visit.Location = new System.Drawing.Point(20, 791);
            this.visit.Name = "visit";
            this.visit.Size = new System.Drawing.Size(29, 20);
            this.visit.TabIndex = 36;
            this.visit.Text = "11";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label17.Location = new System.Drawing.Point(213, 538);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(72, 25);
            this.label17.TabIndex = 73;
            this.label17.Text = "Карта";
            // 
            // left
            // 
            this.left.AutoSize = true;
            this.left.BackColor = System.Drawing.Color.Transparent;
            this.left.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.left.ForeColor = System.Drawing.Color.DimGray;
            this.left.Location = new System.Drawing.Point(20, 729);
            this.left.Name = "left";
            this.left.Size = new System.Drawing.Size(101, 20);
            this.left.TabIndex = 35;
            this.left.Text = "07:10:2024";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(20, 766);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(210, 25);
            this.label7.TabIndex = 72;
            this.label7.Text = "Посещений осталось";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(20, 704);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(113, 25);
            this.label10.TabIndex = 71;
            this.label10.Text = "Окончание";
            // 
            // membership
            // 
            this.membership.AutoSize = true;
            this.membership.BackColor = System.Drawing.Color.Transparent;
            this.membership.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.membership.ForeColor = System.Drawing.Color.DimGray;
            this.membership.Location = new System.Drawing.Point(20, 605);
            this.membership.Name = "membership";
            this.membership.Size = new System.Drawing.Size(284, 20);
            this.membership.TabIndex = 5;
            this.membership.Text = "12 Персональных тренировок";
            // 
            // numberCard
            // 
            this.numberCard.AutoSize = true;
            this.numberCard.BackColor = System.Drawing.Color.Transparent;
            this.numberCard.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.numberCard.ForeColor = System.Drawing.Color.DimGray;
            this.numberCard.Location = new System.Drawing.Point(20, 667);
            this.numberCard.Name = "numberCard";
            this.numberCard.Size = new System.Drawing.Size(162, 20);
            this.numberCard.TabIndex = 4;
            this.numberCard.Text = "№ 2000000034567";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(20, 642);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(75, 25);
            this.label11.TabIndex = 70;
            this.label11.Text = "Номер";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.Location = new System.Drawing.Point(20, 580);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(120, 25);
            this.label14.TabIndex = 68;
            this.label14.Text = "Абонемент";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(20, 466);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(161, 25);
            this.label6.TabIndex = 56;
            this.label6.Text = "День рождения";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(20, 1622);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 25);
            this.label3.TabIndex = 55;
            this.label3.Text = "Сохранен";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(20, 404);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 25);
            this.label5.TabIndex = 54;
            this.label5.Text = "Email";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(20, 342);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 25);
            this.label4.TabIndex = 53;
            this.label4.Text = "Телефон";
            // 
            // id
            // 
            this.id.AutoSize = true;
            this.id.BackColor = System.Drawing.Color.Transparent;
            this.id.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.id.ForeColor = System.Drawing.Color.DimGray;
            this.id.Location = new System.Drawing.Point(20, 305);
            this.id.Name = "id";
            this.id.Size = new System.Drawing.Size(36, 20);
            this.id.TabIndex = 51;
            this.id.Text = "943";
            // 
            // birthday
            // 
            this.birthday.AutoSize = true;
            this.birthday.BackColor = System.Drawing.Color.Transparent;
            this.birthday.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.birthday.ForeColor = System.Drawing.Color.DimGray;
            this.birthday.Location = new System.Drawing.Point(20, 491);
            this.birthday.Name = "birthday";
            this.birthday.Size = new System.Drawing.Size(101, 20);
            this.birthday.TabIndex = 37;
            this.birthday.Text = "18:08:2003";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(20, 280);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 25);
            this.label1.TabIndex = 50;
            this.label1.Text = "ID";
            // 
            // pictureBoxPerson
            // 
            this.pictureBoxPerson.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pictureBoxPerson.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxPerson.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxPerson.Image")));
            this.pictureBoxPerson.Location = new System.Drawing.Point(151, 18);
            this.pictureBoxPerson.Name = "pictureBoxPerson";
            this.pictureBoxPerson.Size = new System.Drawing.Size(200, 190);
            this.pictureBoxPerson.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxPerson.TabIndex = 0;
            this.pictureBoxPerson.TabStop = false;
            // 
            // email
            // 
            this.email.AutoSize = true;
            this.email.BackColor = System.Drawing.Color.Transparent;
            this.email.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.email.ForeColor = System.Drawing.Color.DimGray;
            this.email.Location = new System.Drawing.Point(20, 429);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(265, 20);
            this.email.TabIndex = 40;
            this.email.Text = "evgenijpocekutov6@gmail.com";
            // 
            // sav
            // 
            this.sav.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.sav.AutoSize = true;
            this.sav.BackColor = System.Drawing.Color.Transparent;
            this.sav.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.sav.ForeColor = System.Drawing.Color.DimGray;
            this.sav.Location = new System.Drawing.Point(20, 1647);
            this.sav.Name = "sav";
            this.sav.Size = new System.Drawing.Size(101, 20);
            this.sav.TabIndex = 39;
            this.sav.Text = "25:10:2024";
            // 
            // number
            // 
            this.number.AutoSize = true;
            this.number.BackColor = System.Drawing.Color.Transparent;
            this.number.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.number.ForeColor = System.Drawing.Color.DimGray;
            this.number.Location = new System.Drawing.Point(20, 367);
            this.number.Name = "number";
            this.number.Size = new System.Drawing.Size(119, 20);
            this.number.TabIndex = 32;
            this.number.Text = "89135113451";
            // 
            // name
            // 
            this.name.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.name.AutoSize = true;
            this.name.BackColor = System.Drawing.Color.Transparent;
            this.name.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.name.Location = new System.Drawing.Point(124, 217);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(251, 29);
            this.name.TabIndex = 31;
            this.name.Text = "Почекутов Евгений";
            // 
            // dataGridViewClients
            // 
            this.dataGridViewClients.AllowUserToAddRows = false;
            this.dataGridViewClients.AllowUserToDeleteRows = false;
            this.dataGridViewClients.AllowUserToResizeRows = false;
            this.dataGridViewClients.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewClients.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewClients.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewClients.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridViewClients.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(230)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(230)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewClients.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridViewClients.ColumnHeadersHeight = 35;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewClients.DefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridViewClients.EnableHeadersVisualStyles = false;
            this.dataGridViewClients.GridColor = System.Drawing.Color.Black;
            this.dataGridViewClients.Location = new System.Drawing.Point(19, 11);
            this.dataGridViewClients.Name = "dataGridViewClients";
            this.dataGridViewClients.ReadOnly = true;
            this.dataGridViewClients.RowHeadersVisible = false;
            this.dataGridViewClients.RowHeadersWidth = 40;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            this.dataGridViewClients.RowsDefaultCellStyle = dataGridViewCellStyle9;
            this.dataGridViewClients.RowTemplate.Height = 24;
            this.dataGridViewClients.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewClients.Size = new System.Drawing.Size(1234, 731);
            this.dataGridViewClients.TabIndex = 0;
            this.dataGridViewClients.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewClients_CellContentClick);
            // 
            // jeanModernButtonErase
            // 
            this.jeanModernButtonErase.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.jeanModernButtonErase.BackColor = System.Drawing.Color.White;
            this.jeanModernButtonErase.BackgroundColor = System.Drawing.Color.White;
            this.jeanModernButtonErase.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("jeanModernButtonErase.BackgroundImage")));
            this.jeanModernButtonErase.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.jeanModernButtonErase.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.jeanModernButtonErase.BorderRadius = 30;
            this.jeanModernButtonErase.BorderSize = 0;
            this.jeanModernButtonErase.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonErase.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonErase.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonErase.Location = new System.Drawing.Point(786, 46);
            this.jeanModernButtonErase.Name = "jeanModernButtonErase";
            this.jeanModernButtonErase.Size = new System.Drawing.Size(35, 30);
            this.jeanModernButtonErase.TabIndex = 46;
            this.jeanModernButtonErase.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonErase.UseVisualStyleBackColor = false;
            this.jeanModernButtonErase.Visible = false;
            this.jeanModernButtonErase.Click += new System.EventHandler(this.jeanModernButtonErase_Click);
            // 
            // jeanSoftTextBoxSearch
            // 
            this.jeanSoftTextBoxSearch.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.jeanSoftTextBoxSearch.BorderColor = System.Drawing.Color.Black;
            this.jeanSoftTextBoxSearch.BorderFocusColor = System.Drawing.Color.HotPink;
            this.jeanSoftTextBoxSearch.BorderRadius = 15;
            this.jeanSoftTextBoxSearch.BorderSize = 2;
            this.jeanSoftTextBoxSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanSoftTextBoxSearch.Location = new System.Drawing.Point(433, 40);
            this.jeanSoftTextBoxSearch.Margin = new System.Windows.Forms.Padding(4);
            this.jeanSoftTextBoxSearch.Multiline = false;
            this.jeanSoftTextBoxSearch.Name = "jeanSoftTextBoxSearch";
            this.jeanSoftTextBoxSearch.Padding = new System.Windows.Forms.Padding(50, 10, 50, 10);
            this.jeanSoftTextBoxSearch.PasswordChar = false;
            this.jeanSoftTextBoxSearch.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.jeanSoftTextBoxSearch.PlaceholderText = "  Фамилия, Имя или №Карты";
            this.jeanSoftTextBoxSearch.Size = new System.Drawing.Size(393, 41);
            this.jeanSoftTextBoxSearch.TabIndex = 45;
            this.jeanSoftTextBoxSearch.Texts = "";
            this.jeanSoftTextBoxSearch.UnderlinedStyle = false;
            this.jeanSoftTextBoxSearch._TextChanged += new System.EventHandler(this.jeanSoftTextBoxSearch__TextChanged);
            // 
            // jeanModernButtonChangeData
            // 
            this.jeanModernButtonChangeData.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jeanModernButtonChangeData.BackColor = System.Drawing.Color.White;
            this.jeanModernButtonChangeData.BackgroundColor = System.Drawing.Color.White;
            this.jeanModernButtonChangeData.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButtonChangeData.BorderRadius = 20;
            this.jeanModernButtonChangeData.BorderSize = 2;
            this.jeanModernButtonChangeData.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonChangeData.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonChangeData.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonChangeData.ForeColor = System.Drawing.Color.Black;
            this.jeanModernButtonChangeData.Location = new System.Drawing.Point(1092, 13);
            this.jeanModernButtonChangeData.Name = "jeanModernButtonChangeData";
            this.jeanModernButtonChangeData.Size = new System.Drawing.Size(166, 68);
            this.jeanModernButtonChangeData.TabIndex = 44;
            this.jeanModernButtonChangeData.Text = "Исправить данные";
            this.jeanModernButtonChangeData.TextColor = System.Drawing.Color.Black;
            this.jeanModernButtonChangeData.UseVisualStyleBackColor = false;
            this.jeanModernButtonChangeData.Click += new System.EventHandler(this.jeanModernButtonChangeData_Click);
            // 
            // Clients
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1284, 857);
            this.Controls.Add(this.checkBoxPerson);
            this.Controls.Add(this.jeanPanel);
            this.Controls.Add(this.pictureBoxSearch);
            this.Controls.Add(this.jeanModernButtonErase);
            this.Controls.Add(this.jeanSoftTextBoxSearch);
            this.Controls.Add(this.jeanModernButtonChangeData);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Clients";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Клиенты";
            this.Load += new System.EventHandler(this.Clients_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSearch)).EndInit();
            this.jeanPanel.ResumeLayout(false);
            this.jeanPanelProfile.ResumeLayout(false);
            this.jeanPanelProfile.PerformLayout();
            this.jeanPanelPerson.ResumeLayout(false);
            this.jeanPanelPerson.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPerson)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewClients)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        protected internal System.Windows.Forms.DataGridView dataGridViewClients;
        private Controls.JeanModernButton jeanModernButtonChangeData;
        private Controls.JeanModernButton jeanModernButtonErase;
        private System.Windows.Forms.PictureBox pictureBoxSearch;
        protected internal Controls.jeanSoftTextBox jeanSoftTextBoxSearch;
        private Controls.JeanPanel jeanPanel;
        private Controls.JeanPanel jeanPanelPerson;
        public System.Windows.Forms.Label birthday;
        public System.Windows.Forms.Label number;
        public System.Windows.Forms.Label name;
        public System.Windows.Forms.Label sav;
        public System.Windows.Forms.Label email;
        private System.Windows.Forms.CheckBox checkBoxPerson;
        private Controls.JeanPanel jeanPanelProfile;
        private System.Windows.Forms.Label id;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBoxPerson;
        private Controls.JeanModernButton jeanModernButtonExit;
        private System.Windows.Forms.Label profile;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label14;
        public System.Windows.Forms.Label visit;
        public System.Windows.Forms.Label left;
        public System.Windows.Forms.Label membership;
        public System.Windows.Forms.Label numberCard;
        public System.Windows.Forms.Label saved;
        private System.Windows.Forms.Label label8;
    }
}