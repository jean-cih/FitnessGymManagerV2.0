﻿namespace GymApplicationV2._0.FormsClients
{
    partial class Person
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox = new System.Windows.Forms.PictureBox();
            this.jeanPanel1 = new GymApplicationV2._0.Controls.JeanPanel();
            this.namePerson = new System.Windows.Forms.Label();
            this.numberPerson = new System.Windows.Forms.Label();
            this.jeanPanel2 = new GymApplicationV2._0.Controls.JeanPanel();
            this.membershipPerson = new System.Windows.Forms.Label();
            this.numberCard = new System.Windows.Forms.Label();
            this.visitDate = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.left = new System.Windows.Forms.Label();
            this.visit = new System.Windows.Forms.Label();
            this.birthDay = new System.Windows.Forms.Label();
            this.email = new System.Windows.Forms.Label();
            this.saved = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            this.jeanPanel1.SuspendLayout();
            this.jeanPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox
            // 
            this.pictureBox.Image = global::GymApplicationV2._0.Properties.Resources.Person;
            this.pictureBox.Location = new System.Drawing.Point(13, 12);
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.Size = new System.Drawing.Size(270, 269);
            this.pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox.TabIndex = 0;
            this.pictureBox.TabStop = false;
            // 
            // jeanPanel1
            // 
            this.jeanPanel1.BackColor = System.Drawing.Color.White;
            this.jeanPanel1.BorderRadius = 30;
            this.jeanPanel1.Controls.Add(this.pictureBox);
            this.jeanPanel1.ForeColor = System.Drawing.Color.Black;
            this.jeanPanel1.GradientAngle = 90F;
            this.jeanPanel1.GradientBottomColor = System.Drawing.Color.CadetBlue;
            this.jeanPanel1.GradientTapColor = System.Drawing.Color.DodgerBlue;
            this.jeanPanel1.Location = new System.Drawing.Point(38, 27);
            this.jeanPanel1.Name = "jeanPanel1";
            this.jeanPanel1.Size = new System.Drawing.Size(296, 296);
            this.jeanPanel1.TabIndex = 1;
            // 
            // namePerson
            // 
            this.namePerson.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.namePerson.AutoSize = true;
            this.namePerson.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.namePerson.Location = new System.Drawing.Point(65, 341);
            this.namePerson.Name = "namePerson";
            this.namePerson.Size = new System.Drawing.Size(251, 29);
            this.namePerson.TabIndex = 2;
            this.namePerson.Text = "Почекутов Евгений";
            // 
            // numberPerson
            // 
            this.numberPerson.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.numberPerson.AutoSize = true;
            this.numberPerson.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.numberPerson.Location = new System.Drawing.Point(71, 434);
            this.numberPerson.Name = "numberPerson";
            this.numberPerson.Size = new System.Drawing.Size(214, 20);
            this.numberPerson.TabIndex = 3;
            this.numberPerson.Text = "Телефон: 89135113451";
            // 
            // jeanPanel2
            // 
            this.jeanPanel2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.jeanPanel2.BackColor = System.Drawing.Color.White;
            this.jeanPanel2.BorderRadius = 20;
            this.jeanPanel2.Controls.Add(this.membershipPerson);
            this.jeanPanel2.Controls.Add(this.numberCard);
            this.jeanPanel2.ForeColor = System.Drawing.Color.Black;
            this.jeanPanel2.GradientAngle = 90F;
            this.jeanPanel2.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.jeanPanel2.GradientTapColor = System.Drawing.Color.DodgerBlue;
            this.jeanPanel2.Location = new System.Drawing.Point(393, 156);
            this.jeanPanel2.Name = "jeanPanel2";
            this.jeanPanel2.Size = new System.Drawing.Size(317, 167);
            this.jeanPanel2.TabIndex = 1;
            // 
            // membershipPerson
            // 
            this.membershipPerson.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.membershipPerson.AutoSize = true;
            this.membershipPerson.BackColor = System.Drawing.Color.Transparent;
            this.membershipPerson.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.membershipPerson.ForeColor = System.Drawing.Color.White;
            this.membershipPerson.Location = new System.Drawing.Point(19, 31);
            this.membershipPerson.Name = "membershipPerson";
            this.membershipPerson.Size = new System.Drawing.Size(284, 20);
            this.membershipPerson.TabIndex = 5;
            this.membershipPerson.Text = "12 Персональных тренировок";
            // 
            // numberCard
            // 
            this.numberCard.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.numberCard.AutoSize = true;
            this.numberCard.BackColor = System.Drawing.Color.Transparent;
            this.numberCard.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.numberCard.ForeColor = System.Drawing.Color.White;
            this.numberCard.Location = new System.Drawing.Point(86, 87);
            this.numberCard.Name = "numberCard";
            this.numberCard.Size = new System.Drawing.Size(131, 18);
            this.numberCard.TabIndex = 4;
            this.numberCard.Text = "№ 2000000034567";
            // 
            // visitDate
            // 
            this.visitDate.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.visitDate.AutoSize = true;
            this.visitDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.visitDate.Location = new System.Drawing.Point(478, 423);
            this.visitDate.Name = "visitDate";
            this.visitDate.Size = new System.Drawing.Size(192, 20);
            this.visitDate.TabIndex = 4;
            this.visitDate.Text = "Посетил: 25:10:2024";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(632, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "Скидка: 0";
            // 
            // left
            // 
            this.left.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.left.AutoSize = true;
            this.left.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.left.Location = new System.Drawing.Point(458, 341);
            this.left.Name = "left";
            this.left.Size = new System.Drawing.Size(214, 20);
            this.left.TabIndex = 6;
            this.left.Text = "Окончание: 07:10:2024";
            // 
            // visit
            // 
            this.visit.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.visit.AutoSize = true;
            this.visit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.visit.Location = new System.Drawing.Point(487, 378);
            this.visit.Name = "visit";
            this.visit.Size = new System.Drawing.Size(152, 20);
            this.visit.TabIndex = 7;
            this.visit.Text = "Посещений:  11";
            // 
            // birthDay
            // 
            this.birthDay.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.birthDay.AutoSize = true;
            this.birthDay.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.birthDay.Location = new System.Drawing.Point(71, 391);
            this.birthDay.Name = "birthDay";
            this.birthDay.Size = new System.Drawing.Size(258, 20);
            this.birthDay.TabIndex = 8;
            this.birthDay.Text = "День рождения: 18:08:2003";
            // 
            // email
            // 
            this.email.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.email.AutoSize = true;
            this.email.BackColor = System.Drawing.Color.Transparent;
            this.email.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.email.Location = new System.Drawing.Point(80, 474);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(68, 20);
            this.email.TabIndex = 41;
            this.email.Text = "Email: ";
            // 
            // saved
            // 
            this.saved.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.saved.AutoSize = true;
            this.saved.BackColor = System.Drawing.Color.Transparent;
            this.saved.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.saved.Location = new System.Drawing.Point(34, 669);
            this.saved.Name = "saved";
            this.saved.Size = new System.Drawing.Size(201, 20);
            this.saved.TabIndex = 42;
            this.saved.Text = "Сохранен: 25:10:2024";
            // 
            // Person
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(754, 707);
            this.Controls.Add(this.saved);
            this.Controls.Add(this.email);
            this.Controls.Add(this.birthDay);
            this.Controls.Add(this.visit);
            this.Controls.Add(this.left);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.visitDate);
            this.Controls.Add(this.jeanPanel2);
            this.Controls.Add(this.numberPerson);
            this.Controls.Add(this.namePerson);
            this.Controls.Add(this.jeanPanel1);
            this.Name = "Person";
            this.Text = "Person";
            this.Load += new System.EventHandler(this.Person_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            this.jeanPanel1.ResumeLayout(false);
            this.jeanPanel2.ResumeLayout(false);
            this.jeanPanel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox;
        private Controls.JeanPanel jeanPanel1;
        public System.Windows.Forms.Label namePerson;
        public System.Windows.Forms.Label numberPerson;
        private Controls.JeanPanel jeanPanel2;
        public System.Windows.Forms.Label membershipPerson;
        public System.Windows.Forms.Label numberCard;
        public System.Windows.Forms.Label visitDate;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label left;
        public System.Windows.Forms.Label visit;
        public System.Windows.Forms.Label birthDay;
        public System.Windows.Forms.Label email;
        public System.Windows.Forms.Label saved;
    }
}