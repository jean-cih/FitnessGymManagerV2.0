﻿namespace GymApplicationV2._0
{
    partial class InformationReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InformationReport));
            this.dataGridViewShowReport = new System.Windows.Forms.DataGridView();
            this.labelAllClients = new System.Windows.Forms.Label();
            this.labelQuantity = new System.Windows.Forms.Label();
            this.labelShowPeriod = new System.Windows.Forms.Label();
            this.jeanFormStyle = new GymApplicationV2._0.Components.JeanFormStyle(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewShowReport)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewShowReport
            // 
            this.dataGridViewShowReport.AllowUserToAddRows = false;
            this.dataGridViewShowReport.AllowUserToDeleteRows = false;
            this.dataGridViewShowReport.AllowUserToResizeColumns = false;
            this.dataGridViewShowReport.AllowUserToResizeRows = false;
            this.dataGridViewShowReport.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewShowReport.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewShowReport.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewShowReport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewShowReport.Location = new System.Drawing.Point(5, 67);
            this.dataGridViewShowReport.Name = "dataGridViewShowReport";
            this.dataGridViewShowReport.ReadOnly = true;
            this.dataGridViewShowReport.RowHeadersWidth = 51;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            this.dataGridViewShowReport.RowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewShowReport.RowTemplate.Height = 24;
            this.dataGridViewShowReport.Size = new System.Drawing.Size(1115, 526);
            this.dataGridViewShowReport.TabIndex = 0;
            this.dataGridViewShowReport.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewAttendance_CellContentClick);
            // 
            // labelAllClients
            // 
            this.labelAllClients.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.labelAllClients.AutoSize = true;
            this.labelAllClients.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelAllClients.Location = new System.Drawing.Point(32, 610);
            this.labelAllClients.Name = "labelAllClients";
            this.labelAllClients.Size = new System.Drawing.Size(166, 22);
            this.labelAllClients.TabIndex = 16;
            this.labelAllClients.Text = "Всего клиентов: ";
            // 
            // labelQuantity
            // 
            this.labelQuantity.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.labelQuantity.AutoSize = true;
            this.labelQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelQuantity.Location = new System.Drawing.Point(210, 612);
            this.labelQuantity.Name = "labelQuantity";
            this.labelQuantity.Size = new System.Drawing.Size(21, 22);
            this.labelQuantity.TabIndex = 17;
            this.labelQuantity.Text = "0";
            // 
            // labelShowPeriod
            // 
            this.labelShowPeriod.AutoSize = true;
            this.labelShowPeriod.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelShowPeriod.Location = new System.Drawing.Point(31, 21);
            this.labelShowPeriod.Name = "labelShowPeriod";
            this.labelShowPeriod.Size = new System.Drawing.Size(454, 29);
            this.labelShowPeriod.TabIndex = 18;
            this.labelShowPeriod.Text = "Посещения с 20.07.2024 по 21.07.24 ";
            // 
            // jeanFormStyle
            // 
            this.jeanFormStyle.AllowUserResize = false;
            this.jeanFormStyle.BackColor = System.Drawing.Color.White;
            this.jeanFormStyle.ContextMenuForm = null;
            this.jeanFormStyle.ControlBoxButtonsWidth = 20;
            this.jeanFormStyle.EnableControlBoxIconsLight = false;
            this.jeanFormStyle.EnableControlBoxMouseLight = false;
            this.jeanFormStyle.Form = this;
            this.jeanFormStyle.FormStyle = GymApplicationV2._0.Components.JeanFormStyle.fStyle.None;
            this.jeanFormStyle.HeaderColor = System.Drawing.Color.Black;
            this.jeanFormStyle.HeaderColorAdditional = System.Drawing.Color.DarkOrange;
            this.jeanFormStyle.HeaderColorGradientEnable = true;
            this.jeanFormStyle.HeaderColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.jeanFormStyle.HeaderHeight = 30;
            this.jeanFormStyle.HeaderImage = null;
            this.jeanFormStyle.HeaderTextColor = System.Drawing.Color.White;
            this.jeanFormStyle.HeaderTextFont = new System.Drawing.Font("Segoe UI", 9.75F);
            // 
            // InformationReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1123, 714);
            this.Controls.Add(this.labelShowPeriod);
            this.Controls.Add(this.labelQuantity);
            this.Controls.Add(this.labelAllClients);
            this.Controls.Add(this.dataGridViewShowReport);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "InformationReport";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Посещаемость";
            this.Load += new System.EventHandler(this.Attendance_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewShowReport)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewShowReport;
        private System.Windows.Forms.Label labelAllClients;
        private System.Windows.Forms.Label labelQuantity;
        private System.Windows.Forms.Label labelShowPeriod;
        private Components.JeanFormStyle jeanFormStyle;
    }
}