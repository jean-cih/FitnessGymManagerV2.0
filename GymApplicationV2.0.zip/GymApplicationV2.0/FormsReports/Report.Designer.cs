﻿namespace GymApplicationV2._0
{
    partial class Report
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Report));
            this.labelVisited = new System.Windows.Forms.Label();
            this.labelServices = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.checkBoxHistoryPayment = new System.Windows.Forms.CheckBox();
            this.checkBoxSellServices = new System.Windows.Forms.CheckBox();
            this.panelVisited = new System.Windows.Forms.Panel();
            this.radioOtherPeriod = new System.Windows.Forms.RadioButton();
            this.labelTo = new System.Windows.Forms.Label();
            this.checkBoxClientsForPeriod = new System.Windows.Forms.CheckBox();
            this.labelWith = new System.Windows.Forms.Label();
            this.checkBoxAllClients = new System.Windows.Forms.CheckBox();
            this.dateTimePickerEnd = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerBegin = new System.Windows.Forms.DateTimePicker();
            this.radioForWeek = new System.Windows.Forms.RadioButton();
            this.radioForDay = new System.Windows.Forms.RadioButton();
            this.radioForMonth = new System.Windows.Forms.RadioButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.jeanModernButtonExport = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanModernButtonChooseFile = new GymApplicationV2._0.Controls.JeanModernButton();
            this.checkBoxTSV = new System.Windows.Forms.CheckBox();
            this.checkBoxCSV = new System.Windows.Forms.CheckBox();
            this.checkBoxJSON = new System.Windows.Forms.CheckBox();
            this.checkBoxTXT = new System.Windows.Forms.CheckBox();
            this.checkBoxXLS = new System.Windows.Forms.CheckBox();
            this.jeanModernButtonShow = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanFormStyle = new GymApplicationV2._0.Components.JeanFormStyle(this.components);
            this.panel1.SuspendLayout();
            this.panelVisited.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelVisited
            // 
            this.labelVisited.AutoSize = true;
            this.labelVisited.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelVisited.Location = new System.Drawing.Point(15, 37);
            this.labelVisited.Name = "labelVisited";
            this.labelVisited.Size = new System.Drawing.Size(105, 20);
            this.labelVisited.TabIndex = 11;
            this.labelVisited.Text = "Посещения";
            // 
            // labelServices
            // 
            this.labelServices.AutoSize = true;
            this.labelServices.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelServices.Location = new System.Drawing.Point(15, 41);
            this.labelServices.Name = "labelServices";
            this.labelServices.Size = new System.Drawing.Size(188, 20);
            this.labelServices.TabIndex = 12;
            this.labelServices.Text = "Абонементы и услуги";
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.checkBoxHistoryPayment);
            this.panel1.Controls.Add(this.checkBoxSellServices);
            this.panel1.Controls.Add(this.labelServices);
            this.panel1.Location = new System.Drawing.Point(9, 247);
            this.panel1.Margin = new System.Windows.Forms.Padding(5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(449, 268);
            this.panel1.TabIndex = 14;
            // 
            // checkBoxHistoryPayment
            // 
            this.checkBoxHistoryPayment.AutoSize = true;
            this.checkBoxHistoryPayment.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBoxHistoryPayment.Location = new System.Drawing.Point(38, 153);
            this.checkBoxHistoryPayment.Name = "checkBoxHistoryPayment";
            this.checkBoxHistoryPayment.Size = new System.Drawing.Size(188, 24);
            this.checkBoxHistoryPayment.TabIndex = 25;
            this.checkBoxHistoryPayment.Text = "История платежей";
            this.checkBoxHistoryPayment.UseVisualStyleBackColor = true;
            this.checkBoxHistoryPayment.CheckedChanged += new System.EventHandler(this.checkBoxHistoryPayment_CheckedChanged);
            // 
            // checkBoxSellServices
            // 
            this.checkBoxSellServices.AutoSize = true;
            this.checkBoxSellServices.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBoxSellServices.Location = new System.Drawing.Point(38, 96);
            this.checkBoxSellServices.Name = "checkBoxSellServices";
            this.checkBoxSellServices.Size = new System.Drawing.Size(228, 24);
            this.checkBoxSellServices.TabIndex = 24;
            this.checkBoxSellServices.Text = "Количество проданных";
            this.checkBoxSellServices.UseVisualStyleBackColor = true;
            this.checkBoxSellServices.CheckedChanged += new System.EventHandler(this.checkBoxSellServices_CheckedChanged);
            // 
            // panelVisited
            // 
            this.panelVisited.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelVisited.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelVisited.Controls.Add(this.radioOtherPeriod);
            this.panelVisited.Controls.Add(this.labelTo);
            this.panelVisited.Controls.Add(this.checkBoxClientsForPeriod);
            this.panelVisited.Controls.Add(this.labelWith);
            this.panelVisited.Controls.Add(this.checkBoxAllClients);
            this.panelVisited.Controls.Add(this.dateTimePickerEnd);
            this.panelVisited.Controls.Add(this.labelVisited);
            this.panelVisited.Controls.Add(this.dateTimePickerBegin);
            this.panelVisited.Controls.Add(this.radioForWeek);
            this.panelVisited.Controls.Add(this.radioForDay);
            this.panelVisited.Controls.Add(this.radioForMonth);
            this.panelVisited.Location = new System.Drawing.Point(9, 9);
            this.panelVisited.Name = "panelVisited";
            this.panelVisited.Size = new System.Drawing.Size(705, 233);
            this.panelVisited.TabIndex = 20;
            // 
            // radioOtherPeriod
            // 
            this.radioOtherPeriod.AutoSize = true;
            this.radioOtherPeriod.Checked = true;
            this.radioOtherPeriod.Location = new System.Drawing.Point(391, 128);
            this.radioOtherPeriod.Name = "radioOtherPeriod";
            this.radioOtherPeriod.Size = new System.Drawing.Size(126, 20);
            this.radioOtherPeriod.TabIndex = 27;
            this.radioOtherPeriod.TabStop = true;
            this.radioOtherPeriod.Text = "Другой период";
            this.radioOtherPeriod.UseVisualStyleBackColor = true;
            // 
            // labelTo
            // 
            this.labelTo.AutoSize = true;
            this.labelTo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelTo.Location = new System.Drawing.Point(516, 161);
            this.labelTo.Name = "labelTo";
            this.labelTo.Size = new System.Drawing.Size(29, 20);
            this.labelTo.TabIndex = 26;
            this.labelTo.Text = "по";
            // 
            // checkBoxClientsForPeriod
            // 
            this.checkBoxClientsForPeriod.AutoSize = true;
            this.checkBoxClientsForPeriod.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBoxClientsForPeriod.Location = new System.Drawing.Point(38, 137);
            this.checkBoxClientsForPeriod.Name = "checkBoxClientsForPeriod";
            this.checkBoxClientsForPeriod.Size = new System.Drawing.Size(232, 24);
            this.checkBoxClientsForPeriod.TabIndex = 22;
            this.checkBoxClientsForPeriod.Text = "Посещаемость по дням";
            this.checkBoxClientsForPeriod.UseVisualStyleBackColor = true;
            this.checkBoxClientsForPeriod.CheckedChanged += new System.EventHandler(this.checkBoxClientsForPeriod_CheckedChanged);
            // 
            // labelWith
            // 
            this.labelWith.AutoSize = true;
            this.labelWith.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelWith.Location = new System.Drawing.Point(370, 161);
            this.labelWith.Name = "labelWith";
            this.labelWith.Size = new System.Drawing.Size(18, 20);
            this.labelWith.TabIndex = 20;
            this.labelWith.Text = "с";
            // 
            // checkBoxAllClients
            // 
            this.checkBoxAllClients.AutoSize = true;
            this.checkBoxAllClients.Checked = true;
            this.checkBoxAllClients.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxAllClients.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBoxAllClients.Location = new System.Drawing.Point(38, 84);
            this.checkBoxAllClients.Name = "checkBoxAllClients";
            this.checkBoxAllClients.Size = new System.Drawing.Size(138, 24);
            this.checkBoxAllClients.TabIndex = 21;
            this.checkBoxAllClients.Text = "Все клиенты";
            this.checkBoxAllClients.UseVisualStyleBackColor = true;
            this.checkBoxAllClients.CheckedChanged += new System.EventHandler(this.checkBoxAllClients_CheckedChanged);
            // 
            // dateTimePickerEnd
            // 
            this.dateTimePickerEnd.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerEnd.Location = new System.Drawing.Point(558, 161);
            this.dateTimePickerEnd.MaxDate = new System.DateTime(2100, 12, 31, 0, 0, 0, 0);
            this.dateTimePickerEnd.MinDate = new System.DateTime(2022, 1, 1, 0, 0, 0, 0);
            this.dateTimePickerEnd.Name = "dateTimePickerEnd";
            this.dateTimePickerEnd.Size = new System.Drawing.Size(109, 22);
            this.dateTimePickerEnd.TabIndex = 25;
            // 
            // dateTimePickerBegin
            // 
            this.dateTimePickerBegin.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerBegin.Location = new System.Drawing.Point(398, 161);
            this.dateTimePickerBegin.MaxDate = new System.DateTime(2100, 12, 31, 0, 0, 0, 0);
            this.dateTimePickerBegin.MinDate = new System.DateTime(2022, 1, 1, 0, 0, 0, 0);
            this.dateTimePickerBegin.Name = "dateTimePickerBegin";
            this.dateTimePickerBegin.Size = new System.Drawing.Size(109, 22);
            this.dateTimePickerBegin.TabIndex = 24;
            // 
            // radioForWeek
            // 
            this.radioForWeek.AutoSize = true;
            this.radioForWeek.Location = new System.Drawing.Point(391, 68);
            this.radioForWeek.Name = "radioForWeek";
            this.radioForWeek.Size = new System.Drawing.Size(98, 20);
            this.radioForWeek.TabIndex = 23;
            this.radioForWeek.Text = "За неделю";
            this.radioForWeek.UseVisualStyleBackColor = true;
            // 
            // radioForDay
            // 
            this.radioForDay.AutoSize = true;
            this.radioForDay.Location = new System.Drawing.Point(391, 98);
            this.radioForDay.Name = "radioForDay";
            this.radioForDay.Size = new System.Drawing.Size(79, 20);
            this.radioForDay.TabIndex = 22;
            this.radioForDay.Text = "За день";
            this.radioForDay.UseVisualStyleBackColor = true;
            // 
            // radioForMonth
            // 
            this.radioForMonth.AutoSize = true;
            this.radioForMonth.Location = new System.Drawing.Point(391, 38);
            this.radioForMonth.Name = "radioForMonth";
            this.radioForMonth.Size = new System.Drawing.Size(87, 20);
            this.radioForMonth.TabIndex = 21;
            this.radioForMonth.Text = "За месяц";
            this.radioForMonth.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.jeanModernButtonExport);
            this.panel2.Controls.Add(this.jeanModernButtonChooseFile);
            this.panel2.Controls.Add(this.checkBoxTSV);
            this.panel2.Controls.Add(this.checkBoxCSV);
            this.panel2.Controls.Add(this.checkBoxJSON);
            this.panel2.Controls.Add(this.checkBoxTXT);
            this.panel2.Controls.Add(this.checkBoxXLS);
            this.panel2.Location = new System.Drawing.Point(720, 9);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(329, 233);
            this.panel2.TabIndex = 21;
            // 
            // jeanModernButtonExport
            // 
            this.jeanModernButtonExport.BackColor = System.Drawing.Color.White;
            this.jeanModernButtonExport.BackgroundColor = System.Drawing.Color.White;
            this.jeanModernButtonExport.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButtonExport.BorderRadius = 20;
            this.jeanModernButtonExport.BorderSize = 2;
            this.jeanModernButtonExport.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonExport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonExport.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonExport.ForeColor = System.Drawing.Color.Black;
            this.jeanModernButtonExport.Location = new System.Drawing.Point(167, 161);
            this.jeanModernButtonExport.Name = "jeanModernButtonExport";
            this.jeanModernButtonExport.Size = new System.Drawing.Size(145, 60);
            this.jeanModernButtonExport.TabIndex = 46;
            this.jeanModernButtonExport.Text = "Экспортировать";
            this.jeanModernButtonExport.TextColor = System.Drawing.Color.Black;
            this.jeanModernButtonExport.UseVisualStyleBackColor = false;
            this.jeanModernButtonExport.Click += new System.EventHandler(this.jeanModernButtonExport_Click);
            // 
            // jeanModernButtonChooseFile
            // 
            this.jeanModernButtonChooseFile.BackColor = System.Drawing.Color.White;
            this.jeanModernButtonChooseFile.BackgroundColor = System.Drawing.Color.White;
            this.jeanModernButtonChooseFile.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButtonChooseFile.BorderRadius = 20;
            this.jeanModernButtonChooseFile.BorderSize = 2;
            this.jeanModernButtonChooseFile.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonChooseFile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonChooseFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonChooseFile.ForeColor = System.Drawing.Color.Black;
            this.jeanModernButtonChooseFile.Location = new System.Drawing.Point(16, 161);
            this.jeanModernButtonChooseFile.Name = "jeanModernButtonChooseFile";
            this.jeanModernButtonChooseFile.Size = new System.Drawing.Size(145, 60);
            this.jeanModernButtonChooseFile.TabIndex = 45;
            this.jeanModernButtonChooseFile.Text = "Выбрать";
            this.jeanModernButtonChooseFile.TextColor = System.Drawing.Color.Black;
            this.jeanModernButtonChooseFile.UseVisualStyleBackColor = false;
            this.jeanModernButtonChooseFile.Click += new System.EventHandler(this.jeanModernButtonChooseFile_Click);
            // 
            // checkBoxTSV
            // 
            this.checkBoxTSV.AutoSize = true;
            this.checkBoxTSV.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBoxTSV.Location = new System.Drawing.Point(125, 63);
            this.checkBoxTSV.Name = "checkBoxTSV";
            this.checkBoxTSV.Size = new System.Drawing.Size(57, 24);
            this.checkBoxTSV.TabIndex = 32;
            this.checkBoxTSV.Text = ".tsv";
            this.checkBoxTSV.UseVisualStyleBackColor = true;
            this.checkBoxTSV.CheckedChanged += new System.EventHandler(this.checkBoxTSV_CheckedChanged);
            // 
            // checkBoxCSV
            // 
            this.checkBoxCSV.AutoSize = true;
            this.checkBoxCSV.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBoxCSV.Location = new System.Drawing.Point(125, 33);
            this.checkBoxCSV.Name = "checkBoxCSV";
            this.checkBoxCSV.Size = new System.Drawing.Size(61, 24);
            this.checkBoxCSV.TabIndex = 31;
            this.checkBoxCSV.Text = ".csv";
            this.checkBoxCSV.UseVisualStyleBackColor = true;
            this.checkBoxCSV.CheckedChanged += new System.EventHandler(this.checkBoxCSV_CheckedChanged);
            // 
            // checkBoxJSON
            // 
            this.checkBoxJSON.AutoSize = true;
            this.checkBoxJSON.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBoxJSON.Location = new System.Drawing.Point(43, 97);
            this.checkBoxJSON.Name = "checkBoxJSON";
            this.checkBoxJSON.Size = new System.Drawing.Size(66, 24);
            this.checkBoxJSON.TabIndex = 30;
            this.checkBoxJSON.Text = ".json";
            this.checkBoxJSON.UseVisualStyleBackColor = true;
            this.checkBoxJSON.CheckedChanged += new System.EventHandler(this.checkBoxJSON_CheckedChanged);
            // 
            // checkBoxTXT
            // 
            this.checkBoxTXT.AutoSize = true;
            this.checkBoxTXT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBoxTXT.Location = new System.Drawing.Point(43, 67);
            this.checkBoxTXT.Name = "checkBoxTXT";
            this.checkBoxTXT.Size = new System.Drawing.Size(53, 24);
            this.checkBoxTXT.TabIndex = 29;
            this.checkBoxTXT.Text = ".txt";
            this.checkBoxTXT.UseVisualStyleBackColor = true;
            this.checkBoxTXT.CheckedChanged += new System.EventHandler(this.checkBoxTXT_CheckedChanged);
            // 
            // checkBoxXLS
            // 
            this.checkBoxXLS.AutoSize = true;
            this.checkBoxXLS.Checked = true;
            this.checkBoxXLS.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxXLS.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBoxXLS.Location = new System.Drawing.Point(43, 33);
            this.checkBoxXLS.Name = "checkBoxXLS";
            this.checkBoxXLS.Size = new System.Drawing.Size(56, 24);
            this.checkBoxXLS.TabIndex = 28;
            this.checkBoxXLS.Text = ".xls";
            this.checkBoxXLS.UseVisualStyleBackColor = true;
            this.checkBoxXLS.CheckedChanged += new System.EventHandler(this.checkBoxXLS_CheckedChanged);
            // 
            // jeanModernButtonShow
            // 
            this.jeanModernButtonShow.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jeanModernButtonShow.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonShow.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanModernButtonShow.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButtonShow.BorderRadius = 20;
            this.jeanModernButtonShow.BorderSize = 2;
            this.jeanModernButtonShow.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonShow.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonShow.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonShow.Location = new System.Drawing.Point(704, 452);
            this.jeanModernButtonShow.Name = "jeanModernButtonShow";
            this.jeanModernButtonShow.Size = new System.Drawing.Size(150, 63);
            this.jeanModernButtonShow.TabIndex = 52;
            this.jeanModernButtonShow.Text = "Показать";
            this.jeanModernButtonShow.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonShow.UseVisualStyleBackColor = false;
            this.jeanModernButtonShow.Click += new System.EventHandler(this.buttonShow_Click);
            // 
            // jeanFormStyle
            // 
            this.jeanFormStyle.AllowUserResize = false;
            this.jeanFormStyle.BackColor = System.Drawing.Color.White;
            this.jeanFormStyle.ContextMenuForm = null;
            this.jeanFormStyle.ControlBoxButtonsWidth = 20;
            this.jeanFormStyle.EnableControlBoxIconsLight = false;
            this.jeanFormStyle.EnableControlBoxMouseLight = false;
            this.jeanFormStyle.Form = this;
            this.jeanFormStyle.FormStyle = GymApplicationV2._0.Components.JeanFormStyle.fStyle.None;
            this.jeanFormStyle.HeaderColor = System.Drawing.Color.Black;
            this.jeanFormStyle.HeaderColorAdditional = System.Drawing.Color.DarkOrange;
            this.jeanFormStyle.HeaderColorGradientEnable = true;
            this.jeanFormStyle.HeaderColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.jeanFormStyle.HeaderHeight = 30;
            this.jeanFormStyle.HeaderImage = null;
            this.jeanFormStyle.HeaderTextColor = System.Drawing.Color.White;
            this.jeanFormStyle.HeaderTextFont = new System.Drawing.Font("Segoe UI", 9.75F);
            // 
            // Report
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1061, 585);
            this.Controls.Add(this.jeanModernButtonShow);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panelVisited);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Report";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Отчет";
            this.Load += new System.EventHandler(this.Report_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelVisited.ResumeLayout(false);
            this.panelVisited.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label labelVisited;
        private System.Windows.Forms.Label labelServices;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panelVisited;
        private System.Windows.Forms.RadioButton radioForMonth;
        private System.Windows.Forms.RadioButton radioOtherPeriod;
        private System.Windows.Forms.Label labelTo;
        private System.Windows.Forms.Label labelWith;
        private System.Windows.Forms.DateTimePicker dateTimePickerEnd;
        private System.Windows.Forms.DateTimePicker dateTimePickerBegin;
        private System.Windows.Forms.RadioButton radioForWeek;
        private System.Windows.Forms.RadioButton radioForDay;
        private System.Windows.Forms.CheckBox checkBoxClientsForPeriod;
        private System.Windows.Forms.CheckBox checkBoxAllClients;
        private System.Windows.Forms.CheckBox checkBoxSellServices;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.CheckBox checkBoxJSON;
        private System.Windows.Forms.CheckBox checkBoxTXT;
        private System.Windows.Forms.CheckBox checkBoxXLS;
        private System.Windows.Forms.CheckBox checkBoxTSV;
        private System.Windows.Forms.CheckBox checkBoxCSV;
        private Controls.JeanModernButton jeanModernButtonChooseFile;
        private Controls.JeanModernButton jeanModernButtonExport;
        protected internal Controls.JeanModernButton jeanModernButtonShow;
        private System.Windows.Forms.CheckBox checkBoxHistoryPayment;
        private Components.JeanFormStyle jeanFormStyle;
    }
}