﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymApplicationV2._0
{
    public partial class FieldForService : Form
    {
        public FieldForService()
        {
            InitializeComponent();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            if (textName.Text == "" || textCost.Text == "" || textTermAction.Text == "")
            {
                Message.MessageWindowOk("Незаполненные поля");
 
                return;
            }

            if (textName.Text.Length > 100 || textCost.Text.Length > 20 || (textQuantity.Text != "" && textQuantity.Text.Length > 20))
            {
                Message.MessageWindowOk("Превышен лимит количества символов");

                return;
            }

            if (!int.TryParse(textTermAction.Text, out int term) || term < 0 || !int.TryParse(textCost.Text, out int cost) || cost < 0 || ((!int.TryParse(textQuantity.Text, out int quantity) || quantity < 0) && textQuantity.Text != ""))
            {
                Message.MessageWindowOk("Поля \"Цена\", \"Срок\" и \"Кол-во\" должны быть положительными числами");

                return;
            }

            object maxId;
            using (SQLiteConnection conn = new SQLiteConnection(ServicesContext.ConnectionStringServices()))
            {
                string commandString = "SELECT MAX(Id) FROM Descriptions";
                using (SQLiteCommand cmd = new SQLiteCommand(commandString, conn))
                {
                    conn.Open();

                    maxId = cmd.ExecuteScalar();
                }
            }

            int number;

            if (maxId.ToString() == "")
                number = 1;
            else
                number = Convert.ToInt32(maxId) + 1;


            using (SQLiteConnection conn = new SQLiteConnection(ServicesContext.ConnectionStringServices()))
            {
                string commandString = "INSERT INTO Descriptions ([Id],[Наименование],[Цена],[СрокДействия],[Количество],[ПроданныхЗаМесяц]) VALUES (@Id,@Наименование,@Цена,@СрокДействия,@Количество,@ПроданныхЗаМесяц)";
                using (SQLiteCommand cmd = new SQLiteCommand(commandString, conn))
                {
                    conn.Open();
                    cmd.Parameters.AddWithValue("@Id", number.ToString());
                    cmd.Parameters.AddWithValue("@Наименование", textName.Text);
                    cmd.Parameters.AddWithValue("@Цена", textCost.Text);
                    cmd.Parameters.AddWithValue("@СрокДействия", textTermAction.Text);
                    cmd.Parameters.AddWithValue("@Количество", textQuantity.Text);
                    cmd.Parameters.AddWithValue("@ПроданныхЗаМесяц", 0);

                    cmd.ExecuteNonQuery();
                }
            }

            Services service = new Services();
            service.Show();
            this.Close();
        }
    }
}
