﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace GymApplicationV2._0
{
    public partial class ChooseClient : Form
    {
        public ChooseClient()
        {
            InitializeComponent();
        }

        private void ChooseClient_Load(object sender, EventArgs e)
        {
            if (!File.Exists("Databases\\Clients.db"))
            {
                ClientsContext.CreatingDatabase();
            }
            else
            {
                dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts");
            }

            jeanModernButtonRefresh.Font = new System.Drawing.Font("Обновить", DataClass.sizeFontButtons);
            jeanModernButtonChoose.Font = new System.Drawing.Font("Выбрать", DataClass.sizeFontButtons);

            dataGridViewClients.DefaultCellStyle.Font = new System.Drawing.Font("Contacts", DataClass.sizeFontTables);
            dataGridViewClients.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Contacts", DataClass.sizeFontTables);

            labelSearch.Font = new System.Drawing.Font("Импортировать данные", DataClass.sizeFontCaptions);
        }

        private void textSearch_TextChanged(object sender, EventArgs e)
        {
            if (textSearch.Text == "")
            {
                dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts");
                return;
            }

            dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase($"" +
                $"SELECT * " +
                $"FROM Contacts " +
                $"WHERE №Карты LIKE '%{textSearch.Text}%' " +
                $"OR Фамилия LIKE '%{textSearch.Text}%' " +
                $"OR Имя LIKE '%{textSearch.Text} {textSearch.Text}%'");
        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            textSearch.Text = "";
            dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts");
        }


        string name = "", surname = "", numberCard = "";

        private void jeanModernButtonRefresh_Click(object sender, EventArgs e)
        {
            textSearch.Text = "";
            dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts");
        }

        private void dataGridViewClients_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            surname = dataGridViewClients.SelectedRows[0].Cells[1].Value.ToString();
            name = dataGridViewClients.SelectedRows[0].Cells[2].Value.ToString();
            numberCard = dataGridViewClients.SelectedRows[0].Cells[5].Value.ToString();

            jeanModernButtonChoose.Text = "Выбрать\n " + surname + " " + name;

        }
        private void buttonChoose_Click(object sender, EventArgs e)
        {
            if(name == "" || surname == "" || numberCard == "")
            {
                Message.MessageWindowOk("Выберете клиента");
                return;
            }


            Services services = new Services();
            services.Show();
            services.jeanModernButtonAdd.Visible = true;
            services.jeanModernButtonAdd.Visible = false;
            services.jeanModernButtonDelete.Visible = false;
            services.labelName.Visible = true;
            services.jeanTextBoxPurchase.Visible = true;
            services.labelName.Text = name + " " + surname;
            services.labelNumberCard.Text = numberCard;
            services.labelNumberCard.Visible = true;
            services.checkBoxVisited.Visible = true;

            this.Close();
        }

    }
}
