﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Office.Interop.Excel;
using System.Text.Json;
using static System.Net.Mime.MediaTypeNames;
using System.Text.Json.Nodes;
using System.Data.Entity.Infrastructure;

namespace GymApplicationV2._0
{
    public partial class Report : Form
    {
        private string dbFilePath = "";
        private string itemClients = "Clients.db";
        private string itemServices = "Services.db";
        string quantity = "";

        SplashScreen splashScreen = new SplashScreen();

        public Report()
        {
            InitializeComponent();
        }

        private void Report_Load(object sender, EventArgs e)
        {
            DataClass.AllClients = true;
            jeanModernButtonChooseFile.Font = new System.Drawing.Font("Выбрать файл", DataClass.sizeFontButtons);
            jeanModernButtonExport.Font = new System.Drawing.Font("Экспортировать файл", DataClass.sizeFontButtons);
            jeanModernButtonShow.Font = new System.Drawing.Font("Показать", DataClass.sizeFontButtons);

            labelVisited.Font = new System.Drawing.Font("Посещения", DataClass.sizeFontCaptions);
            checkBoxAllClients.Font = new System.Drawing.Font("Все клиенты", DataClass.sizeFontCaptions);
            checkBoxClientsForPeriod.Font = new System.Drawing.Font("Посещаемость по дням", DataClass.sizeFontCaptions);
            
            labelServices.Font = new System.Drawing.Font("Абонементы и услуги", DataClass.sizeFontCaptions);
            checkBoxSellServices.Font = new System.Drawing.Font("Количество проданных", DataClass.sizeFontCaptions);
            
            radioForMonth.Font = new System.Drawing.Font("За месяц", DataClass.sizeFontCaptions - 2);
            radioForWeek.Font = new System.Drawing.Font("За неделю", DataClass.sizeFontCaptions - 2);
            radioForDay.Font = new System.Drawing.Font("За день", DataClass.sizeFontCaptions - 2);
            radioOtherPeriod.Font = new System.Drawing.Font("Другой период", DataClass.sizeFontCaptions - 2);
            labelWith.Font = new System.Drawing.Font("с", DataClass.sizeFontCaptions);
            labelTo.Font = new System.Drawing.Font("по", DataClass.sizeFontCaptions);

            checkBoxXLS.Font = new System.Drawing.Font(".xls", DataClass.sizeFontCaptions);
            checkBoxTXT.Font = new System.Drawing.Font("txt", DataClass.sizeFontCaptions);
            checkBoxJSON.Font = new System.Drawing.Font(".json", DataClass.sizeFontCaptions);
            checkBoxCSV.Font = new System.Drawing.Font(".csv", DataClass.sizeFontCaptions);
            checkBoxTSV.Font = new System.Drawing.Font(".tsv", DataClass.sizeFontCaptions);
        }

        private void buttonShow_Click(object sender, EventArgs e)
        {
            DataClass.Begin = dateTimePickerBegin.Value;
            DataClass.End = dateTimePickerEnd.Value;

            DataClass.PeriodForMonth = radioForMonth.Checked;
            DataClass.PeriodForWeek = radioForWeek.Checked;
            DataClass.PeriodForDay = radioForDay.Checked;

            DataClass.AllClients = checkBoxAllClients.Checked;
            DataClass.ClientsForPeriod = checkBoxClientsForPeriod.Checked;
            DataClass.SellServices = checkBoxSellServices.Checked;

            InformationReport showReport = new InformationReport();
            showReport.Show();
        }

        private void checkBoxClientsForPeriod_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxClientsForPeriod.Checked)
            {
                checkBoxAllClients.Checked = false;
                checkBoxSellServices.Checked = false;
            }
        }

        private void checkBoxAllClients_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxAllClients.Checked)
            {
                checkBoxClientsForPeriod.Checked = false;
                checkBoxSellServices.Checked = false;
            }
        }

        private void checkBoxSellServices_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxSellServices.Checked)
            {
                checkBoxClientsForPeriod.Checked = false;
                checkBoxAllClients.Checked = false;
            }
        }

        private void UpdateLoadingScreen(string message)
        {
            splashScreen.labelCountImport.Text = message;
        }

        private void ExportFileInXLS(string excelFilePath, string sqlQuery, string file, string query, string quantity, IProgress<string> progress)
        {
            progress.Report("    Подготовление    ");

            SQLiteConnection conn = new SQLiteConnection(query);
            conn.Open();

            SQLiteCommand cmd = new SQLiteCommand(sqlQuery, conn);
            SQLiteDataReader reader = cmd.ExecuteReader();

            Microsoft.Office.Interop.Excel.Application excelApp = new Microsoft.Office.Interop.Excel.Application();
            Workbook workbook = excelApp.Workbooks.Add();
            Worksheet worksheet = (Worksheet)workbook.Worksheets[1];

            int row = 1;
            int j = 1;
            while (reader.Read())
            {
                progress.Report($"Компонентов: {j}/{quantity}");
                for (int i = 0; i < reader.FieldCount; i++)
                {
                    worksheet.Cells[row, i + 1].Value2 = reader[i];
                }
                row++;
                j++;
            }

            workbook.SaveAs(excelFilePath);

            reader.Close();
            cmd.Dispose();
            conn.Close();
            workbook.Close();
            excelApp.Quit();
        }

        private void ExportFileInTXT(string txtFilePath, string sqlQuery, string file, string query)
        {
            if (File.Exists(txtFilePath))
            {
                Message.MessageWindowOk("Файл уже экспортирован");
                return;
            }
            SQLiteConnection conn = new SQLiteConnection(query);
            conn.Open();

            SQLiteCommand cmd = new SQLiteCommand(sqlQuery, conn);
            SQLiteDataReader reader = cmd.ExecuteReader();

            int numberSpace = 20;
            using (StreamWriter writer = new StreamWriter(txtFilePath))
            {
                for (int i = 0; i < reader.FieldCount; i++)
                {
                    string columnName = reader.GetName(i);
                    if(i < 1)
                    {
                        numberSpace = 3;
                    }
                    else if (i < 2)
                    {
                        numberSpace = 30;
                    }
                    else if(i < 6)
                    {
                        numberSpace = 15;
                    }
                    else if (i < 8)
                    {
                        numberSpace = 20;
                    }
                    else if(i < 9)
                    {
                        numberSpace = 30;
                    }
                    else
                    {
                        numberSpace = 8;
                    }
                    writer.Write(columnName.PadRight(numberSpace) + "|");
                }
                writer.WriteLine();

                while (reader.Read())
                {
                    for(int i = 0; i < reader.FieldCount; i++)
                    {
                        string fieldValue = reader[i].ToString();
                        if (i < 1)
                        {
                            numberSpace = 3;
                        }
                        else if (i < 2)
                        {
                            numberSpace = 30;
                        }
                        else if (i < 6)
                        {
                            numberSpace = 15;
                        }
                        else if (i < 8)
                        {
                            numberSpace = 20;
                        }
                        else if (i < 9)
                        {
                            numberSpace = 30;
                        }
                        else
                        {
                            numberSpace = 8;
                        }
                        writer.Write(fieldValue.PadRight(numberSpace) + "|");
                    }
                    writer.WriteLine();
                }
            }

            reader.Close();
            cmd.Dispose();
            conn.Close();

            Message.MessageWindowOk($"Файл {file} экспортирован в формат .txt");
        }

        private void ExportFileInJSON(string jsonFilePath, string sqlQuery, string file, string query)
        {
            if (File.Exists(jsonFilePath))
            {
                Message.MessageWindowOk("Файл уже экспортирован");
                return;
            }
            SQLiteConnection conn = new SQLiteConnection(query);
            conn.Open();

            SQLiteCommand cmd = new SQLiteCommand(sqlQuery, conn);
            SQLiteDataReader reader = cmd.ExecuteReader();

            var jsonArray = new JsonArray();
            while (reader.Read())
            {
                var jsonObject = new JsonObject();
                for (int i = 0; i < reader.FieldCount; i++)
                {
                    jsonObject.Add(reader.GetName(i), JsonSerializer.Serialize(reader[i]));
                }
                jsonArray.Add(jsonObject);
            }

            string jsonString = JsonSerializer.Serialize(jsonArray);
            File.WriteAllText(jsonFilePath, jsonString);

            reader.Close();
            cmd.Dispose();
            conn.Close();

            Message.MessageWindowOk($"Файл {file} экспортирован в формат .json");
        }

        private void ExportFileInCSV(string csvFilePath, string sqlQuery, string file, string query)
        {
            if (File.Exists(csvFilePath))
            {
                Message.MessageWindowOk("Файл уже экспортирован");
                return;
            }
            SQLiteConnection conn = new SQLiteConnection(query);
            conn.Open();

            SQLiteCommand cmd = new SQLiteCommand(sqlQuery, conn);
            SQLiteDataReader reader = cmd.ExecuteReader();

            using(StreamWriter writer = new StreamWriter(csvFilePath))
            {
                for(int i = 0; i < reader.FieldCount; i++)
                {
                    writer.Write(reader.GetName(i));
                    if(i < reader.FieldCount - 1)
                    {
                        writer.Write(";");
                    }
                }
                writer.WriteLine();

                while (reader.Read())
                {
                    for(int i = 0; i < reader.FieldCount; i++)
                    {
                        writer.Write(reader[i]);
                        if (i < reader.FieldCount - 1)
                        {
                            writer.Write(";");
                        }
                    }
                    writer.WriteLine();
                }
            }

            reader.Close();
            cmd.Dispose();
            conn.Close();

            Message.MessageWindowOk($"Файл {file} экспортирован в формат .csv");
        }

        private void ExportFileInTSV(string tsvFilePath, string sqlQuery, string file, string query)
        {
            if (File.Exists(tsvFilePath))
            {
                Message.MessageWindowOk("Файл уже экспортирован");
                return;
            }
            SQLiteConnection conn = new SQLiteConnection(query);
            conn.Open();

            SQLiteCommand cmd = new SQLiteCommand(sqlQuery, conn);
            SQLiteDataReader reader = cmd.ExecuteReader();

            using (StreamWriter writer = new StreamWriter(tsvFilePath))
            {
                for (int i = 0; i < reader.FieldCount; i++)
                {
                    writer.Write(reader.GetName(i));
                    if (i < reader.FieldCount - 1)
                    {
                        writer.Write("\t");
                    }
                }
                writer.WriteLine();

                while (reader.Read())
                {
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        writer.Write(reader[i]);
                        if (i < reader.FieldCount - 1)
                        {
                            writer.Write("\t");
                        }
                    }
                    writer.WriteLine();
                }
            }

            reader.Close();
            cmd.Dispose();
            conn.Close();

            Message.MessageWindowOk($"Файл {file} экспортирован в формат .tsv");
        }

        private void checkBoxXLS_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxXLS.Checked)
            {
                checkBoxTXT.Checked = false;
                checkBoxJSON.Checked = false;
                checkBoxCSV.Checked = false;
                checkBoxTSV.Checked = false;
            }
        }

        private void checkBoxTXT_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxTXT.Checked)
            {
                checkBoxXLS.Checked = false;
                checkBoxJSON.Checked = false;
                checkBoxCSV.Checked = false;
                checkBoxTSV.Checked = false;
            }
        }

        private void checkBoxJSON_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxJSON.Checked)
            {
                checkBoxTXT.Checked = false;
                checkBoxXLS.Checked = false;
                checkBoxCSV.Checked = false;
                checkBoxTSV.Checked = false;
            }
        }

        private void checkBoxCSV_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxCSV.Checked)
            {
                checkBoxTXT.Checked = false;
                checkBoxXLS.Checked = false;
                checkBoxJSON.Checked = false;
                checkBoxTSV.Checked = false;
            }
        }

        private void checkBoxTSV_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxTSV.Checked)
            {
                checkBoxTXT.Checked = false;
                checkBoxXLS.Checked = false;
                checkBoxJSON.Checked = false;
                checkBoxCSV.Checked = false;
            }
        }

        private void jeanModernButtonRefresh_Click(object sender, EventArgs e)
        {
            var openFileDialog = new OpenFileDialog()
            {
                Filter = "Database | *.db;"
            };

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                dbFilePath = openFileDialog.FileName;
            }
        }

        private void jeanModernButtonChooseFile_Click(object sender, EventArgs e)
        {
            var openFileDialog = new OpenFileDialog()
            {
                Filter = "Database | *.db;"
            };

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                dbFilePath = openFileDialog.FileName;
            }
        }

        private async void jeanModernButtonExport_Click(object sender, EventArgs e)
        {
            if (dbFilePath == "")
            {
                Message.MessageWindowOk("Файл не выбран");
                return;
            }

            string finallyFilePath, sqlQuery, file, query;
            if (Regex.IsMatch(dbFilePath, $"\\b{itemClients}\\b"))
            {
                finallyFilePath = @"D:\Development\C#\WinForms\GymApplicationV2.0\bin\Debug\Databases\Clients";
                sqlQuery = "SELECT * FROM Contacts";
                file = itemClients;
                query = ClientsContext.ConnectionStringClients();
                quantity = ClientsContext.GetElementClient("SELECT COUNT(*) FROM Contacts").ToString();
            }
            else if (Regex.IsMatch(dbFilePath, $"\\b{itemServices}\\b"))
            {
                finallyFilePath = @"D:\Development\C#\WinForms\GymApplicationV2.0\bin\Debug\Databases\Services";
                sqlQuery = "SELECT * FROM Descriptions";
                file = itemServices;
                query = ServicesContext.ConnectionStringServices();
                quantity = ServicesContext.GetElementService("SELECT COUNT(*) FROM Descriptions").ToString();
            }
            else
            {
                Message.MessageWindowOk("Некорректный файл");
                return;
            }

            if (checkBoxXLS.Checked)
            {
                if (File.Exists(finallyFilePath + ".xls"))
                {
                    Message.MessageWindowOk("Файл уже экспортирован");
                    return;
                }

                splashScreen.Show();
                var progress = new Progress<string>(UpdateLoadingScreen);

                await Task.Run(() => ExportFileInXLS(finallyFilePath + ".xls", sqlQuery, file, query, quantity, progress));

                splashScreen.Close();

                Message.MessageWindowOk($"Файл {file} экспортирован в формат .xls");
            }
            else if (checkBoxTXT.Checked)
            {
                ExportFileInTXT(finallyFilePath + ".txt", sqlQuery, file, query);
            }
            else if (checkBoxJSON.Checked)
            {
                ExportFileInJSON(finallyFilePath + ".json", sqlQuery, file, query);
            }
            else if (checkBoxCSV.Checked)
            {
                ExportFileInCSV(finallyFilePath + ".csv", sqlQuery, file, query);
            }
            else if (checkBoxTSV.Checked)
            {
                ExportFileInTSV(finallyFilePath + ".tsv", sqlQuery, file, query);
            }

            dbFilePath = "";
        }
    }
}
