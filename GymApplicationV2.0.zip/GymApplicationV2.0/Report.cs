﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymApplicationV2._0
{
    public partial class Report : Form
    {
        public Report()
        {
            InitializeComponent();
        }

        private void Report_Load(object sender, EventArgs e)
        {
            DataClass.AllClients = true;
        }

        private void buttonShow_Click(object sender, EventArgs e)
        {
            DataClass.Begin = dateTimePickerBegin.Value;
            DataClass.End = dateTimePickerEnd.Value;

            DataClass.PeriodForMonth = radioForMonth.Checked;
            DataClass.PeriodForWeek = radioForWeek.Checked;
            DataClass.PeriodForDay = radioForDay.Checked;

            DataClass.AllClients = checkBoxAllClients.Checked;
            DataClass.ClientsForPeriod = checkBoxClientsForPeriod.Checked;
            DataClass.SellServices = checkBoxSellServices.Checked;

            InformationReport showReport = new InformationReport();
            showReport.Show();
        }

        private void checkBoxClientsForPeriod_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxClientsForPeriod.Checked)
            {
                checkBoxAllClients.Checked = false;
                checkBoxSellServices.Checked = false;
            }
        }

        private void checkBoxAllClients_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxAllClients.Checked)
            {
                checkBoxClientsForPeriod.Checked = false;
                checkBoxSellServices.Checked = false;
            }
        }

        private void checkBoxSellServices_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxSellServices.Checked)
            {
                checkBoxClientsForPeriod.Checked = false;
                checkBoxAllClients.Checked = false;
            }
        }
    }
}
