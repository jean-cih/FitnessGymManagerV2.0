﻿namespace GymApplicationV2._0
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.buttonSettings = new System.Windows.Forms.Button();
            this.panelForButtons = new System.Windows.Forms.Panel();
            this.buttonReport = new System.Windows.Forms.Button();
            this.buttonClients = new System.Windows.Forms.Button();
            this.buttonProducts = new System.Windows.Forms.Button();
            this.buttonServices = new System.Windows.Forms.Button();
            this.panelForPayment = new System.Windows.Forms.Panel();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.labelDateSell = new System.Windows.Forms.Label();
            this.buttonSellClient = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.buttonSingleVisiting = new System.Windows.Forms.Button();
            this.buttonNewMembership = new System.Windows.Forms.Button();
            this.textNumberClient = new System.Windows.Forms.TextBox();
            this.labelNumberClient = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dataGridViewClient = new System.Windows.Forms.DataGridView();
            this.panelForButtons.SuspendLayout();
            this.panelForPayment.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewClient)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonSettings
            // 
            this.buttonSettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSettings.Location = new System.Drawing.Point(7, 9);
            this.buttonSettings.Name = "buttonSettings";
            this.buttonSettings.Size = new System.Drawing.Size(109, 39);
            this.buttonSettings.TabIndex = 0;
            this.buttonSettings.Text = "Настройка";
            this.buttonSettings.UseVisualStyleBackColor = true;
            this.buttonSettings.Click += new System.EventHandler(this.buttonSettings_Click);
            // 
            // panelForButtons
            // 
            this.panelForButtons.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelForButtons.BackColor = System.Drawing.Color.Gainsboro;
            this.panelForButtons.Controls.Add(this.buttonReport);
            this.panelForButtons.Controls.Add(this.buttonClients);
            this.panelForButtons.Controls.Add(this.buttonProducts);
            this.panelForButtons.Controls.Add(this.buttonServices);
            this.panelForButtons.Controls.Add(this.buttonSettings);
            this.panelForButtons.Location = new System.Drawing.Point(0, -3);
            this.panelForButtons.Name = "panelForButtons";
            this.panelForButtons.Size = new System.Drawing.Size(1483, 56);
            this.panelForButtons.TabIndex = 1;
            // 
            // buttonReport
            // 
            this.buttonReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonReport.Location = new System.Drawing.Point(467, 9);
            this.buttonReport.Name = "buttonReport";
            this.buttonReport.Size = new System.Drawing.Size(109, 39);
            this.buttonReport.TabIndex = 4;
            this.buttonReport.Text = "Отчет";
            this.buttonReport.UseVisualStyleBackColor = true;
            this.buttonReport.Click += new System.EventHandler(this.buttonReport_Click);
            // 
            // buttonClients
            // 
            this.buttonClients.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonClients.Location = new System.Drawing.Point(352, 9);
            this.buttonClients.Name = "buttonClients";
            this.buttonClients.Size = new System.Drawing.Size(109, 39);
            this.buttonClients.TabIndex = 3;
            this.buttonClients.Text = "Клиенты";
            this.buttonClients.UseVisualStyleBackColor = true;
            this.buttonClients.Click += new System.EventHandler(this.buttonClients_Click);
            // 
            // buttonProducts
            // 
            this.buttonProducts.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonProducts.Location = new System.Drawing.Point(237, 9);
            this.buttonProducts.Name = "buttonProducts";
            this.buttonProducts.Size = new System.Drawing.Size(109, 39);
            this.buttonProducts.TabIndex = 2;
            this.buttonProducts.Text = "Товары";
            this.buttonProducts.UseVisualStyleBackColor = true;
            this.buttonProducts.Click += new System.EventHandler(this.buttonProducts_Click);
            // 
            // buttonServices
            // 
            this.buttonServices.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonServices.Location = new System.Drawing.Point(122, 9);
            this.buttonServices.Name = "buttonServices";
            this.buttonServices.Size = new System.Drawing.Size(109, 39);
            this.buttonServices.TabIndex = 1;
            this.buttonServices.Text = "Услуги";
            this.buttonServices.UseVisualStyleBackColor = true;
            this.buttonServices.Click += new System.EventHandler(this.buttonServices_Click);
            // 
            // panelForPayment
            // 
            this.panelForPayment.BackColor = System.Drawing.Color.Gainsboro;
            this.panelForPayment.Controls.Add(this.dateTimePicker1);
            this.panelForPayment.Controls.Add(this.labelDateSell);
            this.panelForPayment.Controls.Add(this.buttonSellClient);
            this.panelForPayment.Controls.Add(this.button1);
            this.panelForPayment.Controls.Add(this.buttonSingleVisiting);
            this.panelForPayment.Controls.Add(this.buttonNewMembership);
            this.panelForPayment.Location = new System.Drawing.Point(40, 154);
            this.panelForPayment.Name = "panelForPayment";
            this.panelForPayment.Size = new System.Drawing.Size(340, 400);
            this.panelForPayment.TabIndex = 2;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(152, 313);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(118, 22);
            this.dateTimePicker1.TabIndex = 9;
            // 
            // labelDateSell
            // 
            this.labelDateSell.AutoSize = true;
            this.labelDateSell.Location = new System.Drawing.Point(75, 307);
            this.labelDateSell.Name = "labelDateSell";
            this.labelDateSell.Size = new System.Drawing.Size(66, 32);
            this.labelDateSell.TabIndex = 5;
            this.labelDateSell.Text = "    Дата\r\nПродажи";
            // 
            // buttonSellClient
            // 
            this.buttonSellClient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSellClient.Location = new System.Drawing.Point(23, 189);
            this.buttonSellClient.Name = "buttonSellClient";
            this.buttonSellClient.Size = new System.Drawing.Size(291, 59);
            this.buttonSellClient.TabIndex = 4;
            this.buttonSellClient.Text = "Продать";
            this.buttonSellClient.UseVisualStyleBackColor = true;
            this.buttonSellClient.Click += new System.EventHandler(this.buttonSellClient_Click);
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(23, 147);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(291, 39);
            this.button1.TabIndex = 3;
            this.button1.Text = "Выбрать клиента";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // buttonSingleVisiting
            // 
            this.buttonSingleVisiting.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSingleVisiting.Location = new System.Drawing.Point(169, 60);
            this.buttonSingleVisiting.Name = "buttonSingleVisiting";
            this.buttonSingleVisiting.Size = new System.Drawing.Size(145, 39);
            this.buttonSingleVisiting.TabIndex = 2;
            this.buttonSingleVisiting.Text = "Разовый";
            this.buttonSingleVisiting.UseVisualStyleBackColor = true;
            this.buttonSingleVisiting.Click += new System.EventHandler(this.buttonSingleVisiting_Click);
            // 
            // buttonNewMembership
            // 
            this.buttonNewMembership.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonNewMembership.Location = new System.Drawing.Point(23, 60);
            this.buttonNewMembership.Name = "buttonNewMembership";
            this.buttonNewMembership.Size = new System.Drawing.Size(140, 39);
            this.buttonNewMembership.TabIndex = 1;
            this.buttonNewMembership.Text = "Новый";
            this.buttonNewMembership.UseVisualStyleBackColor = true;
            this.buttonNewMembership.Click += new System.EventHandler(this.buttonNewMembership_Click);
            // 
            // textNumberClient
            // 
            this.textNumberClient.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textNumberClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textNumberClient.Location = new System.Drawing.Point(9, 6);
            this.textNumberClient.Name = "textNumberClient";
            this.textNumberClient.Size = new System.Drawing.Size(323, 38);
            this.textNumberClient.TabIndex = 7;
            this.textNumberClient.TextChanged += new System.EventHandler(this.textNumberClient_TextChanged);
            // 
            // labelNumberClient
            // 
            this.labelNumberClient.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelNumberClient.AutoSize = true;
            this.labelNumberClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelNumberClient.Location = new System.Drawing.Point(606, 107);
            this.labelNumberClient.Name = "labelNumberClient";
            this.labelNumberClient.Size = new System.Drawing.Size(80, 40);
            this.labelNumberClient.TabIndex = 8;
            this.labelNumberClient.Text = "Номер\r\nКлиента";
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.Gainsboro;
            this.panel1.Controls.Add(this.textNumberClient);
            this.panel1.Location = new System.Drawing.Point(708, 102);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(342, 50);
            this.panel1.TabIndex = 7;
            // 
            // dataGridViewClient
            // 
            this.dataGridViewClient.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.dataGridViewClient.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewClient.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewClient.GridColor = System.Drawing.Color.Gainsboro;
            this.dataGridViewClient.Location = new System.Drawing.Point(394, 448);
            this.dataGridViewClient.Name = "dataGridViewClient";
            this.dataGridViewClient.RowHeadersWidth = 51;
            this.dataGridViewClient.RowTemplate.Height = 24;
            this.dataGridViewClient.Size = new System.Drawing.Size(656, 106);
            this.dataGridViewClient.TabIndex = 9;
            this.dataGridViewClient.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewClient_CellContentClick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.ClientSize = new System.Drawing.Size(1482, 753);
            this.Controls.Add(this.dataGridViewClient);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.labelNumberClient);
            this.Controls.Add(this.panelForPayment);
            this.Controls.Add(this.panelForButtons);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Сибиряк";
            this.panelForButtons.ResumeLayout(false);
            this.panelForPayment.ResumeLayout(false);
            this.panelForPayment.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewClient)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonSettings;
        private System.Windows.Forms.Panel panelForButtons;
        private System.Windows.Forms.Button buttonClients;
        private System.Windows.Forms.Button buttonProducts;
        private System.Windows.Forms.Button buttonServices;
        private System.Windows.Forms.Button buttonReport;
        private System.Windows.Forms.Panel panelForPayment;
        private System.Windows.Forms.Button buttonSellClient;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button buttonSingleVisiting;
        private System.Windows.Forms.Button buttonNewMembership;
        private System.Windows.Forms.Label labelDateSell;
        private System.Windows.Forms.TextBox textNumberClient;
        private System.Windows.Forms.Label labelNumberClient;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DataGridView dataGridViewClient;
    }
}

