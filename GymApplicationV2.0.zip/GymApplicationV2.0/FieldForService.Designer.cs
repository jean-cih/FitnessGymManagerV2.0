﻿namespace GymApplicationV2._0
{
    partial class FieldForService
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FieldForService));
            this.labelQuantity = new System.Windows.Forms.Label();
            this.textQuantity = new System.Windows.Forms.TextBox();
            this.labelTermAction = new System.Windows.Forms.Label();
            this.labelCost = new System.Windows.Forms.Label();
            this.labelName = new System.Windows.Forms.Label();
            this.textTermAction = new System.Windows.Forms.TextBox();
            this.textCost = new System.Windows.Forms.TextBox();
            this.textName = new System.Windows.Forms.TextBox();
            this.buttonSave = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelQuantity
            // 
            this.labelQuantity.AutoSize = true;
            this.labelQuantity.Location = new System.Drawing.Point(33, 305);
            this.labelQuantity.Name = "labelQuantity";
            this.labelQuantity.Size = new System.Drawing.Size(162, 16);
            this.labelQuantity.TabIndex = 21;
            this.labelQuantity.Text = "Количество Посещений";
            // 
            // textQuantity
            // 
            this.textQuantity.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textQuantity.Location = new System.Drawing.Point(30, 326);
            this.textQuantity.Name = "textQuantity";
            this.textQuantity.Size = new System.Drawing.Size(188, 30);
            this.textQuantity.TabIndex = 20;
            // 
            // labelTermAction
            // 
            this.labelTermAction.AutoSize = true;
            this.labelTermAction.Location = new System.Drawing.Point(33, 220);
            this.labelTermAction.Name = "labelTermAction";
            this.labelTermAction.Size = new System.Drawing.Size(141, 16);
            this.labelTermAction.TabIndex = 19;
            this.labelTermAction.Text = "Срок Действия (Мес)";
            // 
            // labelCost
            // 
            this.labelCost.AutoSize = true;
            this.labelCost.Location = new System.Drawing.Point(33, 143);
            this.labelCost.Name = "labelCost";
            this.labelCost.Size = new System.Drawing.Size(40, 16);
            this.labelCost.TabIndex = 18;
            this.labelCost.Text = "Цена";
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Location = new System.Drawing.Point(33, 73);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(106, 16);
            this.labelName.TabIndex = 17;
            this.labelName.Text = "Наименование";
            // 
            // textTermAction
            // 
            this.textTermAction.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textTermAction.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textTermAction.Location = new System.Drawing.Point(30, 242);
            this.textTermAction.Name = "textTermAction";
            this.textTermAction.Size = new System.Drawing.Size(188, 30);
            this.textTermAction.TabIndex = 16;
            // 
            // textCost
            // 
            this.textCost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textCost.Location = new System.Drawing.Point(30, 164);
            this.textCost.Name = "textCost";
            this.textCost.Size = new System.Drawing.Size(188, 30);
            this.textCost.TabIndex = 15;
            // 
            // textName
            // 
            this.textName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textName.Location = new System.Drawing.Point(30, 95);
            this.textName.Name = "textName";
            this.textName.Size = new System.Drawing.Size(351, 30);
            this.textName.TabIndex = 14;
            // 
            // buttonSave
            // 
            this.buttonSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSave.Location = new System.Drawing.Point(127, 453);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new System.Drawing.Size(150, 55);
            this.buttonSave.TabIndex = 22;
            this.buttonSave.Text = "Сохранить";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
            // 
            // FieldForService
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(404, 548);
            this.Controls.Add(this.buttonSave);
            this.Controls.Add(this.labelQuantity);
            this.Controls.Add(this.textQuantity);
            this.Controls.Add(this.labelTermAction);
            this.Controls.Add(this.labelCost);
            this.Controls.Add(this.labelName);
            this.Controls.Add(this.textTermAction);
            this.Controls.Add(this.textCost);
            this.Controls.Add(this.textName);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FieldForService";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Добавление Услуги";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelQuantity;
        protected internal System.Windows.Forms.TextBox textQuantity;
        private System.Windows.Forms.Label labelTermAction;
        private System.Windows.Forms.Label labelCost;
        private System.Windows.Forms.Label labelName;
        protected internal System.Windows.Forms.TextBox textTermAction;
        protected internal System.Windows.Forms.TextBox textCost;
        protected internal System.Windows.Forms.TextBox textName;
        private System.Windows.Forms.Button buttonSave;
    }
}