﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Data.SQLite;

namespace GymApplicationV2._0
{
    public partial class SingleTicket : Form
    {
        public SingleTicket()
        {
            InitializeComponent();
        }

        private void SingleTicket_Load(object sender, EventArgs e)
        {
            CheckIfDataExists();
        }

        private void CheckIfDataExists()
        {
            if (!File.Exists("Databases\\Clients.db"))
            {
                ClientsContext.CreatingDatabase();
            }
            else
            {
                LoadDataGridViewClients();
            }
        }

        private void LoadDataGridViewClients()
        {
            dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts");
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            if (textSearch.Text == "")
                return;

            dataGridViewClients.DataSource = ClientsContext.GetDataFromDatabase($"SELECT * FROM Contacts WHERE {comboSearch.Text} = '" + textSearch.Text + "';");

            textSearch.Text = "";
        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            LoadDataGridViewClients();
        }

        int key = 0;
        private void dataGridViewClients_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            key = Convert.ToInt32(dataGridViewClients.SelectedRows[0].Cells[0].Value.ToString());
            string surname = dataGridViewClients.SelectedRows[0].Cells[1].Value.ToString();
            string name = dataGridViewClients.SelectedRows[0].Cells[2].Value.ToString();
            buttonSell.Text = "Продать\n" + name + " " + surname;
        }

        private void buttonSell_Click(object sender, EventArgs e)
        {
            if (key == 0)
                return;

            using (SQLiteConnection conn = new SQLiteConnection(ClientsContext.ConnectionStringClients()))
            {
                string commandString = "UPDATE Contacts SET " +
                    "Абонемент = '" + "Разовое" + "'," +
                    "Осталось = '" + 0 + "' " +
                    "WHERE Id = '" + key + "';";

                using (SQLiteCommand cmd = new SQLiteCommand(commandString, conn))
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();

                    Message.MessageWindowOk("Разовое посещение продано");
                }
            }
        }
    }
}
