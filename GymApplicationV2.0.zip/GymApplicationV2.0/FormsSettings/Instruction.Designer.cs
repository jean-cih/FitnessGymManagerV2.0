﻿namespace GymApplicationV2._0.FormsSettings
{
    partial class instruction
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.jeanPanelInf = new GymApplicationV2._0.Controls.JeanPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.listBox = new System.Windows.Forms.ListBox();
            this.jeanPanelInf.SuspendLayout();
            this.SuspendLayout();
            // 
            // jeanPanelInf
            // 
            this.jeanPanelInf.BackColor = System.Drawing.Color.White;
            this.jeanPanelInf.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.jeanPanelInf.BorderRadius = 30;
            this.jeanPanelInf.Controls.Add(this.label2);
            this.jeanPanelInf.Controls.Add(this.listBox);
            this.jeanPanelInf.ForeColor = System.Drawing.Color.Black;
            this.jeanPanelInf.GradientAngle = 90F;
            this.jeanPanelInf.GradientBottomColor = System.Drawing.Color.White;
            this.jeanPanelInf.GradientTapColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            this.jeanPanelInf.Location = new System.Drawing.Point(35, 38);
            this.jeanPanelInf.Name = "jeanPanelInf";
            this.jeanPanelInf.Size = new System.Drawing.Size(1211, 624);
            this.jeanPanelInf.TabIndex = 57;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(552, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(151, 25);
            this.label2.TabIndex = 50;
            this.label2.Text = "ИНСТРУКЦИЯ";
            // 
            // listBox
            // 
            this.listBox.BackColor = System.Drawing.Color.White;
            this.listBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.listBox.FormattingEnabled = true;
            this.listBox.ItemHeight = 25;
            this.listBox.Items.AddRange(new object[] {
            "СЕГОДНЯ У МЕНЯ ОТЛИЧНЫЙ ДЕНЬ, ВООБЩЕ ЗДЕСЬ ДОЛЖНА БЫТЬ ИНСТРУКЦИЯ",
            "ПО ЗАГРУЗКЕ, НО ТАК КАК У МЕНЯ СЕГОДНЯ ХОРОШИЙ ДЕНЬ, Т К Я НЕ ПОШЕЛ В ",
            "УНИВЕР И ТЕПЕРЬ У МЕНЯ ВЫХОДНОЙ, ТО НАПИШУ ИНСТРУКЦИЮ КАК-НИБУДЬ",
            " ПОТОМ, МОЖЕТ ЧЕРЕЗ ПАРУ ЧАСОВ, А ПОКА ПРОСТО СДЕЛАЮ ОСНОВНОЕ",
            "ВООБЩЕ Я УЖЕ СДЕЛАЛ И СЕЙЧАС НЕ ПОНИМАЮ КРАСИВО ЭТО ИЛИ НЕТ, ",
            "ВСЕ-ТАКИ ДУМАЮ ЧТО ЭТО ABHORRENT BUT I CAN HARDLY IMAGINE HOW IT ",
            "MUST BE THE POINT OF DESIGN SO NOW I AM JUST TRYING TO TEST ",
            "THIS PROGRAM, IF YOU WANT TO HEAR IT MORE DISTANTLY I AM TESTING ",
            "THIS FORM WITH LOADING DATA",
            "СЕГОДНЯ У МЕНЯ ОТЛИЧНЫЙ ДЕНЬ, ВООБЩЕ ЗДЕСЬ ДОЛЖНА БЫТЬ ИНСТРУКЦИЯ",
            "ПО ЗАГРУЗКЕ, НО ТАК КАК У МЕНЯ СЕГОДНЯ ХОРОШИЙ ДЕНЬ, Т К Я НЕ ПОШЕЛ В ",
            "УНИВЕР И ТЕПЕРЬ У МЕНЯ ВЫХОДНОЙ, ТО НАПИШУ ИНСТРУКЦИЮ КАК-НИБУДЬ",
            " ПОТОМ, МОЖЕТ ЧЕРЕЗ ПАРУ ЧАСОВ, А ПОКА ПРОСТО СДЕЛАЮ ОСНОВНОЕ",
            "ВООБЩЕ Я УЖЕ СДЕЛАЛ И СЕЙЧАС НЕ ПОНИМАЮ КРАСИВО ЭТО ИЛИ НЕТ, ",
            "ВСЕ-ТАКИ ДУМАЮ ЧТО ЭТО ABHORRENT BUT I CAN HARDLY IMAGINE HOW IT ",
            "MUST BE THE POINT OF DESIGN SO NOW I AM JUST TRYING TO TEST ",
            "THIS PROGRAM, IF YOU WANT TO HEAR IT MORE DISTANTLY I AM TESTING ",
            "THIS FORM WITH LOADING DATA",
            "СЕГОДНЯ У МЕНЯ ОТЛИЧНЫЙ ДЕНЬ, ВООБЩЕ ЗДЕСЬ ДОЛЖНА БЫТЬ ИНСТРУКЦИЯ",
            "ПО ЗАГРУЗКЕ, НО ТАК КАК У МЕНЯ СЕГОДНЯ ХОРОШИЙ ДЕНЬ, Т К Я НЕ ПОШЕЛ В ",
            "УНИВЕР И ТЕПЕРЬ У МЕНЯ ВЫХОДНОЙ, ТО НАПИШУ ИНСТРУКЦИЮ КАК-НИБУДЬ",
            " ПОТОМ, МОЖЕТ ЧЕРЕЗ ПАРУ ЧАСОВ, А ПОКА ПРОСТО СДЕЛАЮ ОСНОВНОЕ",
            "ВООБЩЕ Я УЖЕ СДЕЛАЛ И СЕЙЧАС НЕ ПОНИМАЮ КРАСИВО ЭТО ИЛИ НЕТ, ",
            "ВСЕ-ТАКИ ДУМАЮ ЧТО ЭТО ABHORRENT BUT I CAN HARDLY IMAGINE HOW IT ",
            "MUST BE THE POINT OF DESIGN SO NOW I AM JUST TRYING TO TEST ",
            "THIS PROGRAM, IF YOU WANT TO HEAR IT MORE DISTANTLY I AM TESTING ",
            "THIS FORM WITH LOADING DATA",
            "СЕГОДНЯ У МЕНЯ ОТЛИЧНЫЙ ДЕНЬ, ВООБЩЕ ЗДЕСЬ ДОЛЖНА БЫТЬ ИНСТРУКЦИЯ",
            "ПО ЗАГРУЗКЕ, НО ТАК КАК У МЕНЯ СЕГОДНЯ ХОРОШИЙ ДЕНЬ, Т К Я НЕ ПОШЕЛ В ",
            "УНИВЕР И ТЕПЕРЬ У МЕНЯ ВЫХОДНОЙ, ТО НАПИШУ ИНСТРУКЦИЮ КАК-НИБУДЬ",
            " ПОТОМ, МОЖЕТ ЧЕРЕЗ ПАРУ ЧАСОВ, А ПОКА ПРОСТО СДЕЛАЮ ОСНОВНОЕ",
            "ВООБЩЕ Я УЖЕ СДЕЛАЛ И СЕЙЧАС НЕ ПОНИМАЮ КРАСИВО ЭТО ИЛИ НЕТ, ",
            "ВСЕ-ТАКИ ДУМАЮ ЧТО ЭТО ABHORRENT BUT I CAN HARDLY IMAGINE HOW IT ",
            "MUST BE THE POINT OF DESIGN SO NOW I AM JUST TRYING TO TEST ",
            "THIS PROGRAM, IF YOU WANT TO HEAR IT MORE DISTANTLY I AM TESTING ",
            "THIS FORM WITH LOADING DATA",
            "СЕГОДНЯ У МЕНЯ ОТЛИЧНЫЙ ДЕНЬ, ВООБЩЕ ЗДЕСЬ ДОЛЖНА БЫТЬ ИНСТРУКЦИЯ",
            "ПО ЗАГРУЗКЕ, НО ТАК КАК У МЕНЯ СЕГОДНЯ ХОРОШИЙ ДЕНЬ, Т К Я НЕ ПОШЕЛ В ",
            "УНИВЕР И ТЕПЕРЬ У МЕНЯ ВЫХОДНОЙ, ТО НАПИШУ ИНСТРУКЦИЮ КАК-НИБУДЬ",
            " ПОТОМ, МОЖЕТ ЧЕРЕЗ ПАРУ ЧАСОВ, А ПОКА ПРОСТО СДЕЛАЮ ОСНОВНОЕ",
            "ВООБЩЕ Я УЖЕ СДЕЛАЛ И СЕЙЧАС НЕ ПОНИМАЮ КРАСИВО ЭТО ИЛИ НЕТ, ",
            "ВСЕ-ТАКИ ДУМАЮ ЧТО ЭТО ABHORRENT BUT I CAN HARDLY IMAGINE HOW IT ",
            "MUST BE THE POINT OF DESIGN SO NOW I AM JUST TRYING TO TEST ",
            "THIS PROGRAM, IF YOU WANT TO HEAR IT MORE DISTANTLY I AM TESTING ",
            "THIS FORM WITH LOADING DATA",
            "СЕГОДНЯ У МЕНЯ ОТЛИЧНЫЙ ДЕНЬ, ВООБЩЕ ЗДЕСЬ ДОЛЖНА БЫТЬ ИНСТРУКЦИЯ",
            "ПО ЗАГРУЗКЕ, НО ТАК КАК У МЕНЯ СЕГОДНЯ ХОРОШИЙ ДЕНЬ, Т К Я НЕ ПОШЕЛ В ",
            "УНИВЕР И ТЕПЕРЬ У МЕНЯ ВЫХОДНОЙ, ТО НАПИШУ ИНСТРУКЦИЮ КАК-НИБУДЬ",
            " ПОТОМ, МОЖЕТ ЧЕРЕЗ ПАРУ ЧАСОВ, А ПОКА ПРОСТО СДЕЛАЮ ОСНОВНОЕ",
            "ВООБЩЕ Я УЖЕ СДЕЛАЛ И СЕЙЧАС НЕ ПОНИМАЮ КРАСИВО ЭТО ИЛИ НЕТ, ",
            "ВСЕ-ТАКИ ДУМАЮ ЧТО ЭТО ABHORRENT BUT I CAN HARDLY IMAGINE HOW IT ",
            "MUST BE THE POINT OF DESIGN SO NOW I AM JUST TRYING TO TEST ",
            "THIS PROGRAM, IF YOU WANT TO HEAR IT MORE DISTANTLY I AM TESTING ",
            "THIS FORM WITH LOADING DATA",
            "СЕГОДНЯ У МЕНЯ ОТЛИЧНЫЙ ДЕНЬ, ВООБЩЕ ЗДЕСЬ ДОЛЖНА БЫТЬ ИНСТРУКЦИЯ",
            "ПО ЗАГРУЗКЕ, НО ТАК КАК У МЕНЯ СЕГОДНЯ ХОРОШИЙ ДЕНЬ, Т К Я НЕ ПОШЕЛ В ",
            "УНИВЕР И ТЕПЕРЬ У МЕНЯ ВЫХОДНОЙ, ТО НАПИШУ ИНСТРУКЦИЮ КАК-НИБУДЬ",
            " ПОТОМ, МОЖЕТ ЧЕРЕЗ ПАРУ ЧАСОВ, А ПОКА ПРОСТО СДЕЛАЮ ОСНОВНОЕ",
            "ВООБЩЕ Я УЖЕ СДЕЛАЛ И СЕЙЧАС НЕ ПОНИМАЮ КРАСИВО ЭТО ИЛИ НЕТ, ",
            "ВСЕ-ТАКИ ДУМАЮ ЧТО ЭТО ABHORRENT BUT I CAN HARDLY IMAGINE HOW IT ",
            "MUST BE THE POINT OF DESIGN SO NOW I AM JUST TRYING TO TEST ",
            "THIS PROGRAM, IF YOU WANT TO HEAR IT MORE DISTANTLY I AM TESTING ",
            "THIS FORM WITH LOADING DATA",
            "СЕГОДНЯ У МЕНЯ ОТЛИЧНЫЙ ДЕНЬ, ВООБЩЕ ЗДЕСЬ ДОЛЖНА БЫТЬ ИНСТРУКЦИЯ",
            "ПО ЗАГРУЗКЕ, НО ТАК КАК У МЕНЯ СЕГОДНЯ ХОРОШИЙ ДЕНЬ, Т К Я НЕ ПОШЕЛ В ",
            "УНИВЕР И ТЕПЕРЬ У МЕНЯ ВЫХОДНОЙ, ТО НАПИШУ ИНСТРУКЦИЮ КАК-НИБУДЬ",
            " ПОТОМ, МОЖЕТ ЧЕРЕЗ ПАРУ ЧАСОВ, А ПОКА ПРОСТО СДЕЛАЮ ОСНОВНОЕ",
            "ВООБЩЕ Я УЖЕ СДЕЛАЛ И СЕЙЧАС НЕ ПОНИМАЮ КРАСИВО ЭТО ИЛИ НЕТ, ",
            "ВСЕ-ТАКИ ДУМАЮ ЧТО ЭТО ABHORRENT BUT I CAN HARDLY IMAGINE HOW IT ",
            "MUST BE THE POINT OF DESIGN SO NOW I AM JUST TRYING TO TEST ",
            "THIS PROGRAM, IF YOU WANT TO HEAR IT MORE DISTANTLY I AM TESTING ",
            "THIS FORM WITH LOADING DATA",
            "СЕГОДНЯ У МЕНЯ ОТЛИЧНЫЙ ДЕНЬ, ВООБЩЕ ЗДЕСЬ ДОЛЖНА БЫТЬ ИНСТРУКЦИЯ",
            "ПО ЗАГРУЗКЕ, НО ТАК КАК У МЕНЯ СЕГОДНЯ ХОРОШИЙ ДЕНЬ, Т К Я НЕ ПОШЕЛ В ",
            "УНИВЕР И ТЕПЕРЬ У МЕНЯ ВЫХОДНОЙ, ТО НАПИШУ ИНСТРУКЦИЮ КАК-НИБУДЬ",
            " ПОТОМ, МОЖЕТ ЧЕРЕЗ ПАРУ ЧАСОВ, А ПОКА ПРОСТО СДЕЛАЮ ОСНОВНОЕ",
            "ВООБЩЕ Я УЖЕ СДЕЛАЛ И СЕЙЧАС НЕ ПОНИМАЮ КРАСИВО ЭТО ИЛИ НЕТ, ",
            "ВСЕ-ТАКИ ДУМАЮ ЧТО ЭТО ABHORRENT BUT I CAN HARDLY IMAGINE HOW IT ",
            "MUST BE THE POINT OF DESIGN SO NOW I AM JUST TRYING TO TEST ",
            "THIS PROGRAM, IF YOU WANT TO HEAR IT MORE DISTANTLY I AM TESTING ",
            "THIS FORM WITH LOADING DATA",
            "СЕГОДНЯ У МЕНЯ ОТЛИЧНЫЙ ДЕНЬ, ВООБЩЕ ЗДЕСЬ ДОЛЖНА БЫТЬ ИНСТРУКЦИЯ",
            "ПО ЗАГРУЗКЕ, НО ТАК КАК У МЕНЯ СЕГОДНЯ ХОРОШИЙ ДЕНЬ, Т К Я НЕ ПОШЕЛ В ",
            "УНИВЕР И ТЕПЕРЬ У МЕНЯ ВЫХОДНОЙ, ТО НАПИШУ ИНСТРУКЦИЮ КАК-НИБУДЬ",
            " ПОТОМ, МОЖЕТ ЧЕРЕЗ ПАРУ ЧАСОВ, А ПОКА ПРОСТО СДЕЛАЮ ОСНОВНОЕ",
            "ВООБЩЕ Я УЖЕ СДЕЛАЛ И СЕЙЧАС НЕ ПОНИМАЮ КРАСИВО ЭТО ИЛИ НЕТ, ",
            "ВСЕ-ТАКИ ДУМАЮ ЧТО ЭТО ABHORRENT BUT I CAN HARDLY IMAGINE HOW IT ",
            "MUST BE THE POINT OF DESIGN SO NOW I AM JUST TRYING TO TEST ",
            "THIS PROGRAM, IF YOU WANT TO HEAR IT MORE DISTANTLY I AM TESTING ",
            "THIS FORM WITH LOADING DATA",
            "СЕГОДНЯ У МЕНЯ ОТЛИЧНЫЙ ДЕНЬ, ВООБЩЕ ЗДЕСЬ ДОЛЖНА БЫТЬ ИНСТРУКЦИЯ",
            "ПО ЗАГРУЗКЕ, НО ТАК КАК У МЕНЯ СЕГОДНЯ ХОРОШИЙ ДЕНЬ, Т К Я НЕ ПОШЕЛ В ",
            "УНИВЕР И ТЕПЕРЬ У МЕНЯ ВЫХОДНОЙ, ТО НАПИШУ ИНСТРУКЦИЮ КАК-НИБУДЬ",
            " ПОТОМ, МОЖЕТ ЧЕРЕЗ ПАРУ ЧАСОВ, А ПОКА ПРОСТО СДЕЛАЮ ОСНОВНОЕ",
            "ВООБЩЕ Я УЖЕ СДЕЛАЛ И СЕЙЧАС НЕ ПОНИМАЮ КРАСИВО ЭТО ИЛИ НЕТ, ",
            "ВСЕ-ТАКИ ДУМАЮ ЧТО ЭТО ABHORRENT BUT I CAN HARDLY IMAGINE HOW IT ",
            "MUST BE THE POINT OF DESIGN SO NOW I AM JUST TRYING TO TEST ",
            "THIS PROGRAM, IF YOU WANT TO HEAR IT MORE DISTANTLY I AM TESTING ",
            "THIS FORM WITH LOADING DATA"});
            this.listBox.Location = new System.Drawing.Point(21, 70);
            this.listBox.Name = "listBox";
            this.listBox.Size = new System.Drawing.Size(1170, 425);
            this.listBox.TabIndex = 0;
            // 
            // instruction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.jeanPanelInf);
            this.Name = "instruction";
            this.Size = new System.Drawing.Size(1280, 700);
            this.jeanPanelInf.ResumeLayout(false);
            this.jeanPanelInf.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Controls.JeanPanel jeanPanelInf;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox listBox;
    }
}
