﻿namespace GymApplicationV2._0.FormsSettings
{
    partial class AdjustingDesignForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.comboBoxFontCaptions = new System.Windows.Forms.ComboBox();
            this.labelFontCaptions = new System.Windows.Forms.Label();
            this.labelFontButtons = new System.Windows.Forms.Label();
            this.comboBoxFontTables = new System.Windows.Forms.ComboBox();
            this.comboBoxFontButtons = new System.Windows.Forms.ComboBox();
            this.labelFontTables = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBoxForm = new System.Windows.Forms.ComboBox();
            this.labelForm = new System.Windows.Forms.Label();
            this.labelTheme = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBoxTheme = new System.Windows.Forms.PictureBox();
            this.jeanToggleButtonTheme = new GymApplicationV2._0.Controls.JeanToggleButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTheme)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.comboBoxFontCaptions);
            this.panel1.Controls.Add(this.labelFontCaptions);
            this.panel1.Controls.Add(this.labelFontButtons);
            this.panel1.Controls.Add(this.comboBoxFontTables);
            this.panel1.Controls.Add(this.comboBoxFontButtons);
            this.panel1.Controls.Add(this.labelFontTables);
            this.panel1.Location = new System.Drawing.Point(632, 236);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(409, 306);
            this.panel1.TabIndex = 18;
            // 
            // comboBoxFontCaptions
            // 
            this.comboBoxFontCaptions.FormattingEnabled = true;
            this.comboBoxFontCaptions.Items.AddRange(new object[] {
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13"});
            this.comboBoxFontCaptions.Location = new System.Drawing.Point(73, 96);
            this.comboBoxFontCaptions.Name = "comboBoxFontCaptions";
            this.comboBoxFontCaptions.Size = new System.Drawing.Size(121, 24);
            this.comboBoxFontCaptions.TabIndex = 16;
            this.comboBoxFontCaptions.Text = "8";
            this.comboBoxFontCaptions.SelectedIndexChanged += new System.EventHandler(this.comboBoxFontCaptions_SelectedIndexChanged);
            // 
            // labelFontCaptions
            // 
            this.labelFontCaptions.AutoSize = true;
            this.labelFontCaptions.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelFontCaptions.Location = new System.Drawing.Point(59, 65);
            this.labelFontCaptions.Name = "labelFontCaptions";
            this.labelFontCaptions.Size = new System.Drawing.Size(232, 20);
            this.labelFontCaptions.TabIndex = 15;
            this.labelFontCaptions.Text = "Размер шрифта надписей";
            // 
            // labelFontButtons
            // 
            this.labelFontButtons.AutoSize = true;
            this.labelFontButtons.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelFontButtons.Location = new System.Drawing.Point(59, 129);
            this.labelFontButtons.Name = "labelFontButtons";
            this.labelFontButtons.Size = new System.Drawing.Size(209, 20);
            this.labelFontButtons.TabIndex = 11;
            this.labelFontButtons.Text = "Размер шрифта кнопок";
            // 
            // comboBoxFontTables
            // 
            this.comboBoxFontTables.FormattingEnabled = true;
            this.comboBoxFontTables.Items.AddRange(new object[] {
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.comboBoxFontTables.Location = new System.Drawing.Point(73, 231);
            this.comboBoxFontTables.Name = "comboBoxFontTables";
            this.comboBoxFontTables.Size = new System.Drawing.Size(121, 24);
            this.comboBoxFontTables.TabIndex = 14;
            this.comboBoxFontTables.Text = "8";
            this.comboBoxFontTables.SelectedIndexChanged += new System.EventHandler(this.comboBoxFontTables_SelectedIndexChanged);
            // 
            // comboBoxFontButtons
            // 
            this.comboBoxFontButtons.FormattingEnabled = true;
            this.comboBoxFontButtons.Items.AddRange(new object[] {
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.comboBoxFontButtons.Location = new System.Drawing.Point(73, 160);
            this.comboBoxFontButtons.Name = "comboBoxFontButtons";
            this.comboBoxFontButtons.Size = new System.Drawing.Size(121, 24);
            this.comboBoxFontButtons.TabIndex = 12;
            this.comboBoxFontButtons.Text = "8";
            this.comboBoxFontButtons.SelectedIndexChanged += new System.EventHandler(this.comboBoxFontButtons_SelectedIndexChanged);
            // 
            // labelFontTables
            // 
            this.labelFontTables.AutoSize = true;
            this.labelFontTables.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelFontTables.Location = new System.Drawing.Point(59, 200);
            this.labelFontTables.Name = "labelFontTables";
            this.labelFontTables.Size = new System.Drawing.Size(228, 20);
            this.labelFontTables.TabIndex = 13;
            this.labelFontTables.Text = "Размер шрифта  таблицы";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(282, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(759, 29);
            this.label1.TabIndex = 17;
            this.label1.Text = "Сделать изменение размера шрифта и изменения стиля форму";
            // 
            // comboBoxForm
            // 
            this.comboBoxForm.FormattingEnabled = true;
            this.comboBoxForm.Items.AddRange(new object[] {
            "None",
            "UserStyle",
            "SimpleDark",
            "TelegramStyle"});
            this.comboBoxForm.Location = new System.Drawing.Point(99, 50);
            this.comboBoxForm.Name = "comboBoxForm";
            this.comboBoxForm.Size = new System.Drawing.Size(121, 24);
            this.comboBoxForm.TabIndex = 18;
            this.comboBoxForm.Text = "None";
            this.comboBoxForm.SelectedIndexChanged += new System.EventHandler(this.comboBoxForm_SelectedIndexChanged);
            // 
            // labelForm
            // 
            this.labelForm.AutoSize = true;
            this.labelForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelForm.Location = new System.Drawing.Point(66, 21);
            this.labelForm.Name = "labelForm";
            this.labelForm.Size = new System.Drawing.Size(184, 20);
            this.labelForm.TabIndex = 17;
            this.labelForm.Text = "Дизайн оформления";
            // 
            // labelTheme
            // 
            this.labelTheme.AutoSize = true;
            this.labelTheme.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelTheme.Location = new System.Drawing.Point(48, 41);
            this.labelTheme.Name = "labelTheme";
            this.labelTheme.Size = new System.Drawing.Size(118, 20);
            this.labelTheme.TabIndex = 20;
            this.labelTheme.Text = "Темная тема";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.pictureBoxTheme);
            this.panel2.Controls.Add(this.labelTheme);
            this.panel2.Controls.Add(this.jeanToggleButtonTheme);
            this.panel2.Location = new System.Drawing.Point(272, 442);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(313, 100);
            this.panel2.TabIndex = 21;
            // 
            // pictureBoxTheme
            // 
            this.pictureBoxTheme.Image = global::GymApplicationV2._0.Properties.Resources.LightMode;
            this.pictureBoxTheme.Location = new System.Drawing.Point(13, 39);
            this.pictureBoxTheme.Name = "pictureBoxTheme";
            this.pictureBoxTheme.Size = new System.Drawing.Size(31, 27);
            this.pictureBoxTheme.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxTheme.TabIndex = 22;
            this.pictureBoxTheme.TabStop = false;
            // 
            // jeanToggleButtonTheme
            // 
            this.jeanToggleButtonTheme.AutoSize = true;
            this.jeanToggleButtonTheme.Location = new System.Drawing.Point(253, 39);
            this.jeanToggleButtonTheme.MinimumSize = new System.Drawing.Size(45, 22);
            this.jeanToggleButtonTheme.Name = "jeanToggleButtonTheme";
            this.jeanToggleButtonTheme.OffBackColor = System.Drawing.Color.Silver;
            this.jeanToggleButtonTheme.OffToggleColor = System.Drawing.Color.White;
            this.jeanToggleButtonTheme.OnBackColor = System.Drawing.Color.MediumSlateBlue;
            this.jeanToggleButtonTheme.OnToggleColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.jeanToggleButtonTheme.Size = new System.Drawing.Size(45, 22);
            this.jeanToggleButtonTheme.TabIndex = 19;
            this.jeanToggleButtonTheme.UseVisualStyleBackColor = true;
            this.jeanToggleButtonTheme.CheckedChanged += new System.EventHandler(this.jeanToggleButtonTheme_CheckedChanged);
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.comboBoxForm);
            this.panel3.Controls.Add(this.labelForm);
            this.panel3.Location = new System.Drawing.Point(272, 236);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(313, 100);
            this.panel3.TabIndex = 21;
            // 
            // AdjustingDesignForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1280, 700);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AdjustingDesignForm";
            this.Load += new System.EventHandler(this.AdjustingDesign_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTheme)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox comboBoxFontCaptions;
        private System.Windows.Forms.Label labelFontCaptions;
        private System.Windows.Forms.Label labelFontButtons;
        private System.Windows.Forms.ComboBox comboBoxFontTables;
        private System.Windows.Forms.ComboBox comboBoxFontButtons;
        private System.Windows.Forms.Label labelFontTables;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxForm;
        private System.Windows.Forms.Label labelForm;
        private Controls.JeanToggleButton jeanToggleButtonTheme;
        private System.Windows.Forms.Label labelTheme;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBoxTheme;
    }
}