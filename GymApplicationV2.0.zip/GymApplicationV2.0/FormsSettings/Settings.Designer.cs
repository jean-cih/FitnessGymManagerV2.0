﻿namespace GymApplicationV2._0
{
    partial class Settings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Settings));
            this.panel = new System.Windows.Forms.Panel();
            this.jeanModernButtonClose = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanModernButtonSounds = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanModernButtonFont = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanModernButtonLoad = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanModernButtonInfo = new GymApplicationV2._0.Controls.JeanModernButton();
            this.panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel
            // 
            this.panel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel.Controls.Add(this.jeanModernButtonClose);
            this.panel.Controls.Add(this.jeanModernButtonSounds);
            this.panel.Controls.Add(this.jeanModernButtonFont);
            this.panel.Controls.Add(this.jeanModernButtonLoad);
            this.panel.Controls.Add(this.jeanModernButtonInfo);
            this.panel.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel.Location = new System.Drawing.Point(0, 0);
            this.panel.Name = "panel";
            this.panel.Size = new System.Drawing.Size(114, 705);
            this.panel.TabIndex = 50;
            // 
            // jeanModernButtonClose
            // 
            this.jeanModernButtonClose.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.jeanModernButtonClose.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.jeanModernButtonClose.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("jeanModernButtonClose.BackgroundImage")));
            this.jeanModernButtonClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.jeanModernButtonClose.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.jeanModernButtonClose.BorderRadius = 0;
            this.jeanModernButtonClose.BorderSize = 0;
            this.jeanModernButtonClose.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonClose.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonClose.Location = new System.Drawing.Point(24, 616);
            this.jeanModernButtonClose.Name = "jeanModernButtonClose";
            this.jeanModernButtonClose.Size = new System.Drawing.Size(69, 60);
            this.jeanModernButtonClose.TabIndex = 53;
            this.jeanModernButtonClose.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonClose.UseVisualStyleBackColor = false;
            this.jeanModernButtonClose.Click += new System.EventHandler(this.jeanModernButtonClose_Click);
            // 
            // jeanModernButtonSounds
            // 
            this.jeanModernButtonSounds.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.jeanModernButtonSounds.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.jeanModernButtonSounds.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("jeanModernButtonSounds.BackgroundImage")));
            this.jeanModernButtonSounds.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.jeanModernButtonSounds.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.jeanModernButtonSounds.BorderRadius = 20;
            this.jeanModernButtonSounds.BorderSize = 0;
            this.jeanModernButtonSounds.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonSounds.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonSounds.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonSounds.Location = new System.Drawing.Point(24, 235);
            this.jeanModernButtonSounds.Name = "jeanModernButtonSounds";
            this.jeanModernButtonSounds.Size = new System.Drawing.Size(69, 60);
            this.jeanModernButtonSounds.TabIndex = 52;
            this.jeanModernButtonSounds.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonSounds.UseVisualStyleBackColor = false;
            this.jeanModernButtonSounds.Click += new System.EventHandler(this.jeanModernButtonSounds_Click);
            // 
            // jeanModernButtonFont
            // 
            this.jeanModernButtonFont.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.jeanModernButtonFont.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.jeanModernButtonFont.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("jeanModernButtonFont.BackgroundImage")));
            this.jeanModernButtonFont.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.jeanModernButtonFont.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.jeanModernButtonFont.BorderRadius = 20;
            this.jeanModernButtonFont.BorderSize = 0;
            this.jeanModernButtonFont.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonFont.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonFont.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonFont.Location = new System.Drawing.Point(24, 24);
            this.jeanModernButtonFont.Name = "jeanModernButtonFont";
            this.jeanModernButtonFont.Size = new System.Drawing.Size(69, 60);
            this.jeanModernButtonFont.TabIndex = 51;
            this.jeanModernButtonFont.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonFont.UseVisualStyleBackColor = false;
            this.jeanModernButtonFont.Click += new System.EventHandler(this.jeanModernButtonFont_Click);
            // 
            // jeanModernButtonLoad
            // 
            this.jeanModernButtonLoad.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.jeanModernButtonLoad.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.jeanModernButtonLoad.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("jeanModernButtonLoad.BackgroundImage")));
            this.jeanModernButtonLoad.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.jeanModernButtonLoad.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.jeanModernButtonLoad.BorderRadius = 20;
            this.jeanModernButtonLoad.BorderSize = 0;
            this.jeanModernButtonLoad.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonLoad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonLoad.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonLoad.Location = new System.Drawing.Point(24, 127);
            this.jeanModernButtonLoad.Name = "jeanModernButtonLoad";
            this.jeanModernButtonLoad.Size = new System.Drawing.Size(69, 60);
            this.jeanModernButtonLoad.TabIndex = 50;
            this.jeanModernButtonLoad.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonLoad.UseVisualStyleBackColor = false;
            this.jeanModernButtonLoad.Click += new System.EventHandler(this.jeanModernButtonLoad_Click);
            // 
            // jeanModernButtonInfo
            // 
            this.jeanModernButtonInfo.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.jeanModernButtonInfo.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.jeanModernButtonInfo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("jeanModernButtonInfo.BackgroundImage")));
            this.jeanModernButtonInfo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.jeanModernButtonInfo.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.jeanModernButtonInfo.BorderRadius = 20;
            this.jeanModernButtonInfo.BorderSize = 0;
            this.jeanModernButtonInfo.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonInfo.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonInfo.Location = new System.Drawing.Point(24, 323);
            this.jeanModernButtonInfo.Name = "jeanModernButtonInfo";
            this.jeanModernButtonInfo.Size = new System.Drawing.Size(69, 60);
            this.jeanModernButtonInfo.TabIndex = 49;
            this.jeanModernButtonInfo.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonInfo.UseVisualStyleBackColor = false;
            this.jeanModernButtonInfo.Click += new System.EventHandler(this.jeanModernButtonInfo_Click);
            // 
            // Settings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1400, 705);
            this.Controls.Add(this.panel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Settings";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Settings";
            this.Load += new System.EventHandler(this.Settings_Load);
            this.panel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private Controls.JeanModernButton jeanModernButtonInfo;
        private System.Windows.Forms.Panel panel;
        private Controls.JeanModernButton jeanModernButtonFont;
        private Controls.JeanModernButton jeanModernButtonLoad;
        private Controls.JeanModernButton jeanModernButtonSounds;
        private Controls.JeanModernButton jeanModernButtonClose;
    }
}