﻿namespace GymApplicationV2._0
{
    partial class Settings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Settings));
            this.panelControl = new System.Windows.Forms.Panel();
            this.jeanPanelSide = new GymApplicationV2._0.Controls.JeanPanel();
            this.jeanModernButtonClose = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanModernButtonSounds = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanModernButtonFont = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanModernButtonLoad = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanModernButtonInfo = new GymApplicationV2._0.Controls.JeanModernButton();
            this.panelMain = new System.Windows.Forms.Panel();
            this.instruction = new GymApplicationV2._0.FormsSettings.instruction();
            this.systemSounds = new GymApplicationV2._0.FormsSettings.SystemSounds();
            this.importingData = new GymApplicationV2._0.FormsSettings.ImportingData();
            this.adjustingDesign = new GymApplicationV2._0.FormsSettings.adjustingDesign();
            this.panelControl.SuspendLayout();
            this.panelMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelControl
            // 
            this.panelControl.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panelControl.Controls.Add(this.jeanPanelSide);
            this.panelControl.Controls.Add(this.jeanModernButtonClose);
            this.panelControl.Controls.Add(this.jeanModernButtonSounds);
            this.panelControl.Controls.Add(this.jeanModernButtonFont);
            this.panelControl.Controls.Add(this.jeanModernButtonLoad);
            this.panelControl.Controls.Add(this.jeanModernButtonInfo);
            this.panelControl.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelControl.Location = new System.Drawing.Point(0, 0);
            this.panelControl.Name = "panelControl";
            this.panelControl.Size = new System.Drawing.Size(120, 700);
            this.panelControl.TabIndex = 50;
            // 
            // jeanPanelSide
            // 
            this.jeanPanelSide.BackColor = System.Drawing.Color.White;
            this.jeanPanelSide.BorderRadius = 10;
            this.jeanPanelSide.ForeColor = System.Drawing.Color.Black;
            this.jeanPanelSide.GradientAngle = 90F;
            this.jeanPanelSide.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            this.jeanPanelSide.GradientTapColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            this.jeanPanelSide.Location = new System.Drawing.Point(-2, 24);
            this.jeanPanelSide.Name = "jeanPanelSide";
            this.jeanPanelSide.Size = new System.Drawing.Size(14, 60);
            this.jeanPanelSide.TabIndex = 54;
            // 
            // jeanModernButtonClose
            // 
            this.jeanModernButtonClose.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.jeanModernButtonClose.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.jeanModernButtonClose.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("jeanModernButtonClose.BackgroundImage")));
            this.jeanModernButtonClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.jeanModernButtonClose.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.jeanModernButtonClose.BorderRadius = 0;
            this.jeanModernButtonClose.BorderSize = 0;
            this.jeanModernButtonClose.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonClose.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonClose.Location = new System.Drawing.Point(24, 616);
            this.jeanModernButtonClose.Name = "jeanModernButtonClose";
            this.jeanModernButtonClose.Size = new System.Drawing.Size(69, 60);
            this.jeanModernButtonClose.TabIndex = 53;
            this.jeanModernButtonClose.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonClose.UseVisualStyleBackColor = false;
            this.jeanModernButtonClose.Click += new System.EventHandler(this.jeanModernButtonClose_Click);
            // 
            // jeanModernButtonSounds
            // 
            this.jeanModernButtonSounds.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.jeanModernButtonSounds.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.jeanModernButtonSounds.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("jeanModernButtonSounds.BackgroundImage")));
            this.jeanModernButtonSounds.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.jeanModernButtonSounds.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.jeanModernButtonSounds.BorderRadius = 20;
            this.jeanModernButtonSounds.BorderSize = 0;
            this.jeanModernButtonSounds.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonSounds.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonSounds.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonSounds.Location = new System.Drawing.Point(24, 235);
            this.jeanModernButtonSounds.Name = "jeanModernButtonSounds";
            this.jeanModernButtonSounds.Size = new System.Drawing.Size(69, 60);
            this.jeanModernButtonSounds.TabIndex = 52;
            this.jeanModernButtonSounds.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonSounds.UseVisualStyleBackColor = false;
            this.jeanModernButtonSounds.Click += new System.EventHandler(this.jeanModernButtonSounds_Click);
            // 
            // jeanModernButtonFont
            // 
            this.jeanModernButtonFont.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.jeanModernButtonFont.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.jeanModernButtonFont.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("jeanModernButtonFont.BackgroundImage")));
            this.jeanModernButtonFont.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.jeanModernButtonFont.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.jeanModernButtonFont.BorderRadius = 20;
            this.jeanModernButtonFont.BorderSize = 0;
            this.jeanModernButtonFont.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonFont.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonFont.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonFont.Location = new System.Drawing.Point(24, 24);
            this.jeanModernButtonFont.Name = "jeanModernButtonFont";
            this.jeanModernButtonFont.Size = new System.Drawing.Size(69, 60);
            this.jeanModernButtonFont.TabIndex = 51;
            this.jeanModernButtonFont.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonFont.UseVisualStyleBackColor = false;
            this.jeanModernButtonFont.Click += new System.EventHandler(this.jeanModernButtonFont_Click);
            // 
            // jeanModernButtonLoad
            // 
            this.jeanModernButtonLoad.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.jeanModernButtonLoad.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.jeanModernButtonLoad.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("jeanModernButtonLoad.BackgroundImage")));
            this.jeanModernButtonLoad.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.jeanModernButtonLoad.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.jeanModernButtonLoad.BorderRadius = 20;
            this.jeanModernButtonLoad.BorderSize = 0;
            this.jeanModernButtonLoad.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonLoad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonLoad.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonLoad.Location = new System.Drawing.Point(24, 127);
            this.jeanModernButtonLoad.Name = "jeanModernButtonLoad";
            this.jeanModernButtonLoad.Size = new System.Drawing.Size(69, 60);
            this.jeanModernButtonLoad.TabIndex = 50;
            this.jeanModernButtonLoad.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonLoad.UseVisualStyleBackColor = false;
            this.jeanModernButtonLoad.Click += new System.EventHandler(this.jeanModernButtonLoad_Click);
            // 
            // jeanModernButtonInfo
            // 
            this.jeanModernButtonInfo.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.jeanModernButtonInfo.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.jeanModernButtonInfo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("jeanModernButtonInfo.BackgroundImage")));
            this.jeanModernButtonInfo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.jeanModernButtonInfo.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.jeanModernButtonInfo.BorderRadius = 20;
            this.jeanModernButtonInfo.BorderSize = 0;
            this.jeanModernButtonInfo.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonInfo.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonInfo.Location = new System.Drawing.Point(24, 323);
            this.jeanModernButtonInfo.Name = "jeanModernButtonInfo";
            this.jeanModernButtonInfo.Size = new System.Drawing.Size(69, 60);
            this.jeanModernButtonInfo.TabIndex = 49;
            this.jeanModernButtonInfo.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonInfo.UseVisualStyleBackColor = false;
            this.jeanModernButtonInfo.Click += new System.EventHandler(this.jeanModernButtonInfo_Click);
            // 
            // panelMain
            // 
            this.panelMain.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelMain.Controls.Add(this.instruction);
            this.panelMain.Controls.Add(this.systemSounds);
            this.panelMain.Controls.Add(this.importingData);
            this.panelMain.Controls.Add(this.adjustingDesign);
            this.panelMain.Location = new System.Drawing.Point(120, 0);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(1280, 700);
            this.panelMain.TabIndex = 52;
            // 
            // instruction
            // 
            this.instruction.Dock = System.Windows.Forms.DockStyle.Fill;
            this.instruction.Location = new System.Drawing.Point(0, 0);
            this.instruction.Name = "instruction";
            this.instruction.Size = new System.Drawing.Size(1280, 700);
            this.instruction.TabIndex = 54;
            // 
            // systemSounds
            // 
            this.systemSounds.Dock = System.Windows.Forms.DockStyle.Fill;
            this.systemSounds.Location = new System.Drawing.Point(0, 0);
            this.systemSounds.Name = "systemSounds";
            this.systemSounds.Size = new System.Drawing.Size(1280, 700);
            this.systemSounds.TabIndex = 55;
            // 
            // importingData
            // 
            this.importingData.BackColor = System.Drawing.Color.White;
            this.importingData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.importingData.Location = new System.Drawing.Point(0, 0);
            this.importingData.Name = "importingData";
            this.importingData.Size = new System.Drawing.Size(1280, 700);
            this.importingData.TabIndex = 54;
            // 
            // adjustingDesign
            // 
            this.adjustingDesign.BackColor = System.Drawing.Color.White;
            this.adjustingDesign.Dock = System.Windows.Forms.DockStyle.Fill;
            this.adjustingDesign.Location = new System.Drawing.Point(0, 0);
            this.adjustingDesign.Name = "adjustingDesign";
            this.adjustingDesign.Size = new System.Drawing.Size(1280, 700);
            this.adjustingDesign.TabIndex = 51;
            // 
            // Settings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1400, 700);
            this.Controls.Add(this.panelControl);
            this.Controls.Add(this.panelMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Settings";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Settings";
            this.panelControl.ResumeLayout(false);
            this.panelMain.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private Controls.JeanModernButton jeanModernButtonInfo;
        private System.Windows.Forms.Panel panelControl;
        private Controls.JeanModernButton jeanModernButtonFont;
        private Controls.JeanModernButton jeanModernButtonLoad;
        private Controls.JeanModernButton jeanModernButtonSounds;
        private Controls.JeanModernButton jeanModernButtonClose;
        private FormsSettings.adjustingDesign adjustingDesign;
        private System.Windows.Forms.Panel panelMain;
        private FormsSettings.ImportingData importingData;
        private FormsSettings.SystemSounds systemSounds;
        private FormsSettings.instruction instruction;
        private Controls.JeanPanel jeanPanelSide;
    }
}