﻿namespace GymApplicationV2._0
{
    partial class Settings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Settings));
            this.panel2 = new System.Windows.Forms.Panel();
            this.jeanModernButtonSounds = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanModernButtonFont = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanModernButtonLoad = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanModernButtonInfo = new GymApplicationV2._0.Controls.JeanModernButton();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.jeanModernButtonSounds);
            this.panel2.Controls.Add(this.jeanModernButtonFont);
            this.panel2.Controls.Add(this.jeanModernButtonLoad);
            this.panel2.Controls.Add(this.jeanModernButtonInfo);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(114, 637);
            this.panel2.TabIndex = 50;
            // 
            // jeanModernButtonSounds
            // 
            this.jeanModernButtonSounds.BackColor = System.Drawing.SystemColors.Control;
            this.jeanModernButtonSounds.BackgroundColor = System.Drawing.SystemColors.Control;
            this.jeanModernButtonSounds.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("jeanModernButtonSounds.BackgroundImage")));
            this.jeanModernButtonSounds.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.jeanModernButtonSounds.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.jeanModernButtonSounds.BorderRadius = 20;
            this.jeanModernButtonSounds.BorderSize = 0;
            this.jeanModernButtonSounds.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonSounds.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonSounds.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonSounds.Location = new System.Drawing.Point(24, 235);
            this.jeanModernButtonSounds.Name = "jeanModernButtonSounds";
            this.jeanModernButtonSounds.Size = new System.Drawing.Size(69, 60);
            this.jeanModernButtonSounds.TabIndex = 52;
            this.jeanModernButtonSounds.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonSounds.UseVisualStyleBackColor = false;
            this.jeanModernButtonSounds.Click += new System.EventHandler(this.jeanModernButtonSounds_Click);
            // 
            // jeanModernButtonFont
            // 
            this.jeanModernButtonFont.BackColor = System.Drawing.SystemColors.Control;
            this.jeanModernButtonFont.BackgroundColor = System.Drawing.SystemColors.Control;
            this.jeanModernButtonFont.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("jeanModernButtonFont.BackgroundImage")));
            this.jeanModernButtonFont.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.jeanModernButtonFont.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.jeanModernButtonFont.BorderRadius = 20;
            this.jeanModernButtonFont.BorderSize = 0;
            this.jeanModernButtonFont.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonFont.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonFont.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonFont.Location = new System.Drawing.Point(24, 24);
            this.jeanModernButtonFont.Name = "jeanModernButtonFont";
            this.jeanModernButtonFont.Size = new System.Drawing.Size(69, 60);
            this.jeanModernButtonFont.TabIndex = 51;
            this.jeanModernButtonFont.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonFont.UseVisualStyleBackColor = false;
            this.jeanModernButtonFont.Click += new System.EventHandler(this.jeanModernButtonFont_Click);
            // 
            // jeanModernButtonLoad
            // 
            this.jeanModernButtonLoad.BackColor = System.Drawing.SystemColors.Control;
            this.jeanModernButtonLoad.BackgroundColor = System.Drawing.SystemColors.Control;
            this.jeanModernButtonLoad.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("jeanModernButtonLoad.BackgroundImage")));
            this.jeanModernButtonLoad.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.jeanModernButtonLoad.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.jeanModernButtonLoad.BorderRadius = 20;
            this.jeanModernButtonLoad.BorderSize = 0;
            this.jeanModernButtonLoad.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonLoad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonLoad.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonLoad.Location = new System.Drawing.Point(24, 127);
            this.jeanModernButtonLoad.Name = "jeanModernButtonLoad";
            this.jeanModernButtonLoad.Size = new System.Drawing.Size(69, 60);
            this.jeanModernButtonLoad.TabIndex = 50;
            this.jeanModernButtonLoad.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonLoad.UseVisualStyleBackColor = false;
            this.jeanModernButtonLoad.Click += new System.EventHandler(this.jeanModernButtonLoad_Click);
            // 
            // jeanModernButtonInfo
            // 
            this.jeanModernButtonInfo.BackColor = System.Drawing.SystemColors.Control;
            this.jeanModernButtonInfo.BackgroundColor = System.Drawing.SystemColors.Control;
            this.jeanModernButtonInfo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("jeanModernButtonInfo.BackgroundImage")));
            this.jeanModernButtonInfo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.jeanModernButtonInfo.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.jeanModernButtonInfo.BorderRadius = 20;
            this.jeanModernButtonInfo.BorderSize = 0;
            this.jeanModernButtonInfo.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonInfo.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonInfo.Location = new System.Drawing.Point(24, 527);
            this.jeanModernButtonInfo.Name = "jeanModernButtonInfo";
            this.jeanModernButtonInfo.Size = new System.Drawing.Size(69, 60);
            this.jeanModernButtonInfo.TabIndex = 49;
            this.jeanModernButtonInfo.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonInfo.UseVisualStyleBackColor = false;
            this.jeanModernButtonInfo.Click += new System.EventHandler(this.jeanModernButtonInfo_Click);
            // 
            // Settings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1047, 637);
            this.Controls.Add(this.panel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Settings";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Settings";
            this.Load += new System.EventHandler(this.Settings_Load);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private Controls.JeanModernButton jeanModernButtonInfo;
        private System.Windows.Forms.Panel panel2;
        private Controls.JeanModernButton jeanModernButtonFont;
        private Controls.JeanModernButton jeanModernButtonLoad;
        private Controls.JeanModernButton jeanModernButtonSounds;
    }
}