﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Office.Interop.Excel;
using System.IO;
using GymApplicationV2._0.FormsSettings;

namespace GymApplicationV2._0
{
    public partial class Settings : Form
    {  
        public TabPage tabPage;
        
        public Settings()
        {
            InitializeComponent();

            jeanPanelSide.Height = jeanModernButtonFont.Height;
            jeanPanelSide.Top = jeanModernButtonFont.Top;
            adjustingDesign.BringToFront();
        }

        void closed(object sender, FormClosedEventArgs e)
        {
            tabPage?.Parent?.Controls.Remove(tabPage);
        }

        private void Settings_Load(object sender, EventArgs e)
        {

        }

        private void jeanModernButtonFont_Click(object sender, EventArgs e)
        {
            jeanPanelSide.Height = jeanModernButtonFont.Height;
            jeanPanelSide.Top = jeanModernButtonFont.Top;
            adjustingDesign.BringToFront();    
        }

        private void jeanModernButtonLoad_Click(object sender, EventArgs e)
        {
            jeanPanelSide.Height = jeanModernButtonLoad.Height;
            jeanPanelSide.Top = jeanModernButtonLoad.Top;
            importingData.BringToFront();
        }

        private void jeanModernButtonInfo_Click(object sender, EventArgs e)
        {
            jeanPanelSide.Height = jeanModernButtonInfo.Height;
            jeanPanelSide.Top = jeanModernButtonInfo.Top;
            instruction.BringToFront();
        }

        private void jeanModernButtonSounds_Click(object sender, EventArgs e)
        {
            jeanPanelSide.Height = jeanModernButtonSounds.Height;
            jeanPanelSide.Top = jeanModernButtonSounds.Top;
            systemSounds.BringToFront();
        }

        private void jeanModernButtonClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
