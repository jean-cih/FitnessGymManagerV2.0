﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Office.Interop.Excel;
using System.IO;
using GymApplicationV2._0.FormsSettings;

namespace GymApplicationV2._0
{
    public partial class Settings : Form
    {  
        public TabPage tabPage;
        
        public Settings()
        {
            InitializeComponent();

            this.FormClosed += closed;
        }

        void closed(object sender, FormClosedEventArgs e)
        {
            tabPage?.Parent?.Controls.Remove(tabPage);
        }

        private void Settings_Load(object sender, EventArgs e)
        {
            this.IsMdiContainer = true;

            AdjustingDesign adjustingDesign = new AdjustingDesign();
            adjustingDesign.MdiParent = this;
            adjustingDesign.Dock = DockStyle.Fill;
            adjustingDesign.Show();
        }

        private void jeanModernButtonFont_Click(object sender, EventArgs e)
        {
            this.IsMdiContainer = true;

            AdjustingDesign adjustingDesign = new AdjustingDesign();
            adjustingDesign.MdiParent = this;
            adjustingDesign.Dock = DockStyle.Fill;
            adjustingDesign.Show();
        }

        private void jeanModernButtonLoad_Click(object sender, EventArgs e)
        {
            this.IsMdiContainer = true;

            ImportingData importingData = new ImportingData();
            importingData.MdiParent = this;
            importingData.Dock = DockStyle.Fill;
            importingData.Show();
        }

        private void jeanModernButtonInfo_Click(object sender, EventArgs e)
        {
            this.IsMdiContainer = true;

            Instruction instruction = new Instruction();
            instruction.MdiParent = this;
            instruction.Dock = DockStyle.Fill;
            instruction.Show();
        }

        private void jeanModernButtonSounds_Click(object sender, EventArgs e)
        {
            this.IsMdiContainer = true;

            SystemSounds systemSounds = new SystemSounds();
            systemSounds.MdiParent = this;
            systemSounds.Dock = DockStyle.Fill;
            systemSounds.Show();
        }
    }
}
