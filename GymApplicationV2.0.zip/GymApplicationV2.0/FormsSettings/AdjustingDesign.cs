﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace GymApplicationV2._0.FormsSettings
{
    public partial class AdjustingDesign : Form
    {
        string filePathTXT = "AppFiles/Font.txt";
        public AdjustingDesign()
        {
            InitializeComponent();
        }

        private void AdjustingDesign_Load(object sender, EventArgs e)
        {
            comboBoxFontButtons.Text = DataClass.sizeFontButtons.ToString();
            labelFontButtons.Font = new Font("Размер шрифта кнопок", DataClass.sizeFontCaptions);

            comboBoxFontTables.Text = DataClass.sizeFontTables.ToString();
            labelFontTables.Font = new Font("Размер шрифта  таблицы", DataClass.sizeFontCaptions);

            comboBoxFontCaptions.Text = DataClass.sizeFontCaptions.ToString();
            labelFontCaptions.Font = new Font("Размер шрифта надписей", DataClass.sizeFontCaptions);
        }

        private void comboBoxFontCaptions_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataClass.sizeFontCaptions = Convert.ToInt32(comboBoxFontCaptions.Text);
            labelFontCaptions.Font = new Font("Размер шрифта надписей", DataClass.sizeFontCaptions);
            labelFontButtons.Font = new Font("Размер шрифта кнопок", DataClass.sizeFontCaptions);
            labelFontTables.Font = new Font("Размер шрифта  таблицы", DataClass.sizeFontCaptions);
            string[] lines = File.ReadAllLines(filePathTXT);
            lines[3] = comboBoxFontCaptions.Text;
            File.WriteAllLines(filePathTXT, lines);
        }

        private void comboBoxFontButtons_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataClass.sizeFontButtons = Convert.ToInt32(comboBoxFontButtons.Text);
            
            string[] lines = File.ReadAllLines(filePathTXT);
            lines[5] = comboBoxFontButtons.Text;
            File.WriteAllLines(filePathTXT, lines);
        }

        private void comboBoxFontTables_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataClass.sizeFontTables = Convert.ToInt32(comboBoxFontTables.Text);
            
            string[] lines = File.ReadAllLines(filePathTXT);
            lines[7] = comboBoxFontTables.Text;
            File.WriteAllLines(filePathTXT, lines);
        }
    }
}
