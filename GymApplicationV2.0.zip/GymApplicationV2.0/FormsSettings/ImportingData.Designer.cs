﻿namespace GymApplicationV2._0.FormsSettings
{
    partial class ImportingData
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.jeanModernButtonImport = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanModernButtonChooseFile = new GymApplicationV2._0.Controls.JeanModernButton();
            this.labelImport = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // jeanModernButtonImport
            // 
            this.jeanModernButtonImport.BackColor = System.Drawing.Color.White;
            this.jeanModernButtonImport.BackgroundColor = System.Drawing.Color.White;
            this.jeanModernButtonImport.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButtonImport.BorderRadius = 20;
            this.jeanModernButtonImport.BorderSize = 2;
            this.jeanModernButtonImport.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonImport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonImport.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonImport.ForeColor = System.Drawing.Color.Black;
            this.jeanModernButtonImport.Location = new System.Drawing.Point(622, 401);
            this.jeanModernButtonImport.Name = "jeanModernButtonImport";
            this.jeanModernButtonImport.Size = new System.Drawing.Size(150, 50);
            this.jeanModernButtonImport.TabIndex = 51;
            this.jeanModernButtonImport.Text = "Загрузить";
            this.jeanModernButtonImport.TextColor = System.Drawing.Color.Black;
            this.jeanModernButtonImport.UseVisualStyleBackColor = false;
            this.jeanModernButtonImport.Click += new System.EventHandler(this.jeanModernButtonImport_Click);
            // 
            // jeanModernButtonChooseFile
            // 
            this.jeanModernButtonChooseFile.BackColor = System.Drawing.Color.White;
            this.jeanModernButtonChooseFile.BackgroundColor = System.Drawing.Color.White;
            this.jeanModernButtonChooseFile.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButtonChooseFile.BorderRadius = 20;
            this.jeanModernButtonChooseFile.BorderSize = 2;
            this.jeanModernButtonChooseFile.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonChooseFile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonChooseFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonChooseFile.ForeColor = System.Drawing.Color.Black;
            this.jeanModernButtonChooseFile.Location = new System.Drawing.Point(466, 401);
            this.jeanModernButtonChooseFile.Name = "jeanModernButtonChooseFile";
            this.jeanModernButtonChooseFile.Size = new System.Drawing.Size(150, 50);
            this.jeanModernButtonChooseFile.TabIndex = 50;
            this.jeanModernButtonChooseFile.Text = "Выбрать";
            this.jeanModernButtonChooseFile.TextColor = System.Drawing.Color.Black;
            this.jeanModernButtonChooseFile.UseVisualStyleBackColor = false;
            this.jeanModernButtonChooseFile.Click += new System.EventHandler(this.jeanModernButtonChooseFile_Click);
            // 
            // labelImport
            // 
            this.labelImport.AutoSize = true;
            this.labelImport.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelImport.Location = new System.Drawing.Point(503, 374);
            this.labelImport.Name = "labelImport";
            this.labelImport.Size = new System.Drawing.Size(211, 20);
            this.labelImport.TabIndex = 49;
            this.labelImport.Text = "Импортировать данные";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(77, 92);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(661, 29);
            this.label1.TabIndex = 52;
            this.label1.Text = "Импортирование всех возможных используемых таблиц";
            // 
            // ImportingData
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(938, 580);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.jeanModernButtonImport);
            this.Controls.Add(this.jeanModernButtonChooseFile);
            this.Controls.Add(this.labelImport);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ImportingData";
            this.Load += new System.EventHandler(this.ImportingData_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Controls.JeanModernButton jeanModernButtonImport;
        private Controls.JeanModernButton jeanModernButtonChooseFile;
        private System.Windows.Forms.Label labelImport;
        private System.Windows.Forms.Label label1;
    }
}