﻿namespace GymApplicationV2._0.FormsSettings
{
    partial class ImportingData
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.jeanPanelInf = new GymApplicationV2._0.Controls.JeanPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.listBox = new System.Windows.Forms.ListBox();
            this.pictureBoxArrow = new System.Windows.Forms.PictureBox();
            this.jeanModernButtonInf = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanModernButtonImport = new GymApplicationV2._0.Controls.JeanModernButton();
            this.jeanModernButtonChooseFile = new GymApplicationV2._0.Controls.JeanModernButton();
            this.labelImport = new System.Windows.Forms.Label();
            this.jeanPanelInf.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxArrow)).BeginInit();
            this.SuspendLayout();
            // 
            // jeanPanelInf
            // 
            this.jeanPanelInf.BackColor = System.Drawing.Color.White;
            this.jeanPanelInf.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.jeanPanelInf.BorderRadius = 30;
            this.jeanPanelInf.Controls.Add(this.label1);
            this.jeanPanelInf.Controls.Add(this.listBox);
            this.jeanPanelInf.ForeColor = System.Drawing.Color.Black;
            this.jeanPanelInf.GradientAngle = 90F;
            this.jeanPanelInf.GradientBottomColor = System.Drawing.Color.White;
            this.jeanPanelInf.GradientTapColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            this.jeanPanelInf.Location = new System.Drawing.Point(19, 65);
            this.jeanPanelInf.Name = "jeanPanelInf";
            this.jeanPanelInf.Size = new System.Drawing.Size(1026, 611);
            this.jeanPanelInf.TabIndex = 61;
            this.jeanPanelInf.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(302, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(400, 25);
            this.label1.TabIndex = 50;
            this.label1.Text = "ИНСТРУКЦИЯ ПО ЗАГРУЗКЕ ДАННЫХ";
            // 
            // listBox
            // 
            this.listBox.BackColor = System.Drawing.Color.White;
            this.listBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.listBox.FormattingEnabled = true;
            this.listBox.ItemHeight = 25;
            this.listBox.Items.AddRange(new object[] {
            "СЕГОДНЯ У МЕНЯ ОТЛИЧНЫЙ ДЕНЬ, ВООБЩЕ ЗДЕСЬ ДОЛЖНА БЫТЬ ИНСТРУКЦИЯ",
            "ПО ЗАГРУЗКЕ, НО ТАК КАК У МЕНЯ СЕГОДНЯ ХОРОШИЙ ДЕНЬ, Т К Я НЕ ПОШЕЛ В ",
            "УНИВЕР И ТЕПЕРЬ У МЕНЯ ВЫХОДНОЙ, ТО НАПИШУ ИНСТРУКЦИЮ КАК-НИБУДЬ",
            " ПОТОМ, МОЖЕТ ЧЕРЕЗ ПАРУ ЧАСОВ, А ПОКА ПРОСТО СДЕЛАЮ ОСНОВНОЕ",
            "ВООБЩЕ Я УЖЕ СДЕЛАЛ И СЕЙЧАС НЕ ПОНИМАЮ КРАСИВО ЭТО ИЛИ НЕТ, ",
            "ВСЕ-ТАКИ ДУМАЮ ЧТО ЭТО ABHORRENT BUT I CAN HARDLY IMAGINE HOW IT ",
            "MUST BE THE POINT OF DESIGN SO NOW I AM JUST TRYING TO TEST ",
            "THIS PROGRAM, IF YOU WANT TO HEAR IT MORE DISTANTLY I AM TESTING ",
            "THIS FORM WITH LOADING DATA",
            "СЕГОДНЯ У МЕНЯ ОТЛИЧНЫЙ ДЕНЬ, ВООБЩЕ ЗДЕСЬ ДОЛЖНА БЫТЬ ИНСТРУКЦИЯ",
            "ПО ЗАГРУЗКЕ, НО ТАК КАК У МЕНЯ СЕГОДНЯ ХОРОШИЙ ДЕНЬ, Т К Я НЕ ПОШЕЛ В ",
            "УНИВЕР И ТЕПЕРЬ У МЕНЯ ВЫХОДНОЙ, ТО НАПИШУ ИНСТРУКЦИЮ КАК-НИБУДЬ",
            " ПОТОМ, МОЖЕТ ЧЕРЕЗ ПАРУ ЧАСОВ, А ПОКА ПРОСТО СДЕЛАЮ ОСНОВНОЕ",
            "ВООБЩЕ Я УЖЕ СДЕЛАЛ И СЕЙЧАС НЕ ПОНИМАЮ КРАСИВО ЭТО ИЛИ НЕТ, ",
            "ВСЕ-ТАКИ ДУМАЮ ЧТО ЭТО ABHORRENT BUT I CAN HARDLY IMAGINE HOW IT ",
            "MUST BE THE POINT OF DESIGN SO NOW I AM JUST TRYING TO TEST ",
            "THIS PROGRAM, IF YOU WANT TO HEAR IT MORE DISTANTLY I AM TESTING ",
            "THIS FORM WITH LOADING DATA",
            "СЕГОДНЯ У МЕНЯ ОТЛИЧНЫЙ ДЕНЬ, ВООБЩЕ ЗДЕСЬ ДОЛЖНА БЫТЬ ИНСТРУКЦИЯ",
            "ПО ЗАГРУЗКЕ, НО ТАК КАК У МЕНЯ СЕГОДНЯ ХОРОШИЙ ДЕНЬ, Т К Я НЕ ПОШЕЛ В ",
            "УНИВЕР И ТЕПЕРЬ У МЕНЯ ВЫХОДНОЙ, ТО НАПИШУ ИНСТРУКЦИЮ КАК-НИБУДЬ",
            " ПОТОМ, МОЖЕТ ЧЕРЕЗ ПАРУ ЧАСОВ, А ПОКА ПРОСТО СДЕЛАЮ ОСНОВНОЕ",
            "ВООБЩЕ Я УЖЕ СДЕЛАЛ И СЕЙЧАС НЕ ПОНИМАЮ КРАСИВО ЭТО ИЛИ НЕТ, ",
            "ВСЕ-ТАКИ ДУМАЮ ЧТО ЭТО ABHORRENT BUT I CAN HARDLY IMAGINE HOW IT ",
            "MUST BE THE POINT OF DESIGN SO NOW I AM JUST TRYING TO TEST ",
            "THIS PROGRAM, IF YOU WANT TO HEAR IT MORE DISTANTLY I AM TESTING ",
            "THIS FORM WITH LOADING DATA",
            "СЕГОДНЯ У МЕНЯ ОТЛИЧНЫЙ ДЕНЬ, ВООБЩЕ ЗДЕСЬ ДОЛЖНА БЫТЬ ИНСТРУКЦИЯ",
            "ПО ЗАГРУЗКЕ, НО ТАК КАК У МЕНЯ СЕГОДНЯ ХОРОШИЙ ДЕНЬ, Т К Я НЕ ПОШЕЛ В ",
            "УНИВЕР И ТЕПЕРЬ У МЕНЯ ВЫХОДНОЙ, ТО НАПИШУ ИНСТРУКЦИЮ КАК-НИБУДЬ",
            " ПОТОМ, МОЖЕТ ЧЕРЕЗ ПАРУ ЧАСОВ, А ПОКА ПРОСТО СДЕЛАЮ ОСНОВНОЕ",
            "ВООБЩЕ Я УЖЕ СДЕЛАЛ И СЕЙЧАС НЕ ПОНИМАЮ КРАСИВО ЭТО ИЛИ НЕТ, ",
            "ВСЕ-ТАКИ ДУМАЮ ЧТО ЭТО ABHORRENT BUT I CAN HARDLY IMAGINE HOW IT ",
            "MUST BE THE POINT OF DESIGN SO NOW I AM JUST TRYING TO TEST ",
            "THIS PROGRAM, IF YOU WANT TO HEAR IT MORE DISTANTLY I AM TESTING ",
            "THIS FORM WITH LOADING DATA",
            "СЕГОДНЯ У МЕНЯ ОТЛИЧНЫЙ ДЕНЬ, ВООБЩЕ ЗДЕСЬ ДОЛЖНА БЫТЬ ИНСТРУКЦИЯ",
            "ПО ЗАГРУЗКЕ, НО ТАК КАК У МЕНЯ СЕГОДНЯ ХОРОШИЙ ДЕНЬ, Т К Я НЕ ПОШЕЛ В ",
            "УНИВЕР И ТЕПЕРЬ У МЕНЯ ВЫХОДНОЙ, ТО НАПИШУ ИНСТРУКЦИЮ КАК-НИБУДЬ",
            " ПОТОМ, МОЖЕТ ЧЕРЕЗ ПАРУ ЧАСОВ, А ПОКА ПРОСТО СДЕЛАЮ ОСНОВНОЕ",
            "ВООБЩЕ Я УЖЕ СДЕЛАЛ И СЕЙЧАС НЕ ПОНИМАЮ КРАСИВО ЭТО ИЛИ НЕТ, ",
            "ВСЕ-ТАКИ ДУМАЮ ЧТО ЭТО ABHORRENT BUT I CAN HARDLY IMAGINE HOW IT ",
            "MUST BE THE POINT OF DESIGN SO NOW I AM JUST TRYING TO TEST ",
            "THIS PROGRAM, IF YOU WANT TO HEAR IT MORE DISTANTLY I AM TESTING ",
            "THIS FORM WITH LOADING DATA",
            "СЕГОДНЯ У МЕНЯ ОТЛИЧНЫЙ ДЕНЬ, ВООБЩЕ ЗДЕСЬ ДОЛЖНА БЫТЬ ИНСТРУКЦИЯ",
            "ПО ЗАГРУЗКЕ, НО ТАК КАК У МЕНЯ СЕГОДНЯ ХОРОШИЙ ДЕНЬ, Т К Я НЕ ПОШЕЛ В ",
            "УНИВЕР И ТЕПЕРЬ У МЕНЯ ВЫХОДНОЙ, ТО НАПИШУ ИНСТРУКЦИЮ КАК-НИБУДЬ",
            " ПОТОМ, МОЖЕТ ЧЕРЕЗ ПАРУ ЧАСОВ, А ПОКА ПРОСТО СДЕЛАЮ ОСНОВНОЕ",
            "ВООБЩЕ Я УЖЕ СДЕЛАЛ И СЕЙЧАС НЕ ПОНИМАЮ КРАСИВО ЭТО ИЛИ НЕТ, ",
            "ВСЕ-ТАКИ ДУМАЮ ЧТО ЭТО ABHORRENT BUT I CAN HARDLY IMAGINE HOW IT ",
            "MUST BE THE POINT OF DESIGN SO NOW I AM JUST TRYING TO TEST ",
            "THIS PROGRAM, IF YOU WANT TO HEAR IT MORE DISTANTLY I AM TESTING ",
            "THIS FORM WITH LOADING DATA",
            "СЕГОДНЯ У МЕНЯ ОТЛИЧНЫЙ ДЕНЬ, ВООБЩЕ ЗДЕСЬ ДОЛЖНА БЫТЬ ИНСТРУКЦИЯ",
            "ПО ЗАГРУЗКЕ, НО ТАК КАК У МЕНЯ СЕГОДНЯ ХОРОШИЙ ДЕНЬ, Т К Я НЕ ПОШЕЛ В ",
            "УНИВЕР И ТЕПЕРЬ У МЕНЯ ВЫХОДНОЙ, ТО НАПИШУ ИНСТРУКЦИЮ КАК-НИБУДЬ",
            " ПОТОМ, МОЖЕТ ЧЕРЕЗ ПАРУ ЧАСОВ, А ПОКА ПРОСТО СДЕЛАЮ ОСНОВНОЕ",
            "ВООБЩЕ Я УЖЕ СДЕЛАЛ И СЕЙЧАС НЕ ПОНИМАЮ КРАСИВО ЭТО ИЛИ НЕТ, ",
            "ВСЕ-ТАКИ ДУМАЮ ЧТО ЭТО ABHORRENT BUT I CAN HARDLY IMAGINE HOW IT ",
            "MUST BE THE POINT OF DESIGN SO NOW I AM JUST TRYING TO TEST ",
            "THIS PROGRAM, IF YOU WANT TO HEAR IT MORE DISTANTLY I AM TESTING ",
            "THIS FORM WITH LOADING DATA",
            "СЕГОДНЯ У МЕНЯ ОТЛИЧНЫЙ ДЕНЬ, ВООБЩЕ ЗДЕСЬ ДОЛЖНА БЫТЬ ИНСТРУКЦИЯ",
            "ПО ЗАГРУЗКЕ, НО ТАК КАК У МЕНЯ СЕГОДНЯ ХОРОШИЙ ДЕНЬ, Т К Я НЕ ПОШЕЛ В ",
            "УНИВЕР И ТЕПЕРЬ У МЕНЯ ВЫХОДНОЙ, ТО НАПИШУ ИНСТРУКЦИЮ КАК-НИБУДЬ",
            " ПОТОМ, МОЖЕТ ЧЕРЕЗ ПАРУ ЧАСОВ, А ПОКА ПРОСТО СДЕЛАЮ ОСНОВНОЕ",
            "ВООБЩЕ Я УЖЕ СДЕЛАЛ И СЕЙЧАС НЕ ПОНИМАЮ КРАСИВО ЭТО ИЛИ НЕТ, ",
            "ВСЕ-ТАКИ ДУМАЮ ЧТО ЭТО ABHORRENT BUT I CAN HARDLY IMAGINE HOW IT ",
            "MUST BE THE POINT OF DESIGN SO NOW I AM JUST TRYING TO TEST ",
            "THIS PROGRAM, IF YOU WANT TO HEAR IT MORE DISTANTLY I AM TESTING ",
            "THIS FORM WITH LOADING DATA",
            "СЕГОДНЯ У МЕНЯ ОТЛИЧНЫЙ ДЕНЬ, ВООБЩЕ ЗДЕСЬ ДОЛЖНА БЫТЬ ИНСТРУКЦИЯ",
            "ПО ЗАГРУЗКЕ, НО ТАК КАК У МЕНЯ СЕГОДНЯ ХОРОШИЙ ДЕНЬ, Т К Я НЕ ПОШЕЛ В ",
            "УНИВЕР И ТЕПЕРЬ У МЕНЯ ВЫХОДНОЙ, ТО НАПИШУ ИНСТРУКЦИЮ КАК-НИБУДЬ",
            " ПОТОМ, МОЖЕТ ЧЕРЕЗ ПАРУ ЧАСОВ, А ПОКА ПРОСТО СДЕЛАЮ ОСНОВНОЕ",
            "ВООБЩЕ Я УЖЕ СДЕЛАЛ И СЕЙЧАС НЕ ПОНИМАЮ КРАСИВО ЭТО ИЛИ НЕТ, ",
            "ВСЕ-ТАКИ ДУМАЮ ЧТО ЭТО ABHORRENT BUT I CAN HARDLY IMAGINE HOW IT ",
            "MUST BE THE POINT OF DESIGN SO NOW I AM JUST TRYING TO TEST ",
            "THIS PROGRAM, IF YOU WANT TO HEAR IT MORE DISTANTLY I AM TESTING ",
            "THIS FORM WITH LOADING DATA",
            "СЕГОДНЯ У МЕНЯ ОТЛИЧНЫЙ ДЕНЬ, ВООБЩЕ ЗДЕСЬ ДОЛЖНА БЫТЬ ИНСТРУКЦИЯ",
            "ПО ЗАГРУЗКЕ, НО ТАК КАК У МЕНЯ СЕГОДНЯ ХОРОШИЙ ДЕНЬ, Т К Я НЕ ПОШЕЛ В ",
            "УНИВЕР И ТЕПЕРЬ У МЕНЯ ВЫХОДНОЙ, ТО НАПИШУ ИНСТРУКЦИЮ КАК-НИБУДЬ",
            " ПОТОМ, МОЖЕТ ЧЕРЕЗ ПАРУ ЧАСОВ, А ПОКА ПРОСТО СДЕЛАЮ ОСНОВНОЕ",
            "ВООБЩЕ Я УЖЕ СДЕЛАЛ И СЕЙЧАС НЕ ПОНИМАЮ КРАСИВО ЭТО ИЛИ НЕТ, ",
            "ВСЕ-ТАКИ ДУМАЮ ЧТО ЭТО ABHORRENT BUT I CAN HARDLY IMAGINE HOW IT ",
            "MUST BE THE POINT OF DESIGN SO NOW I AM JUST TRYING TO TEST ",
            "THIS PROGRAM, IF YOU WANT TO HEAR IT MORE DISTANTLY I AM TESTING ",
            "THIS FORM WITH LOADING DATA",
            "СЕГОДНЯ У МЕНЯ ОТЛИЧНЫЙ ДЕНЬ, ВООБЩЕ ЗДЕСЬ ДОЛЖНА БЫТЬ ИНСТРУКЦИЯ",
            "ПО ЗАГРУЗКЕ, НО ТАК КАК У МЕНЯ СЕГОДНЯ ХОРОШИЙ ДЕНЬ, Т К Я НЕ ПОШЕЛ В ",
            "УНИВЕР И ТЕПЕРЬ У МЕНЯ ВЫХОДНОЙ, ТО НАПИШУ ИНСТРУКЦИЮ КАК-НИБУДЬ",
            " ПОТОМ, МОЖЕТ ЧЕРЕЗ ПАРУ ЧАСОВ, А ПОКА ПРОСТО СДЕЛАЮ ОСНОВНОЕ",
            "ВООБЩЕ Я УЖЕ СДЕЛАЛ И СЕЙЧАС НЕ ПОНИМАЮ КРАСИВО ЭТО ИЛИ НЕТ, ",
            "ВСЕ-ТАКИ ДУМАЮ ЧТО ЭТО ABHORRENT BUT I CAN HARDLY IMAGINE HOW IT ",
            "MUST BE THE POINT OF DESIGN SO NOW I AM JUST TRYING TO TEST ",
            "THIS PROGRAM, IF YOU WANT TO HEAR IT MORE DISTANTLY I AM TESTING ",
            "THIS FORM WITH LOADING DATA"});
            this.listBox.Location = new System.Drawing.Point(21, 70);
            this.listBox.Name = "listBox";
            this.listBox.Size = new System.Drawing.Size(983, 350);
            this.listBox.TabIndex = 0;
            // 
            // pictureBoxArrow
            // 
            this.pictureBoxArrow.Image = global::GymApplicationV2._0.Properties.Resources.Arrow;
            this.pictureBoxArrow.Location = new System.Drawing.Point(1194, 98);
            this.pictureBoxArrow.Name = "pictureBoxArrow";
            this.pictureBoxArrow.Size = new System.Drawing.Size(48, 69);
            this.pictureBoxArrow.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxArrow.TabIndex = 60;
            this.pictureBoxArrow.TabStop = false;
            // 
            // jeanModernButtonInf
            // 
            this.jeanModernButtonInf.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.jeanModernButtonInf.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.jeanModernButtonInf.BackgroundImage = global::GymApplicationV2._0.Properties.Resources.LoadInstruction;
            this.jeanModernButtonInf.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.jeanModernButtonInf.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.jeanModernButtonInf.BorderRadius = 20;
            this.jeanModernButtonInf.BorderSize = 0;
            this.jeanModernButtonInf.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonInf.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonInf.ForeColor = System.Drawing.Color.White;
            this.jeanModernButtonInf.Location = new System.Drawing.Point(1168, 24);
            this.jeanModernButtonInf.Name = "jeanModernButtonInf";
            this.jeanModernButtonInf.Size = new System.Drawing.Size(94, 66);
            this.jeanModernButtonInf.TabIndex = 59;
            this.jeanModernButtonInf.TextColor = System.Drawing.Color.White;
            this.jeanModernButtonInf.UseVisualStyleBackColor = false;
            this.jeanModernButtonInf.Click += new System.EventHandler(this.jeanModernButtonFont_Click);
            // 
            // jeanModernButtonImport
            // 
            this.jeanModernButtonImport.BackColor = System.Drawing.Color.White;
            this.jeanModernButtonImport.BackgroundColor = System.Drawing.Color.White;
            this.jeanModernButtonImport.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButtonImport.BorderRadius = 20;
            this.jeanModernButtonImport.BorderSize = 2;
            this.jeanModernButtonImport.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonImport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonImport.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonImport.ForeColor = System.Drawing.Color.Black;
            this.jeanModernButtonImport.Location = new System.Drawing.Point(1103, 622);
            this.jeanModernButtonImport.Name = "jeanModernButtonImport";
            this.jeanModernButtonImport.Size = new System.Drawing.Size(150, 50);
            this.jeanModernButtonImport.TabIndex = 58;
            this.jeanModernButtonImport.Text = "Загрузить";
            this.jeanModernButtonImport.TextColor = System.Drawing.Color.Black;
            this.jeanModernButtonImport.UseVisualStyleBackColor = false;
            this.jeanModernButtonImport.Click += new System.EventHandler(this.jeanModernButtonImport_Click);
            // 
            // jeanModernButtonChooseFile
            // 
            this.jeanModernButtonChooseFile.BackColor = System.Drawing.Color.White;
            this.jeanModernButtonChooseFile.BackgroundColor = System.Drawing.Color.White;
            this.jeanModernButtonChooseFile.BorderColor = System.Drawing.Color.DarkOrange;
            this.jeanModernButtonChooseFile.BorderRadius = 20;
            this.jeanModernButtonChooseFile.BorderSize = 2;
            this.jeanModernButtonChooseFile.FlatAppearance.BorderSize = 0;
            this.jeanModernButtonChooseFile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jeanModernButtonChooseFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jeanModernButtonChooseFile.ForeColor = System.Drawing.Color.Black;
            this.jeanModernButtonChooseFile.Location = new System.Drawing.Point(1103, 566);
            this.jeanModernButtonChooseFile.Name = "jeanModernButtonChooseFile";
            this.jeanModernButtonChooseFile.Size = new System.Drawing.Size(150, 50);
            this.jeanModernButtonChooseFile.TabIndex = 57;
            this.jeanModernButtonChooseFile.Text = "Выбрать";
            this.jeanModernButtonChooseFile.TextColor = System.Drawing.Color.Black;
            this.jeanModernButtonChooseFile.UseVisualStyleBackColor = false;
            this.jeanModernButtonChooseFile.Click += new System.EventHandler(this.jeanModernButtonChooseFile_Click);
            // 
            // labelImport
            // 
            this.labelImport.AutoSize = true;
            this.labelImport.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelImport.Location = new System.Drawing.Point(525, 26);
            this.labelImport.Name = "labelImport";
            this.labelImport.Size = new System.Drawing.Size(257, 25);
            this.labelImport.TabIndex = 56;
            this.labelImport.Text = "Импортировать данные";
            // 
            // ImportingData
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.jeanPanelInf);
            this.Controls.Add(this.pictureBoxArrow);
            this.Controls.Add(this.jeanModernButtonInf);
            this.Controls.Add(this.jeanModernButtonImport);
            this.Controls.Add(this.jeanModernButtonChooseFile);
            this.Controls.Add(this.labelImport);
            this.Name = "ImportingData";
            this.Size = new System.Drawing.Size(1280, 700);
            this.Load += new System.EventHandler(this.ImportingData_Load);
            this.jeanPanelInf.ResumeLayout(false);
            this.jeanPanelInf.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxArrow)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Controls.JeanPanel jeanPanelInf;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox listBox;
        private System.Windows.Forms.PictureBox pictureBoxArrow;
        private Controls.JeanModernButton jeanModernButtonInf;
        private Controls.JeanModernButton jeanModernButtonImport;
        private Controls.JeanModernButton jeanModernButtonChooseFile;
        private System.Windows.Forms.Label labelImport;
    }
}
