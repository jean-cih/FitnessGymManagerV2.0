﻿namespace GymApplicationV2._0
{
    partial class Report
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Report));
            this.buttonShow = new System.Windows.Forms.Button();
            this.labelVisited = new System.Windows.Forms.Label();
            this.labelServices = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panelVisited = new System.Windows.Forms.Panel();
            this.radioForMonth = new System.Windows.Forms.RadioButton();
            this.radioForDay = new System.Windows.Forms.RadioButton();
            this.radioForWeek = new System.Windows.Forms.RadioButton();
            this.dateTimePickerBegin = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerEnd = new System.Windows.Forms.DateTimePicker();
            this.labelWith = new System.Windows.Forms.Label();
            this.labelTo = new System.Windows.Forms.Label();
            this.radioOtherPeriod = new System.Windows.Forms.RadioButton();
            this.checkBoxAllClients = new System.Windows.Forms.CheckBox();
            this.checkBoxClientsForPeriod = new System.Windows.Forms.CheckBox();
            this.checkBoxSellServices = new System.Windows.Forms.CheckBox();
            this.panel1.SuspendLayout();
            this.panelVisited.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonShow
            // 
            this.buttonShow.Location = new System.Drawing.Point(634, 455);
            this.buttonShow.Name = "buttonShow";
            this.buttonShow.Size = new System.Drawing.Size(140, 63);
            this.buttonShow.TabIndex = 8;
            this.buttonShow.Text = "Показать";
            this.buttonShow.UseVisualStyleBackColor = true;
            this.buttonShow.Click += new System.EventHandler(this.buttonShow_Click);
            // 
            // labelVisited
            // 
            this.labelVisited.AutoSize = true;
            this.labelVisited.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelVisited.Location = new System.Drawing.Point(33, 37);
            this.labelVisited.Name = "labelVisited";
            this.labelVisited.Size = new System.Drawing.Size(105, 20);
            this.labelVisited.TabIndex = 11;
            this.labelVisited.Text = "Посещения";
            // 
            // labelServices
            // 
            this.labelServices.AutoSize = true;
            this.labelServices.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelServices.Location = new System.Drawing.Point(33, 39);
            this.labelServices.Name = "labelServices";
            this.labelServices.Size = new System.Drawing.Size(188, 20);
            this.labelServices.TabIndex = 12;
            this.labelServices.Text = "Абонементы и услуги";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.checkBoxSellServices);
            this.panel1.Controls.Add(this.labelServices);
            this.panel1.Location = new System.Drawing.Point(9, 250);
            this.panel1.Margin = new System.Windows.Forms.Padding(5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(329, 268);
            this.panel1.TabIndex = 14;
            // 
            // panelVisited
            // 
            this.panelVisited.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelVisited.Controls.Add(this.radioOtherPeriod);
            this.panelVisited.Controls.Add(this.labelTo);
            this.panelVisited.Controls.Add(this.checkBoxClientsForPeriod);
            this.panelVisited.Controls.Add(this.labelWith);
            this.panelVisited.Controls.Add(this.checkBoxAllClients);
            this.panelVisited.Controls.Add(this.dateTimePickerEnd);
            this.panelVisited.Controls.Add(this.labelVisited);
            this.panelVisited.Controls.Add(this.dateTimePickerBegin);
            this.panelVisited.Controls.Add(this.radioForWeek);
            this.panelVisited.Controls.Add(this.radioForDay);
            this.panelVisited.Controls.Add(this.radioForMonth);
            this.panelVisited.Location = new System.Drawing.Point(9, 9);
            this.panelVisited.Name = "panelVisited";
            this.panelVisited.Size = new System.Drawing.Size(961, 233);
            this.panelVisited.TabIndex = 20;
            // 
            // radioForMonth
            // 
            this.radioForMonth.AutoSize = true;
            this.radioForMonth.Location = new System.Drawing.Point(624, 37);
            this.radioForMonth.Name = "radioForMonth";
            this.radioForMonth.Size = new System.Drawing.Size(87, 20);
            this.radioForMonth.TabIndex = 21;
            this.radioForMonth.Text = "За месяц";
            this.radioForMonth.UseVisualStyleBackColor = true;
            // 
            // radioForDay
            // 
            this.radioForDay.AutoSize = true;
            this.radioForDay.Location = new System.Drawing.Point(624, 97);
            this.radioForDay.Name = "radioForDay";
            this.radioForDay.Size = new System.Drawing.Size(79, 20);
            this.radioForDay.TabIndex = 22;
            this.radioForDay.Text = "За день";
            this.radioForDay.UseVisualStyleBackColor = true;
            // 
            // radioForWeek
            // 
            this.radioForWeek.AutoSize = true;
            this.radioForWeek.Location = new System.Drawing.Point(624, 67);
            this.radioForWeek.Name = "radioForWeek";
            this.radioForWeek.Size = new System.Drawing.Size(98, 20);
            this.radioForWeek.TabIndex = 23;
            this.radioForWeek.Text = "За неделю";
            this.radioForWeek.UseVisualStyleBackColor = true;
            // 
            // dateTimePickerBegin
            // 
            this.dateTimePickerBegin.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerBegin.Location = new System.Drawing.Point(631, 160);
            this.dateTimePickerBegin.MaxDate = new System.DateTime(2100, 12, 31, 0, 0, 0, 0);
            this.dateTimePickerBegin.MinDate = new System.DateTime(2022, 1, 1, 0, 0, 0, 0);
            this.dateTimePickerBegin.Name = "dateTimePickerBegin";
            this.dateTimePickerBegin.Size = new System.Drawing.Size(109, 22);
            this.dateTimePickerBegin.TabIndex = 24;
            // 
            // dateTimePickerEnd
            // 
            this.dateTimePickerEnd.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerEnd.Location = new System.Drawing.Point(791, 160);
            this.dateTimePickerEnd.MaxDate = new System.DateTime(2100, 12, 31, 0, 0, 0, 0);
            this.dateTimePickerEnd.MinDate = new System.DateTime(2022, 1, 1, 0, 0, 0, 0);
            this.dateTimePickerEnd.Name = "dateTimePickerEnd";
            this.dateTimePickerEnd.Size = new System.Drawing.Size(109, 22);
            this.dateTimePickerEnd.TabIndex = 25;
            // 
            // labelWith
            // 
            this.labelWith.AutoSize = true;
            this.labelWith.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelWith.Location = new System.Drawing.Point(603, 160);
            this.labelWith.Name = "labelWith";
            this.labelWith.Size = new System.Drawing.Size(18, 20);
            this.labelWith.TabIndex = 20;
            this.labelWith.Text = "с";
            // 
            // labelTo
            // 
            this.labelTo.AutoSize = true;
            this.labelTo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelTo.Location = new System.Drawing.Point(749, 160);
            this.labelTo.Name = "labelTo";
            this.labelTo.Size = new System.Drawing.Size(29, 20);
            this.labelTo.TabIndex = 26;
            this.labelTo.Text = "по";
            // 
            // radioOtherPeriod
            // 
            this.radioOtherPeriod.AutoSize = true;
            this.radioOtherPeriod.Checked = true;
            this.radioOtherPeriod.Location = new System.Drawing.Point(624, 127);
            this.radioOtherPeriod.Name = "radioOtherPeriod";
            this.radioOtherPeriod.Size = new System.Drawing.Size(126, 20);
            this.radioOtherPeriod.TabIndex = 27;
            this.radioOtherPeriod.TabStop = true;
            this.radioOtherPeriod.Text = "Другой период";
            this.radioOtherPeriod.UseVisualStyleBackColor = true;
            // 
            // checkBoxAllClients
            // 
            this.checkBoxAllClients.AutoSize = true;
            this.checkBoxAllClients.Checked = true;
            this.checkBoxAllClients.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxAllClients.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBoxAllClients.Location = new System.Drawing.Point(56, 84);
            this.checkBoxAllClients.Name = "checkBoxAllClients";
            this.checkBoxAllClients.Size = new System.Drawing.Size(138, 24);
            this.checkBoxAllClients.TabIndex = 21;
            this.checkBoxAllClients.Text = "Все клиенты";
            this.checkBoxAllClients.UseVisualStyleBackColor = true;
            this.checkBoxAllClients.CheckedChanged += new System.EventHandler(this.checkBoxAllClients_CheckedChanged);
            // 
            // checkBoxClientsForPeriod
            // 
            this.checkBoxClientsForPeriod.AutoSize = true;
            this.checkBoxClientsForPeriod.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBoxClientsForPeriod.Location = new System.Drawing.Point(56, 137);
            this.checkBoxClientsForPeriod.Name = "checkBoxClientsForPeriod";
            this.checkBoxClientsForPeriod.Size = new System.Drawing.Size(232, 24);
            this.checkBoxClientsForPeriod.TabIndex = 22;
            this.checkBoxClientsForPeriod.Text = "Посещаемость по дням";
            this.checkBoxClientsForPeriod.UseVisualStyleBackColor = true;
            this.checkBoxClientsForPeriod.CheckedChanged += new System.EventHandler(this.checkBoxClientsForPeriod_CheckedChanged);
            // 
            // checkBoxSellServices
            // 
            this.checkBoxSellServices.AutoSize = true;
            this.checkBoxSellServices.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBoxSellServices.Location = new System.Drawing.Point(56, 94);
            this.checkBoxSellServices.Name = "checkBoxSellServices";
            this.checkBoxSellServices.Size = new System.Drawing.Size(228, 24);
            this.checkBoxSellServices.TabIndex = 24;
            this.checkBoxSellServices.Text = "Количество проданных";
            this.checkBoxSellServices.UseVisualStyleBackColor = true;
            this.checkBoxSellServices.CheckedChanged += new System.EventHandler(this.checkBoxSellServices_CheckedChanged);
            // 
            // Report
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(982, 553);
            this.Controls.Add(this.panelVisited);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.buttonShow);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Report";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Отчет";
            this.Load += new System.EventHandler(this.Report_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelVisited.ResumeLayout(false);
            this.panelVisited.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button buttonShow;
        private System.Windows.Forms.Label labelVisited;
        private System.Windows.Forms.Label labelServices;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panelVisited;
        private System.Windows.Forms.RadioButton radioForMonth;
        private System.Windows.Forms.RadioButton radioOtherPeriod;
        private System.Windows.Forms.Label labelTo;
        private System.Windows.Forms.Label labelWith;
        private System.Windows.Forms.DateTimePicker dateTimePickerEnd;
        private System.Windows.Forms.DateTimePicker dateTimePickerBegin;
        private System.Windows.Forms.RadioButton radioForWeek;
        private System.Windows.Forms.RadioButton radioForDay;
        private System.Windows.Forms.CheckBox checkBoxClientsForPeriod;
        private System.Windows.Forms.CheckBox checkBoxAllClients;
        private System.Windows.Forms.CheckBox checkBoxSellServices;
    }
}