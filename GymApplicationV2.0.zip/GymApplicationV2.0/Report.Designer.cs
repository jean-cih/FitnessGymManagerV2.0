﻿namespace GymApplicationV2._0
{
    partial class Report
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Report));
            this.buttonShow = new System.Windows.Forms.Button();
            this.labelVisited = new System.Windows.Forms.Label();
            this.labelServices = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.checkBoxSellServices = new System.Windows.Forms.CheckBox();
            this.panelVisited = new System.Windows.Forms.Panel();
            this.radioOtherPeriod = new System.Windows.Forms.RadioButton();
            this.labelTo = new System.Windows.Forms.Label();
            this.checkBoxClientsForPeriod = new System.Windows.Forms.CheckBox();
            this.labelWith = new System.Windows.Forms.Label();
            this.checkBoxAllClients = new System.Windows.Forms.CheckBox();
            this.dateTimePickerEnd = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerBegin = new System.Windows.Forms.DateTimePicker();
            this.radioForWeek = new System.Windows.Forms.RadioButton();
            this.radioForDay = new System.Windows.Forms.RadioButton();
            this.radioForMonth = new System.Windows.Forms.RadioButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.checkBoxJSON = new System.Windows.Forms.CheckBox();
            this.checkBoxTXT = new System.Windows.Forms.CheckBox();
            this.checkBoxXLS = new System.Windows.Forms.CheckBox();
            this.buttonChoose = new System.Windows.Forms.Button();
            this.buttonExport = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panelVisited.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonShow
            // 
            this.buttonShow.Location = new System.Drawing.Point(634, 455);
            this.buttonShow.Name = "buttonShow";
            this.buttonShow.Size = new System.Drawing.Size(140, 63);
            this.buttonShow.TabIndex = 8;
            this.buttonShow.Text = "Показать";
            this.buttonShow.UseVisualStyleBackColor = true;
            this.buttonShow.Click += new System.EventHandler(this.buttonShow_Click);
            // 
            // labelVisited
            // 
            this.labelVisited.AutoSize = true;
            this.labelVisited.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelVisited.Location = new System.Drawing.Point(33, 37);
            this.labelVisited.Name = "labelVisited";
            this.labelVisited.Size = new System.Drawing.Size(105, 20);
            this.labelVisited.TabIndex = 11;
            this.labelVisited.Text = "Посещения";
            // 
            // labelServices
            // 
            this.labelServices.AutoSize = true;
            this.labelServices.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelServices.Location = new System.Drawing.Point(33, 39);
            this.labelServices.Name = "labelServices";
            this.labelServices.Size = new System.Drawing.Size(188, 20);
            this.labelServices.TabIndex = 12;
            this.labelServices.Text = "Абонементы и услуги";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.checkBoxSellServices);
            this.panel1.Controls.Add(this.labelServices);
            this.panel1.Location = new System.Drawing.Point(9, 247);
            this.panel1.Margin = new System.Windows.Forms.Padding(5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(329, 268);
            this.panel1.TabIndex = 14;
            // 
            // checkBoxSellServices
            // 
            this.checkBoxSellServices.AutoSize = true;
            this.checkBoxSellServices.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBoxSellServices.Location = new System.Drawing.Point(56, 94);
            this.checkBoxSellServices.Name = "checkBoxSellServices";
            this.checkBoxSellServices.Size = new System.Drawing.Size(228, 24);
            this.checkBoxSellServices.TabIndex = 24;
            this.checkBoxSellServices.Text = "Количество проданных";
            this.checkBoxSellServices.UseVisualStyleBackColor = true;
            this.checkBoxSellServices.CheckedChanged += new System.EventHandler(this.checkBoxSellServices_CheckedChanged);
            // 
            // panelVisited
            // 
            this.panelVisited.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelVisited.Controls.Add(this.radioOtherPeriod);
            this.panelVisited.Controls.Add(this.labelTo);
            this.panelVisited.Controls.Add(this.checkBoxClientsForPeriod);
            this.panelVisited.Controls.Add(this.labelWith);
            this.panelVisited.Controls.Add(this.checkBoxAllClients);
            this.panelVisited.Controls.Add(this.dateTimePickerEnd);
            this.panelVisited.Controls.Add(this.labelVisited);
            this.panelVisited.Controls.Add(this.dateTimePickerBegin);
            this.panelVisited.Controls.Add(this.radioForWeek);
            this.panelVisited.Controls.Add(this.radioForDay);
            this.panelVisited.Controls.Add(this.radioForMonth);
            this.panelVisited.Location = new System.Drawing.Point(9, 9);
            this.panelVisited.Name = "panelVisited";
            this.panelVisited.Size = new System.Drawing.Size(721, 233);
            this.panelVisited.TabIndex = 20;
            // 
            // radioOtherPeriod
            // 
            this.radioOtherPeriod.AutoSize = true;
            this.radioOtherPeriod.Checked = true;
            this.radioOtherPeriod.Location = new System.Drawing.Point(403, 127);
            this.radioOtherPeriod.Name = "radioOtherPeriod";
            this.radioOtherPeriod.Size = new System.Drawing.Size(126, 20);
            this.radioOtherPeriod.TabIndex = 27;
            this.radioOtherPeriod.TabStop = true;
            this.radioOtherPeriod.Text = "Другой период";
            this.radioOtherPeriod.UseVisualStyleBackColor = true;
            // 
            // labelTo
            // 
            this.labelTo.AutoSize = true;
            this.labelTo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelTo.Location = new System.Drawing.Point(528, 160);
            this.labelTo.Name = "labelTo";
            this.labelTo.Size = new System.Drawing.Size(29, 20);
            this.labelTo.TabIndex = 26;
            this.labelTo.Text = "по";
            // 
            // checkBoxClientsForPeriod
            // 
            this.checkBoxClientsForPeriod.AutoSize = true;
            this.checkBoxClientsForPeriod.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBoxClientsForPeriod.Location = new System.Drawing.Point(56, 137);
            this.checkBoxClientsForPeriod.Name = "checkBoxClientsForPeriod";
            this.checkBoxClientsForPeriod.Size = new System.Drawing.Size(232, 24);
            this.checkBoxClientsForPeriod.TabIndex = 22;
            this.checkBoxClientsForPeriod.Text = "Посещаемость по дням";
            this.checkBoxClientsForPeriod.UseVisualStyleBackColor = true;
            this.checkBoxClientsForPeriod.CheckedChanged += new System.EventHandler(this.checkBoxClientsForPeriod_CheckedChanged);
            // 
            // labelWith
            // 
            this.labelWith.AutoSize = true;
            this.labelWith.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelWith.Location = new System.Drawing.Point(382, 160);
            this.labelWith.Name = "labelWith";
            this.labelWith.Size = new System.Drawing.Size(18, 20);
            this.labelWith.TabIndex = 20;
            this.labelWith.Text = "с";
            // 
            // checkBoxAllClients
            // 
            this.checkBoxAllClients.AutoSize = true;
            this.checkBoxAllClients.Checked = true;
            this.checkBoxAllClients.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxAllClients.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBoxAllClients.Location = new System.Drawing.Point(56, 84);
            this.checkBoxAllClients.Name = "checkBoxAllClients";
            this.checkBoxAllClients.Size = new System.Drawing.Size(138, 24);
            this.checkBoxAllClients.TabIndex = 21;
            this.checkBoxAllClients.Text = "Все клиенты";
            this.checkBoxAllClients.UseVisualStyleBackColor = true;
            this.checkBoxAllClients.CheckedChanged += new System.EventHandler(this.checkBoxAllClients_CheckedChanged);
            // 
            // dateTimePickerEnd
            // 
            this.dateTimePickerEnd.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerEnd.Location = new System.Drawing.Point(570, 160);
            this.dateTimePickerEnd.MaxDate = new System.DateTime(2100, 12, 31, 0, 0, 0, 0);
            this.dateTimePickerEnd.MinDate = new System.DateTime(2022, 1, 1, 0, 0, 0, 0);
            this.dateTimePickerEnd.Name = "dateTimePickerEnd";
            this.dateTimePickerEnd.Size = new System.Drawing.Size(109, 22);
            this.dateTimePickerEnd.TabIndex = 25;
            // 
            // dateTimePickerBegin
            // 
            this.dateTimePickerBegin.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerBegin.Location = new System.Drawing.Point(410, 160);
            this.dateTimePickerBegin.MaxDate = new System.DateTime(2100, 12, 31, 0, 0, 0, 0);
            this.dateTimePickerBegin.MinDate = new System.DateTime(2022, 1, 1, 0, 0, 0, 0);
            this.dateTimePickerBegin.Name = "dateTimePickerBegin";
            this.dateTimePickerBegin.Size = new System.Drawing.Size(109, 22);
            this.dateTimePickerBegin.TabIndex = 24;
            // 
            // radioForWeek
            // 
            this.radioForWeek.AutoSize = true;
            this.radioForWeek.Location = new System.Drawing.Point(403, 67);
            this.radioForWeek.Name = "radioForWeek";
            this.radioForWeek.Size = new System.Drawing.Size(98, 20);
            this.radioForWeek.TabIndex = 23;
            this.radioForWeek.Text = "За неделю";
            this.radioForWeek.UseVisualStyleBackColor = true;
            // 
            // radioForDay
            // 
            this.radioForDay.AutoSize = true;
            this.radioForDay.Location = new System.Drawing.Point(403, 97);
            this.radioForDay.Name = "radioForDay";
            this.radioForDay.Size = new System.Drawing.Size(79, 20);
            this.radioForDay.TabIndex = 22;
            this.radioForDay.Text = "За день";
            this.radioForDay.UseVisualStyleBackColor = true;
            // 
            // radioForMonth
            // 
            this.radioForMonth.AutoSize = true;
            this.radioForMonth.Location = new System.Drawing.Point(403, 37);
            this.radioForMonth.Name = "radioForMonth";
            this.radioForMonth.Size = new System.Drawing.Size(87, 20);
            this.radioForMonth.TabIndex = 21;
            this.radioForMonth.Text = "За месяц";
            this.radioForMonth.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.checkBoxJSON);
            this.panel2.Controls.Add(this.checkBoxTXT);
            this.panel2.Controls.Add(this.checkBoxXLS);
            this.panel2.Controls.Add(this.buttonChoose);
            this.panel2.Controls.Add(this.buttonExport);
            this.panel2.Location = new System.Drawing.Point(736, 9);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(234, 233);
            this.panel2.TabIndex = 21;
            // 
            // checkBoxJSON
            // 
            this.checkBoxJSON.AutoSize = true;
            this.checkBoxJSON.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBoxJSON.Location = new System.Drawing.Point(31, 97);
            this.checkBoxJSON.Name = "checkBoxJSON";
            this.checkBoxJSON.Size = new System.Drawing.Size(66, 24);
            this.checkBoxJSON.TabIndex = 30;
            this.checkBoxJSON.Text = ".json";
            this.checkBoxJSON.UseVisualStyleBackColor = true;
            this.checkBoxJSON.CheckedChanged += new System.EventHandler(this.checkBoxJSON_CheckedChanged);
            // 
            // checkBoxTXT
            // 
            this.checkBoxTXT.AutoSize = true;
            this.checkBoxTXT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBoxTXT.Location = new System.Drawing.Point(31, 67);
            this.checkBoxTXT.Name = "checkBoxTXT";
            this.checkBoxTXT.Size = new System.Drawing.Size(53, 24);
            this.checkBoxTXT.TabIndex = 29;
            this.checkBoxTXT.Text = ".txt";
            this.checkBoxTXT.UseVisualStyleBackColor = true;
            this.checkBoxTXT.CheckedChanged += new System.EventHandler(this.checkBoxTXT_CheckedChanged);
            // 
            // checkBoxXLS
            // 
            this.checkBoxXLS.AutoSize = true;
            this.checkBoxXLS.Checked = true;
            this.checkBoxXLS.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxXLS.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBoxXLS.Location = new System.Drawing.Point(31, 33);
            this.checkBoxXLS.Name = "checkBoxXLS";
            this.checkBoxXLS.Size = new System.Drawing.Size(56, 24);
            this.checkBoxXLS.TabIndex = 28;
            this.checkBoxXLS.Text = ".xls";
            this.checkBoxXLS.UseVisualStyleBackColor = true;
            this.checkBoxXLS.CheckedChanged += new System.EventHandler(this.checkBoxXLS_CheckedChanged);
            // 
            // buttonChoose
            // 
            this.buttonChoose.Location = new System.Drawing.Point(18, 160);
            this.buttonChoose.Name = "buttonChoose";
            this.buttonChoose.Size = new System.Drawing.Size(90, 50);
            this.buttonChoose.TabIndex = 1;
            this.buttonChoose.Text = "Выбрать файл";
            this.buttonChoose.UseVisualStyleBackColor = true;
            this.buttonChoose.Click += new System.EventHandler(this.buttonChoose_Click);
            // 
            // buttonExport
            // 
            this.buttonExport.Location = new System.Drawing.Point(125, 160);
            this.buttonExport.Name = "buttonExport";
            this.buttonExport.Size = new System.Drawing.Size(90, 50);
            this.buttonExport.TabIndex = 0;
            this.buttonExport.Text = "Экспортировать";
            this.buttonExport.UseVisualStyleBackColor = true;
            this.buttonExport.Click += new System.EventHandler(this.buttonExport_Click);
            // 
            // Report
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(982, 553);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panelVisited);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.buttonShow);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Report";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Отчет";
            this.Load += new System.EventHandler(this.Report_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelVisited.ResumeLayout(false);
            this.panelVisited.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button buttonShow;
        private System.Windows.Forms.Label labelVisited;
        private System.Windows.Forms.Label labelServices;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panelVisited;
        private System.Windows.Forms.RadioButton radioForMonth;
        private System.Windows.Forms.RadioButton radioOtherPeriod;
        private System.Windows.Forms.Label labelTo;
        private System.Windows.Forms.Label labelWith;
        private System.Windows.Forms.DateTimePicker dateTimePickerEnd;
        private System.Windows.Forms.DateTimePicker dateTimePickerBegin;
        private System.Windows.Forms.RadioButton radioForWeek;
        private System.Windows.Forms.RadioButton radioForDay;
        private System.Windows.Forms.CheckBox checkBoxClientsForPeriod;
        private System.Windows.Forms.CheckBox checkBoxAllClients;
        private System.Windows.Forms.CheckBox checkBoxSellServices;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button buttonExport;
        private System.Windows.Forms.Button buttonChoose;
        private System.Windows.Forms.CheckBox checkBoxJSON;
        private System.Windows.Forms.CheckBox checkBoxTXT;
        private System.Windows.Forms.CheckBox checkBoxXLS;
    }
}