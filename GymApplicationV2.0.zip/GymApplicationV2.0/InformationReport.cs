﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymApplicationV2._0
{
    public partial class InformationReport : Form
    {
        public InformationReport()
        {
            InitializeComponent();
        }

        private void Attendance_Load(object sender, EventArgs e)
        {
            if (DataClass.AllClients)
            {
                dataGridViewShowReport.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts");

                object allClients = ClientsContext.GetElementClient("SELECT COUNT(*) FROM Contacts");

                labelQuantity.Text = allClients.ToString();
                labelShowPeriod.Text = "Клиенты за все время";
            }
            else if (DataClass.ClientsForPeriod)
            {
                object allClients = null;
                DateTime now = DateTime.Now;

                if (DataClass.PeriodForMonth)
                {
                    var beginMonth = new DateTime(now.Year, now.Month, 1);

                    dataGridViewShowReport.DataSource = ClientsContext.GetDataFromDatabase($"SELECT Посетил, Фамилия, Имя, Телефон, №Карты, Абонемент FROM Contacts WHERE Посетил BETWEEN '{beginMonth}' AND '{DateTime.Now}'");

                    allClients = ClientsContext.GetElementClient($"SELECT COUNT(*) FROM Contacts WHERE Посетил BETWEEN '{beginMonth}' AND '{DateTime.Now}'");
                    labelShowPeriod.Text = "Посещения с " + beginMonth.ToShortDateString() + " по " + DateTime.Now.ToShortDateString();
                }
                else if (DataClass.PeriodForWeek)
                {
                    var startLastWeek = new DateTime(now.Year, now.Month, now.Day - (int)now.DayOfWeek + 1);

                    dataGridViewShowReport.DataSource = ClientsContext.GetDataFromDatabase($"SELECT Посетил, Фамилия, Имя, Телефон, №Карты, Абонемент FROM Contacts WHERE Посетил BETWEEN '{startLastWeek}' AND '{DateTime.Now}'");

                    allClients = ClientsContext.GetElementClient($"SELECT COUNT(*) FROM Contacts WHERE Посетил BETWEEN '{startLastWeek}' AND '{DateTime.Now}'");
                    labelShowPeriod.Text = "Посещения с " + startLastWeek.ToShortDateString() + " по " + DateTime.Now.ToShortDateString();
                }
                else if (DataClass.PeriodForDay)
                {
                    var startPreviousDay = new DateTime(now.Year, now.Month, now.Day);

                    dataGridViewShowReport.DataSource = ClientsContext.GetDataFromDatabase($"SELECT Посетил, Фамилия, Имя, Телефон, №Карты, Абонемент FROM Contacts WHERE Посетил BETWEEN '{startPreviousDay}' AND '{DateTime.Now}'");

                    allClients = ClientsContext.GetElementClient($"SELECT COUNT(*) FROM Contacts WHERE Посетил BETWEEN '{startPreviousDay}' AND '{DateTime.Now}'");
                    labelShowPeriod.Text = "Посещения с " + startPreviousDay.ToShortDateString() + " по " + new DateTime(now.Year, now.Month, now.Day + 1).ToShortDateString();
                }
                else
                {
                    dataGridViewShowReport.DataSource = ClientsContext.GetDataFromDatabase($"SELECT Посетил, Фамилия, Имя, Телефон, №Карты, Абонемент FROM Contacts WHERE Посетил BETWEEN '{DataClass.Begin.Date}' AND '{DataClass.End}'");

                    allClients = ClientsContext.GetElementClient($"SELECT COUNT(*) FROM Contacts WHERE Посетил BETWEEN '{DataClass.Begin.Date}' AND '{DataClass.End}'");
                    labelShowPeriod.Text = "Посещения с " + DataClass.Begin.ToShortDateString() + " по " + DataClass.End.ToShortDateString();
                }

                labelQuantity.Text = allClients.ToString();
            }
            else
            {
                labelShowPeriod.Visible = false;
                labelAllClients.Visible = false;
                labelQuantity.Visible = false;

                dataGridViewShowReport.DataSource = ServicesContext.GetDataFromDatabase($"SELECT * FROM Descriptions");
            }
        }

        private void dataGridViewAttendance_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
