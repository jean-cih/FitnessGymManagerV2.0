﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymApplicationV2._0
{
    public partial class InformationReport : Form
    {
        public InformationReport()
        {
            InitializeComponent();
        }

        private void Attendance_Load(object sender, EventArgs e)
        {
            if (DataClass.AllClients)
            {
                dataGridViewShowReport.DataSource = ClientsContext.GetDataFromDatabase("SELECT * FROM Contacts");

                object allClients = ClientsContext.GetElementClient("SELECT COUNT(*) FROM Contacts");

                labelQuantity.Text = allClients.ToString();
            }
            else if (DataClass.ClientsForPeriod)
            {
                object allClients = null;
                DateTime now = DateTime.Now;

                if (DataClass.PeriodForMonth)
                {
                    var beginMonth = new DateTime(now.Year, now.Month, 1);

                    dataGridViewShowReport.DataSource = ClientsContext.GetDataFromDatabase($"SELECT * FROM Contacts WHERE Посетил BETWEEN '{beginMonth}' AND '{DateTime.Now}'");

                    allClients = ClientsContext.GetElementClient($"SELECT COUNT(*) FROM Contacts WHERE Посетил BETWEEN '{beginMonth}' AND '{DateTime.Now}'");
                }
                else if (DataClass.PeriodForWeek)
                {
                    var startLastWeek = new DateTime(now.Year, now.Month, now.Day - (int)now.DayOfWeek + 1);

                    dataGridViewShowReport.DataSource = ClientsContext.GetDataFromDatabase($"SELECT * FROM Contacts WHERE Посетил BETWEEN '{startLastWeek}' AND '{DateTime.Now}'");

                    allClients = ClientsContext.GetElementClient($"SELECT COUNT(*) FROM Contacts WHERE Посетил BETWEEN '{startLastWeek}' AND '{DateTime.Now}'");
                }
                else if (DataClass.PeriodForDay)
                {
                    var startPreviousDay = new DateTime(now.Year, now.Month, now.Day);

                    dataGridViewShowReport.DataSource = ClientsContext.GetDataFromDatabase($"SELECT * FROM Contacts WHERE Посетил BETWEEN '{startPreviousDay}' AND '{DateTime.Now}'");

                    allClients = ClientsContext.GetElementClient($"SELECT COUNT(*) FROM Contacts WHERE Посетил BETWEEN '{startPreviousDay}' AND '{DateTime.Now}'");
                }
                else
                {
                    dataGridViewShowReport.DataSource = ClientsContext.GetDataFromDatabase($"SELECT * FROM Contacts WHERE Посетил BETWEEN '{DataClass.Begin.Date}' AND '{DataClass.End}'");

                    allClients = ClientsContext.GetElementClient($"SELECT COUNT(*) FROM Contacts WHERE Посетил BETWEEN '{DataClass.Begin.Date}' AND '{DataClass.End}'");
                }

                labelQuantity.Text = allClients.ToString();
            }
            else
            {
                labelAllClients.Visible = false;
                labelQuantity.Visible = false;

                dataGridViewShowReport.DataSource = ServicesContext.GetDataFromDatabase($"SELECT * FROM Descriptions");
            }
        }

        private void dataGridViewAttendance_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
