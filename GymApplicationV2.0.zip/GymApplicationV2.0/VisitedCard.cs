﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymApplicationV2._0
{
    public class VisitedCard
    {
        private string numberCard;

        public string NumberCard
        {
            get { return numberCard; }
            set
            {
                numberCard = value;
            }
        }
    }
}
